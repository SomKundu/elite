<?php
class cms_login_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

    public function login_check($data){
        $this->db->select('*');
        $this->db->where('username',$data['username']);
        $this->db->where('password',$data['password']);
        $query=$this->db->get('admin');
        echo $this->db->last_query();
        return $query->result();
     
    }   
    public function adddate_time($id,$arg){
        date_default_timezone_set("Asia/Kolkata");
        if($arg=='login')     $data['login_time'] = date('Y-m-d H:i:s');
        if($arg=='logout')    $data['logout_time'] = date('Y-m-d H:i:s');
        $this->db->where('id',$id);
        $this->db->update('admin',$data);
    } 
}