<?php
class cms_comment_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

 public function getlist()
 {
 	$this->db->select('*');
 	$query=$this->db->get('comment');
 	 return $query->result();     
 }
 public function getdetials($id)
{
	$this->db->where('id',$id);
	$this->db->select('*');
	$query=$this->db->get('comment');
	return $query->result();
}


}