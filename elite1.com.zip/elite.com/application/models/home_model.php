<?php
class home_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    public function getbanners($count=4){
		$this->db->select('*');
		$this->db->order_by("id", "desc"); 
		$this->db->where('status','y');
		$query=$this->db->get('banner',$count,0);
		return $query->result();
	}
    public function getfeatured($count=10){
		$this->db->select('a.*,b.title as subcatagory');
		$this->db->from('product as a');
		$this->db->order_by("a.id", "desc"); 
		$this->db->where('a.featured','y');
		$this->db->where('a.status','y');
		$this->db->join('catagory as b','a.sub_cat_id = b.id','left');
		$query=$this->db->get();
		return $query->result();
	}
	public function getPromotionalCatagories(){
	    $this->db->select('*');
	    $this->db->where(array('parent_id'=>'0','home_link'=>'y','status'=>'y'));
	    $query=$this->db->get('catagory');
	    return $query->result();
	}
	public function getDiscounts(){
		$sql="SELECT id,discount,title,image1 FROM product WHERE discount<>''";
		$query=$this->db->query($sql);
	    return $query->result();
	}
	public function getMAXDiscount(){
		$sql="SELECT MAX(discount) as MaxDiscountVal FROM product WHERE discount<>''";
		$query=$this->db->query($sql);
	    return $query->result();
	}
	public function offerBaner(){
		$sql="SELECT * FROM  `offer_promotion`  WHERE place='secondarybanner' AND status='y'";
		$query=$this->db->query($sql);
	    return $query->result();
	}
}