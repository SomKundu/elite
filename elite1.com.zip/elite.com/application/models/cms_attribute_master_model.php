<?php
class cms_attribute_master_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

 public function getlist()
 {
 	$this->db->select('*');
 	$query=$this->db->get('attribute_name_master');
 	 return $query->result();
     
 } 


public function getdetials($id)
{
	$this->db->where('id',$id);
	$this->db->select('*');
	$query=$this->db->get('attribute_name_master');
	return $query->result();

}

public function save($data)
{
	$this->db->insert('attribute_name_master',$data);
}

 public function update($id,$data)
 {
 	$this->db->where('id',$id);
 	$this->db->update('attribute_name_master',$data);
 }

 public function delete($id)
  {
  	$this->db->where('id',$id);
  	$this->db->delete('attribute_name_master');
  }



}