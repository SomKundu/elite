<?php
	class cms_admin_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

}