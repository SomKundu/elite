<?php
class cms_catagory_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

 public function getlist()
 {
 	$this->db->select('*');
  $this->db->where(array('parent_id'=>'0'));
 	$query=$this->db->get('catagory');
 	 return $query->result();
     
 } 


public function getdetials($id)
{
	$this->db->where('id',$id);
	$this->db->select('*');
	$query=$this->db->get('catagory');
	return $query->result();

}

public function save($data)
{
	$this->db->insert('catagory',$data);
}

 public function update($id,$data)
 {
 	$this->db->where('id',$id);
 	$this->db->update('catagory',$data);
 }

 public function delete($id)
  {
  	$this->db->where('id',$id);
  	$this->db->delete('catagory');
  }



}