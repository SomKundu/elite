<?php
class cms_attribute_model extends CI_Model
{
	function __construct(){
		// Call the Model constructor
        parent::__construct();
    }	
	public function getlist()
	{
		$this->db->select('a.*,b.attribute_field_name');
		$this->db->from('attribute_value_master as a');
		$this->db->order_by("a.id", "desc");
		$this->db->join('attribute_name_master as b','a.attribute_field_name_id = b.id');
		$query=$this->db->get();
		return $query->result();   
	 
	} 
	public function getdetials($id)
	{
		$this->db->where('id',$id);
		$this->db->select('*');
		$query=$this->db->get('attribute_value_master');
		return $query->result();
	}

	public function getattribute()
	{
		 $this->db->select('*');
	     $query=$this->db->get('attribute_name_master');
	     return $query->result();
	}

	public function attributelist($subcat_id)
	{
		$this->db->select('*');
	  	$this->db->where('subcat_id',$subcat_id);
	     $query=$this->db->get('attribute');
	     return $query->result();
    }
		public function getattributedetials()
	
	{
		 $this->db->select('*');
		 $this->db->where('input_status','select');
	     $query=$this->db->get('attribute_name_master');
	     return $query->result();
	}
		
	public function save($data)
	{
		$this->db->insert('attribute_value_master',$data);
	}


	 public function update($id,$data)
	 {
	 	$this->db->where('id',$id);
	 	$this->db->update('attribute_value_master',$data);
	 }


	 public function delete($id)
	  {
	  	$this->db->where('id',$id);
	  	$this->db->delete('attribute_value_master');
	  } 
	public function get_attribute_list()
	{
		$this->db->select('a.*,b.attribute_field_name');
		$this->db->from('attribute_value_master as a');
		$this->db->join('attribute_name_master as b','a.attribute_field_name_id = b.id');
		$query=$this->db->get();
		return $query->result();   
	 
	} 
   	public function attribute_save($data)
   	{
   		$this->db->insert('attribute',$data);
   	}
  	public function attribute_delete($id)
	{
	  	$this->db->where('id',$id);
	  	$this->db->delete('attribute');
	} 
	public function update_attribute($data,$id){
		$this->db->where('id',$id);
	 	$this->db->update('attribute',$data);
	}
	public function delete_attribute($id){
	  	$this->db->where('id',$id);
	  	$this->db->delete('attribute');
	}
}