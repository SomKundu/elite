<?php
class media_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
	public function getCorporateHeaderList(){
	    $this->db->select('id,header');
	    $this->db->order_by("sequence_no", "asc");
	    $this->db->where(array('page'=>'media'));
	    $query=$this->db->get('content');
	    return $query->result();
	}
	public function getCorporateContentList(){
	    $this->db->select('*');
	    $this->db->order_by("sequence_no", "asc");
	    $this->db->where(array('page'=>'media'));
	    $query=$this->db->get('content');
	    return $query->result();
	}
}