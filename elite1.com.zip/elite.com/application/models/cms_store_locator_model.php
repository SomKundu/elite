<?php
class cms_store_locator_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

 public function getlist()
 {
 	$this->db->select('*');
 	$query=$this->db->get('store_locator');
 	 return $query->result();
     
 }
 public function getdetials($id)
{
	$this->db->where('id',$id);
	$this->db->select('*');
	$query=$this->db->get('store_locator');
	return $query->result();

}

public function save($data)
{
	$this->db->insert('store_locator',$data);
}

public function update($id,$data)
 {
 	$this->db->where('id',$id);
 	$this->db->update('store_locator',$data);
 }
  public function delete($id)
  {
  	$this->db->where('id',$id);
  	$this->db->delete('store_locator');
  }
}