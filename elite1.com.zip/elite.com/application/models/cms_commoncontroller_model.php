<?php
class cms_commoncontroller_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    public function getComments($id){
    	$sql="	SELECT a.* FROM  
				`comment` as a, `admin` as b 
		WHERE 	b.`id`=".$id." AND 
				a.`last_update_on` between b.`logout_time` and b.`login_time`";
		$query = $this->db->query($sql);
		return $query->result();
    }
}