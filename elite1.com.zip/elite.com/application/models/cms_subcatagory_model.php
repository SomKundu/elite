<?php
class cms_subcatagory_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

    

 public function getlist()
 {  
  $this->db->select('a.*,b.title as cat_title,b.id as cat_id');
  $this->db->from('catagory as a')->where('a.parent_id >','0');
  $this->db->join('catagory as b','a.parent_id = b.id','left');
  $query=$this->db->get();
   return $query->result();     
  } 


public function getdetials($id)
{
	$this->db->where('id',$id);
	$this->db->select('*');
	$query=$this->db->get('catagory');
	return $query->result();
}


public function save($data)
{
	$this->db->insert('catagory',$data);
}


 public function update($id,$data)
 {
 	$this->db->where('id',$id);
 	$this->db->update('catagory',$data);
 }


 public function delete($id)
  {
  	$this->db->where('id',$id);
  	$this->db->delete('catagory');
  }   


    public function getcatagories(){
    $this->db->select('*');
    $this->db->where(array('parent_id'=>'0'));
    $query=$this->db->get('catagory');
    return $query->result();
  }


}