<?php
class product_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    public function getbestseller(){
		$this->db->select('*');
		$this->db->where(array('best_seller'=>'y'));	
		$query=$this->db->get('product',5,0);		
		return $query->result();
	}
    public function getproducts($identifier,$param){
		$this->db->select('*');
		$this->db->where(array('status'=>'y'));
		if($param=='scat')	$this->db->where(array('sub_cat_id'=>$identifier));
		if($param=='cat')	$this->db->where(array('cat_id'=>$identifier));
		$query=$this->db->get('product');
		return $query->result();
	}
	public function getproductdetail($id){
	    $this->db->select('*');
	    $this->db->where(array('status'=>'y','id'=>$id));
	    $query=$this->db->get('product');
	    return $query->result();
	}
	public function getproductAttributes($product_id){
		$this->db->select('a.id,b.attribute,a.attribute_value,c.input_status,c.id as attribute_field_id');
	    //$this->db->order_by("sequence_no", "asc");
		$this->db->where(array('a.status'=>'y','a.product_id'=>$product_id));
		$this->db->from('product_attribute as a');
		$this->db->join('attribute as b','a.attribute_id = b.id','left');
		$this->db->join('attribute_name_master as c','c.id = b.attribute_type','left');
		$query=$this->db->get();
	    return $query->result();
	}	
	public function getproductAttributeValues(){
		$this->db->select('id,attribute_field_name_id,value');
	    $this->db->where(array('status'=>'y'));
	    $query=$this->db->get('attribute_value_master');
	    return $query->result();
	}
	public function getsimilar(){
	    $this->db->select('a.*,b.title as subcatagory');
		$this->db->from('product as a');
		$this->db->order_by("a.id", "desc"); 
		$this->db->join('catagory as b','a.sub_cat_id = b.id','left');
		$query=$this->db->get();
	    return $query->result();
	}
	public function getAttributecatagories($indicator){
	    $this->db->select('id,title');
	    $this->db->where(array('parent_id'=>$indicator,'status'=>'y'));
	    $query=$this->db->get('catagory');
	    return $query->result();
	}
	public function getAttributes($subcat_id){
	    $this->db->select('a.*,b.input_status,b.id as attribute_type_id');
	    $this->db->where(array('a.subcat_id'=>$subcat_id,'a.status'=>'y','b.status'=>'y','b.input_status'=>'select'));
	    $this->db->from('attribute as a');
	    $this->db->join('attribute_name_master as b','a.attribute_type = b.id','left');
	    $query=$this->db->get();
	    return $query->result();
	}
	public function getAttributeValues($subcat_id){
		$this->db->select('b.*,a.input_status');
	    $this->db->where(array('c.subcat_id'=>$subcat_id,'a.input_status'=>'select','a.status'=>'y','b.status'=>'y'));
	    $this->db->from('attribute_name_master as a');
	    $this->db->join('attribute_value_master as b','b.attribute_field_name_id = a.id','left');
	    $this->db->join('attribute as c','a.id = c.attribute_type','left');
	    return $this->db->get()->result();
	}
	public function getsubcatagories($parent_id){
	    $this->db->select('*');
	    $this->db->where(array('parent_id'=>$parent_id));
	    $query=$this->db->get('catagory');
	    return $query->result();
	}
}