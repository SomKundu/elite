<?php
class storelocator_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
	public function get_State(){
    		$query = $this->db->query("SELECT distinct state from `store_locator`");
    		return $query->result();
    }
    public function get_State_Dist($state){
    		$query = $this->db->query("SELECT distinct district FROM `store_locator` WHERE `state`='".$state."'");
    		return $query->result();
    }
   public function get_State_Town($dist){
    		$query = $this->db->query("SELECT distinct city FROM `store_locator` WHERE `district`='".$dist."'");
    		return $query->result();
    }
    public function get_State_Location($city){
        $query = $this->db->query("SELECT  * FROM `store_locator` WHERE `city`='".$city."'");
        return $query->result();
    }
    public function getStoreLocationMarker($city=''){
        $sql =' SELECT  store_name as STORENAME,
                        lat as LATITUDE,
                        lng as LONGITITUDE,
                        address as ADDRESS, city 
                FROM    `store_locator` ';
        $query ='';
        if($city=='')
            $query = $this->db->query($sql);
        else
            $query = $this->db->query($sql." "."WHERE `city`='".$city."'");
        return $query->result();
    }
}