<?php
class cms_banner_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

 public function getlist()
 {
 	$this->db->select('*');
  	$query=$this->db->get('banner');
 	 return $query->result();
     
} 


public function getdetials($id)
{
	$this->db->where('id',$id);
	$this->db->select('*');
	$query=$this->db->get('banner');
	return $query->result();

}

 public function update($id,$data)
 {
 	$this->db->where('id',$id);
 	$this->db->update('banner',$data);
 }

 public function delete($id)
  {
  	$this->db->where('id',$id);
  	$this->db->delete('banner');
  }


public function save($data)
{
	$this->db->insert('banner',$data);
}


}