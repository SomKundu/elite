<?php
class cms_newsletter_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

 public function getlist()
 {
 	$this->db->select('*');
 	$query=$this->db->get('newsletter');
 	 return $query->result();     
 }
 public function getdetials($id)
{
	$this->db->where('id',$id);
	$this->db->select('*');
	$query=$this->db->get('newsletter');
	return $query->result();
}
public function email()
{
    $this->db->select('*');
    $query=$this->db->get('client_email');
    return $query->result();
}
public function save($data)
{
	$this->db->insert('newsletter',$data);
}

public function update($id,$data)
 {
 	$this->db->where('id',$id);
 	$this->db->update('newsletter',$data);
 }
  public function delete($id)
  {
  	$this->db->where('id',$id);
  	$this->db->delete('newsletter');
  }
}