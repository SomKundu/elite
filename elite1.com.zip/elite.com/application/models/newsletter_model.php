<?php
class newsletter_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    public function add_email($arrData){
    	$query = $this->db->query("INSERT INTO`client_email`(email)VALUES('".$arrData."')");
    	return true;
    }
}