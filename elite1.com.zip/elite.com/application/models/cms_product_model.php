<?php
class cms_product_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
	public function getlist(){
		$this->db->select('a.*,b.title as sub_cat_title');
		$this->db->from('product as a');
		$this->db->join('catagory as b','a.sub_cat_id = b.id','left');
		$query=$this->db->get();
		return $query->result();
	} 	
	public function getdetials($id)
	{
		$this->db->where('id',$id);
		$this->db->select('*');
		$query=$this->db->get('product');
		return $query->result();
	
	}
	
	public function save($data)
	{
		$this->db->insert('product',$data);
	}
	
	public function update($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('product',$data);
	}
	
	public function delete($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('product');
	}
	public function getsubcatagories(){
		$this->db->select('*');
		$this->db->where(array('status'=>'y','parent_id >'=>'0'));
		$query=$this->db->get('catagory');
		return $query->result();
	}
	
	public function getcatagories(){
		$this->db->select('*');
		$this->db->where(array('status'=>'y','parent_id'=>'0'));
		$query=$this->db->get('catagory');
		return $query->result();
	}
	public function getAttribute($product_id){
		$sql="SELECT * FROM  `attribute` WHERE status='y' AND subcat_id IN(SELECT sub_cat_id FROM product WHERE id=".$product_id.")";
		//$this->db->select('*');
		//$this->db->where(array('status'=>'y','subcat_id'=>$subcat_id));
		//$query=$this->db->get('attribute');
		$query=$this->db->query($sql);
		return $query->result();
	}

	public function getAttributeNameMaster(){
		$this->db->select('id,input_status');
		$this->db->where(array('status'=>'y'));
		$query=$this->db->get('attribute_name_master');
		return $query->result();
	}
	public function getAttributeSelecttionMaster(){
		$this->db->select('id,attribute_field_name_id,value');
		$this->db->where(array('status'=>'y'));
		$query=$this->db->get('attribute_value_master');
		return $query->result();
	}
	public function saveAttribute($data){
		$this->db->insert('product_attribute',$data);
	}
	public function getProductAttributeValue($product_id){
		$sql="	SELECT 	a.*,
						c.`id` as attribute_field_id,
						c.`input_status`
				FROM 	`product_attribute` as a ,
						`attribute` as b , 
						`attribute_name_master` as c
				WHERE 	a.`product_id`=".$product_id." AND
						a.attribute_id=b.id AND
						b.attribute_type=c.id";
		$query=$this->db->query($sql);
		return $query->result();
	}
	public function delAttribute($product_id){
		$this->db->delete('product_attribute', array('product_id' => $product_id)); 		
	}
}