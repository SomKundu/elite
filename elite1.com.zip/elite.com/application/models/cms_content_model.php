<?php
class cms_content_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

 public function getlist($page)
 {
  $this->db->select('*');
  $this->db->where('page',$page);
  $query=$this->db->get('content');
   return $query->result();     
 }

public function getdetials($id)
{
  $this->db->where('id',$id);
  $this->db->select('*');
  $query=$this->db->get('content');
  return $query->result();
}

public function save($data)
{
  $this->db->insert('content',$data);
}

 public function update($id,$data)
 {
  $this->db->where('id',$id);
  $this->db->update('content',$data);
 }

 public function delete($id)
  {
    $this->db->where('id',$id);
    $this->db->delete('content');
  } 

   public function count($page)
   {
    $this->db->select('*');
    $this->db->where('page',$page);
    return $this->db->get('content')->result();
   }
   
}
/*
class cms_content_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }

 public function getlist()
 {
 	$this->db->select('*');
 	$query=$this->db->get('content');
 	 return $query->result();
     
 } 


public function getdetials($id)
{
	$this->db->where('id',$id);
	$this->db->select('*');
	$query=$this->db->get('content');
	return $query->result();

}

public function save($data)
{
	$this->db->insert('content',$data);
}

 public function update($id,$data)
 {
 	$this->db->where('id',$id);
 	$this->db->update('content',$data);
 }

 public function delete($id)
  {
  	$this->db->where('id',$id);
  	$this->db->delete('content');
  }



}
*/