<?php
class content_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }   
	
	public function getcontent($id){
		$this->db->select('*');
	    $this->db->where(array('id'=>$id));
	    $query=$this->db->get('content');
	    return $query->result();
	}
}