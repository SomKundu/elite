<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_commoncontroller extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cms_commoncontroller_model','my_model');
	}
	public function commonLayoutView($viewPath,$viewData){
		$data_header=array();
		$data_side=array();
		$viewPartialPath='cms_admin/';
		if($this->uri->segment(2)<>'login'){
		$data_side['catagory_list']='cms-admin/catagory/index/';
		$data_side['subcatagory_list']='cms-admin/subcatagory/index/';
		$data_side['banner_list']='cms-admin/banner/index/';
		////////////////////////////////////////////////////
		$data_side['content_list']='cms-admin/content/index/';
		$data_side['corporate_list']='cms-admin/corporate/index/';
		$data_side['media_list']='cms-admin/media/index/';
		/////////////////////////////////////////////////////
		$data_side['product_list']='cms-admin/product/index/';
	##################################################################
		$data_side['attribute_list']='cms-admin/attribute/index/';
		$data_side['franchise_list']='cms-admin/franchise/index/';
		$data_side['jobseeker_list']='cms-admin/jobseeker/index/';
	#################################################################
		$data_side['store_locator_list']='cms-admin/store_locator/index/';
		$data_side['newsletter_list']='cms-admin/newsletter/index/';
		$data_side['attribute_master_list']='cms-admin/attribute_master/index/';
		$data_side['corporate_list']='cms-admin/corporate/index/';
		$data_side['offer_list']='cms-admin/offer/index/';
	#################################################################	
		$data_header['logout_link']='cms-admin/login/logout/';
		$data_header['commentData']=$this->my_model->getComments($this->session->userdata('login_id'));
		$data_header['allComment_link']='cms-admin/comments/index/';
		}
		$this->load->view($viewPartialPath.'layout/headertop');
		if($this->uri->segment(2)<>'login'){
	    $this->load->view($viewPartialPath.'layout/header',$data_header);
	    $this->load->view($viewPartialPath.'layout/sidemenu',$data_side);
		$this->load->view($viewPartialPath.'layout/subheader');
		}
		$this->load->view($viewPartialPath.$viewPath,$viewData);
		if($this->uri->segment(2)<>'login'){
		$this->load->view($viewPartialPath.'layout/footer');
		}
		$this->load->view($viewPartialPath.'layout/footerdown');
	
    }
	public function logincheck(){
		$this->session->set_userdata('current_url',current_url());
		if(!$this->session->userdata('login_data')){
			redirect(base_url().'cms-admin/login/index');	
		}
	}
	public function reloadComment(){
		$commentData=$this->my_model->getComments();
		$allComment_link='cms-admin/comments/index/';
		$msg='
		<li class="dropdown-menu-title">
				<span>You have '.count($commentData).' messages</span>
			<a href="#" onClick="myPageReload();"><i class="icon-repeat"></i></a>
		</li>';
		if(count($commentData)>0){
		foreach($commentData as $cmt){
			$date=explode('-',current(explode(' ',$cmt->last_update_on)));
			$jd=gregoriantojd((int)$date[1],(int)$date[0],(int)$date[2]);
			$month=jdmonthname($jd,0);			
			$msg.='
			<li>
		        <a href="#">
					<span class="avatar"><img src="'.base_url().'assets/cms_admin/img/avatar.jpg" alt="Avatar"></span>
					<span class="header">
						<span class="from">'.$cmt->name.'</span>
						<span class="time">'.$date[2].'-'.$date[1].'-'.$date[0].'</span>
					</span>            
		            <span class="message">'.$cmt->comments.'</span>             
		            <span class="header">
						<span class="from">Phone: '.$cmt->phone_no.'</span>
					</span>
		            <span class="header">
						<span class="from">Email: '.$cmt->email_id.'</span>
					</span>
		        </a>
		    </li>';
		}}else{
			$msg.='
			<li>
		        <a href="#">          
		            <span class="message">No More New Comment Found</span>             
		        </a>
		    </li>';
		}
		$msg.='
		<li>
    		<a href="'.base_url().$allComment_link.'" class="dropdown-menu-sub-footer">View all messages</a>
		</li>';
		echo $msg;
	}
}