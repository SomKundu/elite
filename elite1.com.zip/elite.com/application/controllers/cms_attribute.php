<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_attribute extends CI_Controller {
	public function __construct() {
        parent::__construct();
		$this->load->model('cms_attribute_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');
    }
	//public function index(){redirect(BACKEND_URL.'catagory/viewlist/');}
	public function index(){
		$this->cms_commoncontroller->logincheck(); 
        $data['edit']='cms-admin/attribute/edit/';
        $data['delete']='cms-admin/attribute/delete/';
        $data['table_header']='Attribute Master List';
        $data['addNew']='cms-admin/attribute/addnew/';
		$data['list']=$this->my_model->getlist();   
        //$data['getvalue']=$this->my_model->getvalue();
		$this->cms_commoncontroller->commonLayoutView('attribute/index',$data);
	}

   
    public function addnew()
    {   
        $this->cms_commoncontroller->logincheck(); 
        $data['form_action']='cms_attribute/addnew_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/attribute/index/'; 
        $data['form_header']='Attribute Master Add New';       
        $data['getattributedetials']=$this->my_model->getattributedetials();
		$this->cms_commoncontroller->commonLayoutView('attribute/addnew',$data);
    }

    public function addnew_post()
    {
    	//print_r($this->input->post());
        $data['attribute_field_name_id']=$this->input->post('attribute_field_name_id');
        $data['value']=$this->input->post('value');
        $data['status']=$this->input->post('status');
        //print_r($data);
        $this->my_model->save($data);
        redirect(base_url().'cms-admin/attribute/index');

    }

    public function edit()
	{
        $this->cms_commoncontroller->logincheck(); 
		$id=$this->uri->segment(4);
		$data['form_action']='cms_attribute/edit_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/attribute/index/';
        $data['form_header']='Attribute Master Edit';
		$data['getdetials']=$this->my_model->getdetials($id);
        $data['getattribute']=$this->my_model->getattribute();  
		$this->cms_commoncontroller->commonLayoutView('attribute/edit',$data);

	}


    public function edit_post()
    {
        //print_r($this->input->post());
        $id=$this->input->post('id');
        $data['attribute_field_name_id']=$this->input->post('attribute_field_name_id');
        $data['value']=$this->input->post('value'); 
        $data['status']=$this->input->post('status');
        //print_r($data);
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/attribute/index');
     }
    public function delete()
    {
		$this->cms_commoncontroller->logincheck();
        $id=$this->uri->segment(4);
        $this->my_model->delete($id);
         redirect(base_url().'cms-admin/attribute/index');
    }

    public function add_attribute()
    {
        $data['attribute_edit']='cms-admin/attribute/attribute_edit/';
        $data['attribute_delete']='cms-admin/attribute/attribute_delete/';
        $id=$this->uri->segment(4);
        $data['form_action']='cms_attribute/attribute_save/';
        $data['form_method']='post';
        $data['form_cancel']='cms-admin/subcatagory/index/';
        $data['form_header']='Sub-Catagory Attribute';
        $data['attr_type']=$this->my_model->getattribute();
        $data['attributelist']=$this->my_model->attributelist($id);
        //$this->cms_commoncontroller->commonLayoutView('attribute/add_attribute',$data);
        $this->cms_commoncontroller->commonLayoutView('attribute/add_attribute',$data);
    }

    public function attribute_save()
    {
        if(isset($_POST)){//print_r($_POST);
            if($this->input->post('attributeCounter')>=1 or     
            ($this->input->post('attribute_1')<>'' && $this->input->post('attribute_type_1')<>'')){
                for($i=1;$i<=$this->input->post('attributeCounter');$i++){
                    $data['subcat_id']=$this->input->post('subcat_id');
                    $data['sequence_no']=$i;
                    $data['attribute']=$this->input->post('attribute_'.$i);
                    $data['attribute_type']=$this->input->post('attribute_type_'.$i);
                    $this->my_model->attribute_save($data);                
                }
            }
        }   
        //$data['subcat_id']=$this->input->post('subcat_id');
        //$data['attribute_type']=$this->input->post('attribute_type');
        //$data['attribute']=$this->input->post('attribute');
        //$data['status']=$this->input->post('status');
        //$this->my_model->attribute_save($data);
        redirect(base_url().'cms-admin/attribute/add_attribute/'.$this->input->post('subcat_id'));
    }
#####################################################################    
    public function updateAttribute(){      
        $id=$_REQUEST["id"];
        $data['attribute']=$_REQUEST["attribute"];
        $data['attribute_type']=$_REQUEST["attribute_type"];
        $this->my_model->update_attribute($data,$id);        
        echo 'Yo';
    }   
    public function deleteAttribute(){      
        $id=$_REQUEST["id"];
        $this->my_model->delete_attribute($id);
        echo 'Yo';
    }
#####################################################################
    public function attribute_delete()
    {
        $this->cms_commoncontroller->logincheck(); 
        $id=$this->uri->segment(4);
        $this->my_model->attribute_delete($id);  
        redirect(base_url().'cms-admin/attribute/add_attribute/'.$this->uri->segment(5));

    }

}