<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class corporate extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('corporate_model','my_model');
		$this->load->library('../controllers/commoncontroller');
	}
	public function index(){
		$viewData=array();
		$viewPath='corporate/index';
		$viewData['headerList']=$this->my_model->getCorporateHeaderList();
		$viewData['contentList']=$this->my_model->getCorporateContentList();
		$this->commoncontroller->commonLayoutView($viewPath,$viewData);
	}
}