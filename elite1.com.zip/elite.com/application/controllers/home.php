<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class home extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('home_model','my_model');
		$this->load->library('../controllers/commoncontroller');
	}
	public function index(){
		$data_banner['banner']=$this->my_model->getbanners();
		$data_banner['productListOnCat']='product/list/';
		$data_banner['storelocator_link']='storelocator/';
		$data_banner['product_link']='product/detail/';
		$data_banner['promotionalCatagoryList']=$this->my_model->getPromotionalCatagories();
		$data_banner['discountList']=$this->my_model->getDiscounts();
		$data_banner['MaxDiscount']=$this->my_model->getMAXDiscount();
		$data_banner['offerBanner']=$this->my_model->offerBaner();
		//////////////////////////////////////////////////////////////////	
		$data_featured['product_details']='product/detail/';
		$data_featured['featured']=$this->my_model->getfeatured();
		////////////////////////////////////////////////////////////////////
		$viewData['bannerView']='home/banner';
		$viewData['featuredView']='home/featured';
		$viewData['promotionView']='home/promotion';
		$viewData['bannerData']=$data_banner;
		$viewData['featuredData']=$data_featured;
		$viewData['promotionData']=array();
		$viewPath='home/index';
		$this->commoncontroller->commonLayoutView($viewPath,$viewData);
    }
}