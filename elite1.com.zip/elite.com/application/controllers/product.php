<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class product extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model','my_model');
		$this->load->library('../controllers/commoncontroller');
	}
	public function index(){
		$cat_id=$this->uri->segment(3);
		$sub_cat_id=$this->uri->segment(4);
		/////////////////////////////////////////////////
		$data_attribute['catlist']=$this->my_model->getAttributecatagories(0);
		$data_attribute['subcatlist']=$this->my_model->getAttributecatagories($cat_id);
		$data_attribute['attrlist']=$this->my_model->getAttributes($sub_cat_id);
		$data_attribute['attrValuelist']=$this->my_model->getAttributeValues($sub_cat_id);
		/////////////////////////////////////////////////
		if($sub_cat_id	>	0)	$data_product['list']=$this->my_model->getproducts($sub_cat_id,'scat');
		else 					$data_product['list']=$this->my_model->getproducts($cat_id,'cat');
		$data_product['product_details']='product/detail/';
		$viewData['attributeView']='product/attribute';
		$viewData['productListView']='product/productList';
		$viewData['attributeData']=$data_attribute;
		$viewData['productListData']=$data_product;
		$viewPath='product/index';
		$this->commoncontroller->commonLayoutView($viewPath,$viewData);
    }
	public function detail(){
		$id=$this->uri->segment(3);
		$data_product['detail']=$this->my_model->getproductdetail($id);
		$data_product['attribute']=$this->my_model->getproductAttributes($id);
		$data_product['attributeValue']=$this->my_model->getproductAttributeValues();
		$data_product['product_details']='product/detail/';
		$data_product['similar_list']=$this->my_model->getsimilar();
		$data_leftList['best_seller']=$this->my_model->getbestseller();
		$viewData['detailLeftView']='product/detailLeft';
		$viewData['productDetailView']='product/productDetail';
		$viewData['detailLeftData']=$data_leftList;
		$viewData['productDetailData']=$data_product;
		$viewPath='product/detail';
		$this->commoncontroller->commonLayoutView($viewPath,$viewData);
	}
	public function getSubCatagoryList(){
		$parent_id = $_REQUEST["parent_id"];
		$subcat=$this->my_model->getsubcatagories($parent_id);
		$msg='';
		 foreach ($subcat as $row){
            $msg.= '<li><input type="checkbox" id="sub_cat_<?=$subcat->id?>" 
            onclick="myFunctionAttributeGen('.$row->id.');" 
            id="'.$row->id.'" >'.$row->title.'</li>';
            
        }
        echo $msg;
	}
	public function getAttributeList(){
		$subcat_id = $_REQUEST["subcat_id"];
		$attrlist=$this->my_model->getAttributes($subcat_id);
		$attrValuelist=$this->my_model->getAttributeValues($subcat_id);
		$msg='';
		if(isset($attrlist)){foreach($attrlist as $attr){
				$msg.='
					<div class="box">
	                    <h1>'.$attr->attribute.'</h1>
	                    <ul class="FilmainMenu">
				';
			if(isset($attrValuelist)){foreach($attrValuelist as $attrVal){
	            if($attr->attribute_type_id==$attrVal->attribute_field_name_id){
					$msg.= '<li><input type="checkbox" id="attr_<?=$attrVal->id?>" 
	            onclick="myFunctionProguctListGen('.$attrVal->id.');">'.$attrVal->value.'</li>';
	        }}}
	        $msg.='
	        			</ul>
	                </div>
	        ';
    	}}
    	echo $msg;
	}
	/*public function getAttributeList(){
		$subcat_id = $_REQUEST["subcat_id"];
		$attrlist=$this->my_model->getAttributes($subcat_id);
		$attrValuelist=$this->my_model->getAttributeValues($subcat_id);
		$msg='';
		$prev = '';
		$cur = '';
		if(isset($attrlist)){foreach($attrlist as $attr){
			if($prev == ''){
				$msg.='
					<div class="box">
	                    <h1>'.$attr->attribute.'</h1>
	                    <ul class="FilmainMenu">
					';
				$cur = $attr->attribute_type;
				$prev = $attr->attribute_type;
			}
			$cur = $attr->attribute_type;
			if($prev != $cur ){
				$msg.='
						</ul>
	                </div>
					<div class="box">
	                    <h1>'.$attr->attribute.'</h1>
	                    <ul class="FilmainMenu">
				';
			}
			if(isset($attrValuelist)){foreach($attrValuelist as $attrVal){
	            if($attr->attribute_type_id==$attrVal->attribute_field_name_id){
					$msg.= '<li><input type="checkbox" id="attr_<?=$attrVal->id?>" 
	            onclick="myFunctionProguctListGen('.$attrVal->id.');">'.$attrVal->value.'</li>';
	        }}}
	        $msg.='
	        			</ul>
	                </div>
	        ';
    	}}
    	echo $msg;
	}*/
}