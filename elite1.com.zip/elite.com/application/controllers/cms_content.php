<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_content extends CI_Controller {
    public function __construct()
    {
        parent::__construct();  
        $this->load->library('form_validation');
        $this->load->model('cms_content_model','my_model');
        $this->load->library('../controllers/cms_commoncontroller');
    }
    public function index($page)
    {   //echo $page;   
		$this->cms_commoncontroller->logincheck();  
        $data['edit']='cms-admin/content/edit/';
        $data['delete']='cms-admin/content/delete/';
        $data['table_header']='Content List';
        $data['addNew']='cms-admin/content/addnew/';
        $this->session->unset_userdata('page');
        $this->session->set_userdata('page',$this->uri->segment(2));
        $data['list']=$this->my_model->getlist($page);
        $this->cms_commoncontroller->commonLayoutView('content/index',$data);       
    }
    public function edit()
    {
		$this->cms_commoncontroller->logincheck();
        $id=$this->uri->segment(4);
        $data['form_action']='cms_content/edit_post/';
        $data['form_method']='post';
        $data['form_cancel']='cms-admin/'.$this->session->userdata('page').'/index/';
        $data['page']=$this->input->post('page');
        $data['getdetials']=$this->my_model->getdetials($id);
        $data['form_header']='Content Edit';  
        $this->cms_commoncontroller->commonLayoutView('content/edit',$data);
    }     
     public function edit_post()
     {
        $id=$this->input->post('id');
        $data['sequence_no']=$this->input->post('sequence_no');
        $data['page']=$this->input->post('page');
        $data['header']=$this->input->post('header');
        $data['keyword']=$this->input->post('keyword'); 
        $data['description']=$this->input->post('description');
        $data['content']=$this->input->post('content');
        $data['status']=$this->input->post('status');
        if($_FILES['image']['tmp_name']){
            //-------------------------//
            $getdetials=$this->my_model->getdetials($id);
            $image='';
            foreach($getdetials as $d){
                $image='./uploads/content/'.$d->image;            
            }
            if(file_exists($image)){unlink($image);}
            //-------------------------//
            $file=$_FILES['image']['tmp_name'];
            $name=$data['page'].'_'.date('mdHis').$_FILES['image']['name'];
            if(move_uploaded_file($file, FILE_HARD_PATH.'content/'.$name)){                
                $data['image']=$name;                
            }
        }
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/'.$this->session->userdata('page').'/index');
     }
    public function delete()
    {
		$this->cms_commoncontroller->logincheck();
        $id=$this->uri->segment(4);
		//-------------------------//
            $getdetials=$this->my_model->getdetials($id);
            $image='';
            foreach($getdetials as $d){
                $image='./uploads/content/'.$d->image;            
            }
            if(file_exists($image)){unlink($image);}
        //-------------------------//
        $this->my_model->delete($id);
        redirect(base_url().'cms-admin/'.$this->session->userdata('page').'/index');
    }
    public function addnew()
    {
		$this->cms_commoncontroller->logincheck();
        $data['form_action']='cms_content/addnew_post/';
        $data['form_method']='post';
        $data['form_cancel']='cms-admin/'.$this->session->userdata('page').'/index/';
        $data['form_header']='Content Add New'; 
        $page='corporate';
        $data['sequence_no']=$this->my_model->count($this->session->userdata('page')); 

        $this->cms_commoncontroller->commonLayoutView('content/new',$data);
    }
    public function addnew_post()
     {
        //print_r($this->input->post());
        $data['header']=$this->input->post('header');
        $data['page']=$this->input->post('page');
        $data['sequence_no']=$this->input->post('sequence_no');
        $data['keyword']=$this->input->post('keyword');
        $data['description']=$this->input->post('description');
        $data['content']=$this->input->post('content');
        $data['status']=$this->input->post('status');
         if($_FILES['image']['tmp_name']){
            $file=$_FILES['image']['tmp_name'];
            $name=$data['page'].'_'.date('mdHis').$_FILES['image']['name'];
            if(move_uploaded_file($file, FILE_HARD_PATH.'content/'.$name)){                
                $data['image']=$name;                
            }
        }
        //print_r($data);
        $this->my_model->save($data);

        redirect(base_url().'cms-admin/'.$this->session->userdata('page').'/index');
     }
}
/* if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_content extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_content_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');

	}



	public function index()
	{
      
        $data['edit']='cms-admin/content/edit/';
        $data['delete']='cms-admin/content/delete/';
        $data['table_header']='Content List';
        $data['addNew']='cms-admin/content/addnew/';
		$data['list']=$this->my_model->getlist();
		$this->cms_commoncontroller->commonLayoutView('content/index',$data);
		
	}

	public function edit()
	{
		$id=$this->uri->segment(4);
		$data['form_action']='cms_content/edit_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/content/index/';
		$data['getdetials']=$this->my_model->getdetials($id);
		$data['form_header']='Content Edit';  
        $this->cms_commoncontroller->commonLayoutView('content/edit',$data);

	}

     
     public function edit_post()
     {
     	$id=$this->input->post('id');
        $data['header']=$this->input->post('header');
        $data['keyword']=$this->input->post('keyword'); 
        $data['description']=$this->input->post('description');
        $data['content']=$this->input->post('content');
        $data['status']=$this->input->post('status');
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/content/index');
     }


    public function delete()
    {
    	$id=$this->uri->segment(4);
    	$this->my_model->delete($id);
    	 redirect(base_url().'cms-admin/content/index');
    }


    public function addnew()
    {
        $data['form_action']='cms_content/addnew_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/content/index/';
		$data['form_header']='Content Add New';  
        $this->cms_commoncontroller->commonLayoutView('content/new',$data);
    }

    public function addnew_post()
     {
        //print_r($this->input->post());
        $data['header']=$this->input->post('header');
        $data['keyword']=$this->input->post('keyword'); 
        $data['description']=$this->input->post('description');
        $data['content']=$this->input->post('content');
        $data['status']=$this->input->post('status');
        //print_r($data);
        $this->my_model->save($data);
        redirect(base_url().'cms-admin/content/index');
     }

}*/