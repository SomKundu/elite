<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_catagory extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_catagory_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');

	}



	public function index()
	{
      	$this->cms_commoncontroller->logincheck();
        $data['edit']='cms-admin/catagory/edit/';
        $data['delete']='cms-admin/catagory/delete/';
        $data['table_header']='Category List';
        $data['addNew']='cms-admin/catagory/addnew/';
		$data['list']=$this->my_model->getlist();
		$this->cms_commoncontroller->commonLayoutView('catagory/index',$data);
		
	}

	public function edit()
	{
		$this->cms_commoncontroller->logincheck();
		$id=$this->uri->segment(4);
		$data['form_action']='cms_catagory/edit_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/catagory/index/';
        $data['form_header']='Category Edit';
		$data['getdetials']=$this->my_model->getdetials($id);
		$this->cms_commoncontroller->commonLayoutView('catagory/edit',$data);

	}

     
     public function edit_post()
     {
        //print_r($this->input->post());
        //print_r($_FILES);
     	$id=$this->input->post('id');
        $data=array();
        $data['title']=$this->input->post('title');
        $data['status']=$this->input->post('status'); 
        $data['parent_id']='0';
        $data['discount']=$this->input->post('discount'); 
        $data['home_link']=$this->input->post('home_link'); 
        if(isset($_FILES) && !empty($_FILES)){  
            $getdetials=$this->my_model->getdetials($id);
            if($_FILES['image']['tmp_name']){
                //-------------------------//
                //$getdetials=$this->my_model->getdetials($id);
                $image_old='';
                foreach($getdetials as $d){
                    $image_old='./uploads/catagory/'.$d->image;            
                }
                if(file_exists($image_old)){unlink($image_old);}
                //-------------------------//
                $file=$_FILES['image']['tmp_name'];
                $name=$data['title'].'_'.$id.date('mdHis').$_FILES['image']['name'];
                if(move_uploaded_file($file, FILE_HARD_PATH.'catagory/'.$name)){                
                    $data['image']=$name;                
                }
            }
            if($_FILES['prom_img']['tmp_name']){ 
                //-------------------------//
                //$getdetials=$this->my_model->getdetials($id);
                $prom_img_old='';
                foreach($getdetials as $d){
                    $prom_img_old='./uploads/prom_img/'.$d->prom_img;            
                }
                if(file_exists($prom_img_old)){unlink($prom_img_old);}
                //-------------------------//           
                $prom_img_file=$_FILES['prom_img']['tmp_name'];
                $prom_img_name=$data['title'].'_'.$id.date('mdHis').'_prom_img_'.$_FILES['prom_img']['name'];
                if(move_uploaded_file($prom_img_file, FILE_HARD_PATH.'prom_img/'.$prom_img_name) ){                 
                    $data['prom_img']=$prom_img_name;          
                }            
            }
        }
        /*if($_FILES['image']['tmp_name']){
            $file=$_FILES['image']['tmp_name'];
            $name=$_FILES['image']['name'];
            if(move_uploaded_file($file, FILE_HARD_PATH.'catagory/'.$name)){
                $data['title']=$this->input->post('title');
                $data['image']=$name;
                $data['status']=$this->input->post('status');
                $data['parent_id']='0'; 
                $data['discount']=$this->input->post('discount');
                }
        }else{
            $data['title']=$this->input->post('title');
            $data['status']=$this->input->post('status'); 
            $data['parent_id']='0'; 
            $data['discount']=$this->input->post('discount');
        }*/
        //print_r($data);
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/catagory/index');
     }


    public function delete()
    {
		$this->cms_commoncontroller->logincheck();
    	$id=$this->uri->segment(4);
		//-------------------------//
		$getdetials=$this->my_model->getdetials($id);
		$image='';
		$prom_img='';
		foreach($getdetials as $d){
			$image='./uploads/catagory/'.$d->image;            
			$prom_img='./uploads/prom_img/'.$d->prom_img;            
        }
        if(file_exists($prom_img)){unlink($prom_img);}
		if(file_exists($image)){unlink($image);}
		//-------------------------//
    	$this->my_model->delete($id);
    	redirect(base_url().'cms-admin/catagory/index');
    }


    public function addnew()
    {
		$this->cms_commoncontroller->logincheck();
        $data['form_action']='cms_catagory/addnew_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/catagory/index/';
        $data['form_header']='Category Add New';
		$this->cms_commoncontroller->commonLayoutView('catagory/new',$data);
    }

    public function addnew_post()
     {
        $data=array();
        $data['title']=$this->input->post('title');
        $data['status']=$this->input->post('status'); 
        $data['parent_id']='0';
        $data['discount']=$this->input->post('discount');
		$data['home_link']=$this->input->post('home_link'); 
		if(isset($_FILES) && !empty($_FILES)){  
			if($_FILES['image']['tmp_name']){
				$file=$_FILES['image']['tmp_name'];
				$name=$data['title'].'_'.$id.date('mdHis').$_FILES['image']['name'];
				if(move_uploaded_file($file, FILE_HARD_PATH.'catagory/'.$name)){                
					$data['image']=$name;                
				}
			}
			if($_FILES['prom_img']['tmp_name']){            
				$prom_img_file=$_FILES['prom_img']['tmp_name'];
				$prom_img_name=$data['title'].'_'.$id.date('mdHis').'_prom_img_'.$_FILES['prom_img']['name'];
				if(move_uploaded_file($prom_img_file, FILE_HARD_PATH.'prom_img/'.$prom_img_name) ){                 
					$data['prom_img']=$prom_img_name;                
				}            
			}
		}
        $this->my_model->save($data);
        redirect(base_url().'cms-admin/catagory/index');
     }

}