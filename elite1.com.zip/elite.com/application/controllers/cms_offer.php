<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_offer extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_offer_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');

	}



	public function index()
	{
     	$this->cms_commoncontroller->logincheck(); 
        $data['edit']='cms-admin/offer/edit/';
        $data['delete']='cms-admin/offer/delete/';
        $data['table_header']='Offer List';
        $data['addNew']='cms-admin/offer/addnew/';
		$data['list']=$this->my_model->getlist();
		$this->cms_commoncontroller->commonLayoutView('offer/index',$data);
		
	}


	public function edit()
	{
		$this->cms_commoncontroller->logincheck();
		$id=$this->uri->segment(4);
		$data['form_action']='cms_offer/edit_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/offer/index/';
        $data['form_header']='Offer Edit';
		$data['getdetials']=$this->my_model->getdetials($id);
		$this->cms_commoncontroller->commonLayoutView('offer/edit',$data);

	}
	public function edit_post()
     {
     	$id=$this->input->post('id');        
        $data=array();
		$data['status']=$this->input->post('status');
		$data['place']=$this->input->post('place');
        if($_FILES['image']['tmp_name']){
			//-------------------------//
			$getdetials=$this->my_model->getdetials($id);
			$image='';
			foreach($getdetials as $d){
				$image='./uploads/offer/'.$d->image;            
			}
			if(file_exists($image)){unlink($image);}
			//-------------------------//
            $file=$_FILES['image']['tmp_name'];
            $name=$_FILES['image']['name'];
            if(move_uploaded_file($file, FILE_HARD_PATH.'offer/'.$name)){
                $data['image']=$name;
                 
            }
        }
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/offer/index');
     }


    public function delete()
    {
		$this->cms_commoncontroller->logincheck();
    	$id=$this->uri->segment(4);
		//-------------------------//
        $getdetials=$this->my_model->getdetials($id);
        $image='';
        foreach($getdetials as $d){
            $image='./uploads/offer/'.$d->image;            
        }
        if(file_exists($image)){unlink($image);}
        //-------------------------//
    	$this->my_model->delete($id);
    	 redirect(base_url().'cms-admin/offer/index');
    }



    public function addnew()
    {
		$this->cms_commoncontroller->logincheck();
        $data['form_action']='cms_offer/addnew_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/offer/index/';
        $data['form_header']='Offer Add New';
		$this->cms_commoncontroller->commonLayoutView('offer/new',$data);
    }

    public function addnew_post()
     {
        $data=array();
        if($_FILES['image']['tmp_name']){
            $file=$_FILES['image']['tmp_name'];
            $name=$_FILES['image']['name'];
            if(move_uploaded_file($file, FILE_HARD_PATH.'offer/'.$name)){
                $data['image']=$name;
                $data['status']=$this->input->post('status'); 
				$data['place']=$this->input->post('place'); 
            }
        }
        $this->my_model->save($data);
        redirect(base_url().'cms-admin/offer/index');
     }


}
