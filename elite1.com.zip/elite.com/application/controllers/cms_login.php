<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_login  extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_login_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');
	}


	public function index(){
		$data['header'] = ' Login';
		$data['form_action']='cms_login/login_post/';
		$data['form_method']='post';
		$this->cms_commoncontroller->commonLayoutView('login/bodycontent',$data); 
	}

	public function logout(){
		$this->my_model->adddate_time($this->session->userdata('login_id'),'logout');
		$this->session->unset_userdata('login_id');
		$this->session->unset_userdata('username');	
		$this->session->unset_userdata('usertitle');
		$this->session->unset_userdata('adminPriority');
		$this->session->unset_userdata('login_data');
		$this->session->unset_userdata('current_url');
   		$this->session->sess_destroy();
		redirect(base_url().'cms-admin/login/index');
	}


	public function login_post()
	{	
		$data['username']=$this->input->post('username');
		$data['password']=$this->input->post('password');
        $result=$this->my_model->login_check($data);
		//die;
		if(empty($result))	redirect(base_url().'cms-admin/login/index');
		else{	//echo 'not';
			//if($this->session->userdata('login_error')<>'')$this->session->unset_userdata('login_error');
			foreach($result as $u){	
				$this->session->set_userdata('login_id',$u->id);
				$this->session->set_userdata('usertitle',$u->usertitle);	
				$this->session->set_userdata('username',$u->username);				
				$this->session->set_userdata('login_data','y');
				$this->session->set_userdata('adminPriority',$u->priority);	
			}
			$this->my_model->adddate_time($this->session->userdata('login_id'),'login');
			if($this->session->userdata('current_url'))
				redirect($this->session->userdata('current_url'));
			else
				redirect(base_url().'cms-admin/');
		}
	}


}