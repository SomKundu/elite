<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_subcatagory extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_subcatagory_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');

	}



	public function index()
	{      
		$this->cms_commoncontroller->logincheck();
        $data['edit']='cms-admin/subcatagory/edit/';
        $data['delete']='cms-admin/subcatagory/delete/';
        $data['table_header']='Sub-Category List';
        $data['addNew']='cms-admin/subcatagory/addnew/';
    ###############################################################
        $data['attribute']='cms-admin/attribute/add_attribute/';
    ###############################################################
        //$data['attribute']='cms-admin/attribute/addnew/';
		$data['list']=$this->my_model->getlist();   
        $data['getcatagories']=$this->my_model->getcatagories();
		$this->cms_commoncontroller->commonLayoutView('subcatagory/index',$data);
		
	}

	public function edit()
	{
		$this->cms_commoncontroller->logincheck();
		$id=$this->uri->segment(4);
		$data['form_action']='cms_subcatagory/edit_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/subcatagory/index/';
        $data['form_header']='Sub-Category Edit';
		$data['getdetials']=$this->my_model->getdetials($id);   
        $data['getcatagories']=$this->my_model->getcatagories();
		$this->cms_commoncontroller->commonLayoutView('subcatagory/edit',$data);

	}

     
     public function edit_post()
     {
     	$id=$this->input->post('id');
        $data=array();
        $data['title']=$this->input->post('title');
        $data['status']=$this->input->post('status');
        $data['parent_id']=$this->input->post('parent_id'); 
        $data['discount']=$this->input->post('discount');
        $getdetials=$this->my_model->getdetials($id);
        if($_FILES['image']['tmp_name']){
            //-------------------------//
            $image_old='';
            foreach($getdetials as $d){
                $image_old='./uploads/catagory/'.$d->image;            
            }
            if(file_exists($image_old)){unlink($image_old);}
            //-------------------------//
            $file=$_FILES['image']['tmp_name'];
            $name=$data['title'].'_'.$id.date('mdHis').$_FILES['image']['name'];
            if(move_uploaded_file($file, FILE_HARD_PATH.'catagory/'.$name)){
                $data['image']=$name;
            }
        }
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/subcatagory/index');
     }


    public function delete()
    {
		$this->cms_commoncontroller->logincheck();
    	$id=$this->uri->segment(4);
		//-------------------------//
		$getdetials=$this->my_model->getdetials($id);
		$image='';
		foreach($getdetials as $d){
			$image='./uploads/catagory/'.$d->image;            
		}
		if(file_exists($image)){unlink($image);}
		//-------------------------//
    	$this->my_model->delete($id);
    	 redirect(base_url().'cms-admin/subcatagory/index');
    }


    public function addnew()
    {
		$this->cms_commoncontroller->logincheck();
        $data['form_action']='cms_subcatagory/addnew_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/subcatagory/index/'; 
        $data['form_header']='Sub-Category Add New';       
        $data['getcatagories']=$this->my_model->getcatagories();
		$this->cms_commoncontroller->commonLayoutView('subcatagory/new',$data);
    }

    public function addnew_post()
     {
        $data=array();
		$data['title']=$this->input->post('title');
		$data['parent_id']=$this->input->post('parent_id'); 
		$data['discount']=$this->input->post('discount');
		$data['status']=$this->input->post('status'); 
		if(isset($_FILES) && !empty($_FILES)){ 
			if($_FILES['image']['tmp_name']){
				$file=$_FILES['image']['tmp_name'];
				$name=$_FILES['image']['name'];
				if(move_uploaded_file($file, FILE_HARD_PATH.'catagory/'.$name)){
					$data['image']=$name;
				}
			}
		}
        $this->my_model->save($data);
        redirect(base_url().'cms-admin/subcatagory/index');
     }

}