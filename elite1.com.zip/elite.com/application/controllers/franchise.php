<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class franchise extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('franchise_model','my_model');
		$this->load->library('../controllers/commoncontroller');
	}
	public function index(){
		$viewData=array();
		$viewPath='franchise/index';
		$viewData['form_action']='franchise/submit/';
		$viewData['form_method']='post';
		$this->commoncontroller->commonLayoutView($viewPath,$viewData);
	}
	public function submit(){
		//print_r($this->input->post());
		//print_r($_FILES);
		$data=array();
		//Array ( [fname] => m [mname] => N [lname] => Kundu [dob] => 08/15/2015 [address] => sdf sfsdf sdfsdf [phone] => 234234 [mobile] => w3e4234 [fax] => 54654756 [email] => somenath.kundu@keevestechnologies.com [qualification] => Graduate [exp_years] => 3 [exp_months] => 6 [work_exp_detail] => zfdsfds sdfsd fsd sdfsf [city] => Kolkata [locality] => Baguiati [located_in] => New market [any_other_brand_nearly] => Na [parking_facility] => Yes [proposed_locality] => College [other_proposed_locality] => Na [size_sq_ft] => 567 [frontage_ft] => 5 [height_ft] => 12 [investment] => 50000 [owned_rented] => Below 30 Lacs [lease_years] => Na [reason_investment] => Na [funds_source] => Personal funds [owning_business] => Yes [franchise_business] => Yes [franchise_info] => Na [investment_in_month] => 5 )
		$data['fname']=$this->input->post('fname');
		$data['mname']=$this->input->post('mname');
		$data['lname']=$this->input->post('lname');
		$data['sex']=$this->input->post('sex');
		$data['dob']=$this->input->post('dob');
		$data['address']=$this->input->post('address');
		$data['phone']=$this->input->post('phone');
		$data['mobile']=$this->input->post('mobile');
		$data['fax']=$this->input->post('fax');
		$data['email']=$this->input->post('email');
		$data['qualification']=$this->input->post('qualification');		
		$data['exp_years']=$this->input->post('exp_years');
		$data['exp_months']=$this->input->post('exp_months');
		$data['work_exp_detail']=$this->input->post('work_exp_detail');
		$data['city']=$this->input->post('city');
		$data['locality']=$this->input->post('locality');
		$data['located_in']=$this->input->post('located_in');
		$data['any_other_brand_nearly']=$this->input->post('any_other_brand_nearly');
		$data['parking_facility']=$this->input->post('parking_facility');
		$data['proposed_locality']=$this->input->post('proposed_locality');
		$data['other_proposed_locality']=$this->input->post('other_proposed_locality');
		$data['size_sq_ft']=$this->input->post('size_sq_ft');
		$data['frontage_ft']=$this->input->post('frontage_ft');
		$data['height_ft']=$this->input->post('height_ft');
		$data['investment']=$this->input->post('investment');
		$data['owned_rented']=$this->input->post('owned_rented');
		$data['lease_years']=$this->input->post('lease_years');
		$data['reason_investment']=$this->input->post('reason_investment');
		$data['funds_source']=$this->input->post('funds_source');
		$data['owning_business']=$this->input->post('owning_business');
		$data['franchise_business']=$this->input->post('franchise_business');
		$data['franchise_info']=$this->input->post('franchise_info');
		$data['investment_in_month']=$this->input->post('investment_in_month');
		/*
		 if($_FILES['ulocfile']['tmp_name']){
            $file=$_FILES['ulocfile']['tmp_name'];
            $name=$data['fname'].'_'.date('mdHis').'_'.$_FILES['ulocfile']['name'];
            if(move_uploaded_file($file, FILE_HARD_PATH.'franchise/'.$name)){
                $data['ulocfile']=$name;
            }
        }*/
		$data['ulocfile']='';
		for($i=0;$i < count($_FILES['ulocfile'] ['name']);$i++){
			if($_FILES['ulocfile']['tmp_name'][$i]){
				$file_path=$_FILES['ulocfile']['tmp_name'][$i];
				$file_name=$_FILES['ulocfile']['name'][$i];
				if(move_uploaded_file($file_path, FILE_HARD_PATH.'franchise/'.$file_name)){
					$data['ulocfile'].=$file_name;
				}
			}
		}
		$this->my_model->insert($data);
        redirect(base_url());
	}
}