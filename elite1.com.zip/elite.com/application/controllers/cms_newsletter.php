<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_newsletter extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_newsletter_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');

	}

	public function index()
	{ 
        $this->cms_commoncontroller->logincheck();
        $data['edit']='cms-admin/newsletter/edit/';
        $data['delete']='cms-admin/newsletter/delete/';
        $data['table_header']='Newsletter List';
        $data['addNew']='cms-admin/newsletter/addnew/';
		$data['list']=$this->my_model->getlist();
        $data['emailList']=$this->my_model->email();
		$this->cms_commoncontroller->commonLayoutView('newsletter/index',$data);
		
	}
	public function addnew()
    {
        $this->cms_commoncontroller->logincheck();
        $data['form_action']='cms_newsletter/addnew_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/newsletter/index/';
		$data['form_header']='newsletter Add New';
        $data['email']=$this->my_model->email();  
        $this->cms_commoncontroller->commonLayoutView('newsletter/new',$data);
    }
    
    public function addnew_post()
    {
        //print_r($this->input->post());
    	$data['title']=$this->input->post('title'); 
        $data['date_of_publish']=$this->input->post('date_of_publish');
        $data['repeat']=$this->input->post('repeat');                  
        $data['desc']=$this->input->post('desc');
        //$data['send_list']=$this->input->post('send_list');
        $data['send_list']='';	
        for($i=0;$i<count($this->input->post('send_list'));$i++){
            $data['send_list'].=$this->input->post('send_list')[$i].'|';
        }           
        $data['status']=$this->input->post('status');   
        //print_r($data); 
        $this->my_model->save($data);
        redirect(base_url().'cms-admin/newsletter/index');
    }

    public function edit()
    {
        $this->cms_commoncontroller->logincheck();
        $id=$this->uri->segment(4);
        $data['form_action']='cms_newsletter/edit_post/';
        $data['form_method']='post';
        $data['form_cancel']='cms-admin/newsletter/index/';
        $data['email_edit']=$this->my_model->email();  
        $data['getdetials']=$this->my_model->getdetials($id);
        $data['form_header']='Newsletter Edit';  
        $this->cms_commoncontroller->commonLayoutView('newsletter/edit',$data);

    }
     
    public function edit_post()
    { 
        //print_r($this->input->post());
        $id=$this->input->post('id');    
    	$data['title']=$this->input->post('title'); 
        $data['date_of_publish']=$this->input->post('date_of_publish');
        $data['repeat']=$this->input->post('repeat');                  
        $data['desc']=$this->input->post('desc');
        $data['send_list']='';  
        for($i=0;$i<count($this->input->post('send_list'));$i++){
            $data['send_list'].=$this->input->post('send_list')[$i].'|';
        }      
        $data['status']=$this->input->post('status');    
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/newsletter/index');
    }

    public function delete()
    {
		$this->cms_commoncontroller->logincheck();
    	$id=$this->uri->segment(4);
    	$this->my_model->delete($id);
    	redirect(base_url().'cms-admin/newsletter/index');
    }
    
}


  
