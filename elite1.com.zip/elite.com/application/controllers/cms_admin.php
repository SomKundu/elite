<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('cms_admin_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');
	}
	public function index(){
		$this->cms_commoncontroller->logincheck();
		$data=array();
		$data['product_list']='cms-admin/product/index/';
		$data_side['comment_list']='cms-admin/comment/index/';
		$this->cms_commoncontroller->commonLayoutView('admin/index',$data); 
	}
}