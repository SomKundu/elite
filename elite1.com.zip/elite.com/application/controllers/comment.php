<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class comment extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('comment_model','my_model');
    }
    public function index(){
        $data['name']=$this->input->post('name');
        //$data['first_name']=$this->input->post('first_name');
        //$data['last_name']=$this->input->post('last_name'); 
        $data['phone_no']=$this->input->post('phone_no');
        $data['email_id']=$this->input->post('email_id');     
        $data['Comments']=$this->input->post('Comments');   
        $url=$this->input->post('current_url');     
        $this->my_model->save($data);
        redirect($url);
       
    }
    
}