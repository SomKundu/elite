<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class newsletter extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('newsletter_model','my_model');
	}
	public function index(){
		$curUrl=$this->input->post("curUrl");
		$arrData=$this->input->post("email");
   		$this->my_model->add_email($arrData); 
   		redirect($curUrl);
	}
	
}