<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class content extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('content_model','my_model');
		$this->load->library('../controllers/commoncontroller');
	}
	public function index(){
		$content_id=$this->uri->segment(2);
		$viewPath='content/index';
		$viewData['data']=$this->my_model->getcontent($content_id);
		$this->commoncontroller->commonLayoutView($viewPath,$viewData);
	}
}