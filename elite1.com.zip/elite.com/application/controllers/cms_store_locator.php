<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_store_locator extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_store_locator_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');

	}

	public function index()
	{ 
        $this->cms_commoncontroller->logincheck();
        $data['edit']='cms-admin/store_locator/edit/';
        $data['delete']='cms-admin/store_locator/delete/';
        $data['table_header']='Store Locator List';
        $data['addNew']='cms-admin/store_locator/addnew/';
		$data['list']=$this->my_model->getlist();
		$this->cms_commoncontroller->commonLayoutView('store_locator/index',$data);
		
	}
	  public function addnew()
    {
        $this->cms_commoncontroller->logincheck();
        $data['form_action']='cms_store_locator/addnew_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/store_locator/index/';
		$data['form_header']='Store Locator Add New';  
        $this->cms_commoncontroller->commonLayoutView('store_locator/new',$data);
    }
      public function addnew_post()
       {
        	$data['storecode']=$this->input->post('storecode'); 
	        $data['store_name']=$this->input->post('store_name');
	        $data['address']=$this->input->post('address');                  
	        $data['city']=$this->input->post('city');
	        $data['district']=$this->input->post('district'); 
	        $data['state']=$this->input->post('state');
	        $data['zip']=$this->input->post('zip');
	        $data['lat']=$this->input->post('lat');
	        $data['lng']=$this->input->post('lng');      
	        $data['status']=$this->input->post('status');    
	        $this->my_model->save($data);
	        redirect(base_url().'cms-admin/store_locator/index');
        }
     public function edit()
	  {
        $this->cms_commoncontroller->logincheck();
		$id=$this->uri->segment(4);
		$data['form_action']='cms_store_locator/edit_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/store_locator/index/';
		$data['getdetials']=$this->my_model->getdetials($id);
		$data['form_header']='Store Locator Edit';  
        $this->cms_commoncontroller->commonLayoutView('store_locator/edit',$data);

	   }
     
     public function edit_post()
     { 
        $id=$this->input->post('id');    
    	$data['storecode']=$this->input->post('storecode'); 
        $data['store_name']=$this->input->post('store_name');
        $data['address']=$this->input->post('address');                  
        $data['city']=$this->input->post('city');
        $data['district']=$this->input->post('district'); 
        $data['state']=$this->input->post('state');
        $data['zip']=$this->input->post('zip');
        $data['lat']=$this->input->post('lat');
        $data['lng']=$this->input->post('lng');      
        $data['status']=$this->input->post('status');    
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/store_locator/index');
     }

    public function delete()
    {
		$this->cms_commoncontroller->logincheck();
    	$id=$this->uri->segment(4);
    	$this->my_model->delete($id);
    	redirect(base_url().'cms-admin/store_locator/index');
    }
}


  
