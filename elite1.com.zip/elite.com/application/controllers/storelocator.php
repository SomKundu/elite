<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class storelocator extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('storelocator_model','my_model');
		$this->load->library('../controllers/commoncontroller');
	}
	public function index(){
		//$this->load->view('store_locator/storelocator');
		$viewData=array();
		$viewPath='storelocator/index';
		$store_locator['getState']=$this->my_model->get_State();
		$store_locator['storeLocation']=json_encode($this->my_model->getStoreLocationMarker());
		$viewData=$store_locator;
	   	$this->commoncontroller->commonLayoutView($viewPath,$viewData);
	}
	public function getAllStotre(){
    	$get_location = $this->my_model->get_State(); 
    	echo json_encode($get_location);
    }

	public function get_selected_dist(){
		$state=$_REQUEST["select_state"];
		//echo $state;
		$get_dist = $this->my_model->get_State_Dist($state); 
		$msg='<option value="">---District / City---</option>';
        foreach ($get_dist as $row){ 
          $msg.='<option value="'.$row->district.'">'.$row->district.'</option>';
        }             	          
        echo $msg;
	}
	
	public function get_selected_town(){
		$dist=$_REQUEST["select_dist"];
		$get_town = $this->my_model->get_State_Town($dist);
		$msg='<option value="">---Town / Market---</option>';
        foreach ($get_town as $row){ 
          $msg.='<option value="'.$row->city.'">'.$row->city.'</option>';
        }             	          
        echo $msg;
	}
	public function get_location_points(){
		$town=$_REQUEST["select_town"];
		$storeLocation=json_encode($this->my_model->getStoreLocationMarker($town));
		echo $storeLocation;
	}
}