<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class commoncontroller extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('commoncontroller_model','my_model');
	}
	public function commonLayoutView($viewPath,$viewData){
		$data_header=array();
		$data_footer=array();
		$data_header['product_list']='product/list/';
		$data_header['storelocator_link']='storelocator/';
		$data_header['corporate_link']='corporate/';
		$data_header['media_link']='media/';
		$data_header['joinus_link']='joinus/';
		$data_header['franchise_link']='franchise/';
		
		$data_header['cat_list']=$this->my_model->getcatagories();
		$data_header['sub_cat_list']=$this->my_model->getsubcatagories();
		/////////////////////////////////////////////////////////////////
		$data_footer['storelocator_link']='storelocator/';
		$data_footer['newsletter_link']='newsletter/';
		$data_footer['content_management_link']='content/';		
		$data_footer['comment_link']='comment/';
		$data_footer['get_content']=$this->my_model->footer_link();
		/////////////////////////////////////////////////////////////////		
		$this->load->view('layout/headertop',$data_header);		
		if($this->uri->segment(1)==''||$this->uri->segment(1)=='home'){}
		else{$this->load->view('layout/breadcrumb');}
	    /////////////////////////////////////////////////////////////////
	    $this->load->view($viewPath,$viewData);
	    /////////////////////////////////////////////////////////////////
		$this->load->view('layout/footer',$data_footer);
	}
}