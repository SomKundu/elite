<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_jobseeker extends CI_Controller {
    public function __construct()
    {
        parent::__construct();  
        $this->load->library('form_validation');
        $this->load->model('cms_jobseeker_model','my_model');
        $this->load->library('../controllers/cms_commoncontroller');
    }


    public function index()
    { 
        $this->cms_commoncontroller->logincheck();
        $data['edit']='cms-admin/jobseeker/edit/';        
        $data['table_header']='jobseeker List';        
        $data['list']=$this->my_model->getlist();        
        $this->cms_commoncontroller->commonLayoutView('jobseeker/index',$data);
        
    }   
    
    
    public function edit()
    {
        $this->cms_commoncontroller->logincheck();
        $id=$this->uri->segment(4);
        $data['form_action']='cms_jobseeker/edit_post/';
        $data['form_method']='post';
        $data['form_cancel']='cms-admin/jobseeker/index/';        
        $data['getdetials']=$this->my_model->getdetials($id);
        $data['form_header']='jobseeker Edit';  
        $this->cms_commoncontroller->commonLayoutView('jobseeker/edit',$data);
    }  

   

    
}


  
