<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class joinus extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('joinus_model','my_model');
		$this->load->library('../controllers/commoncontroller');
	}
	public function index(){
		$viewData=array();
		$viewPath='joinus/index';
		$viewData['form_action']='joinus/submit/';
		$viewData['form_method']='post';
		$this->commoncontroller->commonLayoutView($viewPath,$viewData);
	}
	public function submit(){
		//print_r($this->input->post());
		//print_r($_FILES);
		$data=array();
		//Array ( [email] => somenath.kundu@keevestechnologies.com [fname] => m [mname] => [lname] => Kundu [dob] => 08/01/2015 [phone] => 9012345678 [mobile] => [state] => Alaska [country] => 28 [address] => dsasdasdsadsadsada [qualification] => 0 [other_qualification] => [exp_years] => 0 [exp_months] => 0 [relevant_exp_years] => 0 [relevant_exp_months] => 0 [cvText] => ) Array ( [cvfile] => Array ( [name] => sfz_progress_13-Aug.txt [type] => text/plain [tmp_name] => C:\xampp\tmp\phpD316.tmp [error] => 0 [size] => 341 ) )
		$data['email']=$this->input->post('email');
		$data['fname']=$this->input->post('fname');
		$data['mname']=$this->input->post('mname');
		$data['lname']=$this->input->post('lname');
		$data['sex']=$this->input->post('sex');
		$data['dob']=$this->input->post('dob');
		$data['phone']=$this->input->post('phone');
		$data['mobile']=$this->input->post('mobile');
		$data['state']=$this->input->post('state');
		$data['country']=$this->input->post('country');
		$data['address']=$this->input->post('address');
		$data['qualification']=$this->input->post('qualification');
		$data['other_qualification']=$this->input->post('other_qualification');
		$data['exp_years']=$this->input->post('exp_years');
		$data['exp_months']=$this->input->post('exp_months');
		$data['relevant_exp_years']=$this->input->post('relevant_exp_years');
		$data['relevant_exp_months']=$this->input->post('relevant_exp_months');
		$data['cvText']=$this->input->post('cvText');
		 if($_FILES['cvfile']['tmp_name']){
            $file=$_FILES['cvfile']['tmp_name'];
            $name=$data['fname'].'_'.date('mdHis').'_'.$_FILES['cvfile']['name'];
            if(move_uploaded_file($file, FILE_HARD_PATH.'career/'.$name)){
                $data['cvfile']=$name;
                
            }
        }
		$this->my_model->insert($data);
        redirect(base_url());
	}
}