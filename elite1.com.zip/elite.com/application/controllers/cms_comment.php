<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_comment extends CI_Controller {
    public function __construct()
    {
        parent::__construct();  
        $this->load->library('form_validation');
        $this->load->model('cms_comment_model','my_model');
        $this->load->library('../controllers/cms_commoncontroller');
    }


    public function index()
    { 
        $this->cms_commoncontroller->logincheck();
        $data['edit']='cms-admin/comment/edit/';        
        $data['table_header']='comment List';        
        $data['list']=$this->my_model->getlist();        
        $this->cms_commoncontroller->commonLayoutView('comment/index',$data);
        
    }   
    
    
    public function edit()
    {
        $this->cms_commoncontroller->logincheck();
        $id=$this->uri->segment(4);
        $data['form_action']='cms_comment/edit_post/';
        $data['form_method']='post';
        $data['form_cancel']='cms-admin/comment/index/';        
        $data['getdetials']=$this->my_model->getdetials($id);
        $data['form_header']='comment Edit';  
        $this->cms_commoncontroller->commonLayoutView('comment/edit',$data);
    }  

   

    
}


  
