<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_franchise extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_franchise_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');
	}


	public function index()
	{ 
        $this->cms_commoncontroller->logincheck();
        $data['edit']='cms-admin/franchise/edit/';        
        $data['table_header']='Franchise List';        
		$data['list']=$this->my_model->getlist();        
		$this->cms_commoncontroller->commonLayoutView('franchise/index',$data);
		
	}	
    
    
    public function edit()
    {
        $this->cms_commoncontroller->logincheck();
        $id=$this->uri->segment(4);
        $data['form_action']='cms_franchise/edit_post/';
        $data['form_method']='post';
        $data['form_cancel']='cms-admin/franchise/index/';        
        $data['getdetials']=$this->my_model->getdetials($id);
        $data['form_header']='Franchise Edit';  
        $this->cms_commoncontroller->commonLayoutView('franchise/edit',$data);
    }  

   

    
}


  
