<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms_product extends CI_Controller {
	public function __construct()
	{
		parent::__construct();	
		$this->load->library('form_validation');
		$this->load->model('cms_product_model','my_model');
		$this->load->library('../controllers/cms_commoncontroller');

	}



	public function index()
	{
		$this->cms_commoncontroller->logincheck();
        if($this->session->userdata('step1_data'))
            $this->session->unset_userdata('step1_data'); 
        if($this->session->userdata('step2_data'))
            $this->session->unset_userdata('step2_data'); 
        if($this->session->userdata('step3_data'))
            $this->session->unset_userdata('step3_data'); 
        $data['edit']='cms-admin/product/edit/';
        $data['delete']='cms-admin/product/delete/';
        $data['table_header']='Product List';		
		$data['addNew']='cms-admin/product/addnew/0/detail/';
		$data['list']=$this->my_model->getlist();
        $data['getcatagories']=$this->my_model->getsubcatagories();
		$this->cms_commoncontroller->commonLayoutView('product/index',$data);
		
	}
/*
	public function edit()
	{
		$id=$this->uri->segment(4);
		$data['form_action']='cms_product/edit_post/';
		$data['form_method']='post';
        $data['form_cancel']='cms-admin/product/index/';
        $data['form_header']='Product Edit';	
		$data['getdetials']=$this->my_model->getdetials($id);
        $data['getsubcatagories']=$this->my_model->getsubcatagories();
		$this->cms_commoncontroller->commonLayoutView('product/edit',$data);

	}

     
     public function edit_post()
     {
     	$id=$this->input->post('id');
         //print_r($this->input->post());
        $data['title']=$this->input->post('title');
        $data['code']=$this->input->post('code'); 
        $data['sub_cat_id']=$this->input->post('sub_cat_id');
        $data['details']=$this->input->post('details');
        $data['quick_overview']=$this->input->post('quick_overview');
        $data['general_info']=$this->input->post('general_info');
        $data['occession']=$this->input->post('occession');
        $data['material']=$this->input->post('material');
        $data['maintainance']=$this->input->post('maintainance');
        $data['price']=$this->input->post('price');
        $data['status']=$this->input->post('status');
        $data['meta_tag']=$this->input->post('meta_tag');
        $data['meta_description']=$this->input->post('meta_description');
        $data['meta_content']=$this->input->post('meta_content');
        $data['discount']=$this->input->post('discount');
        $data['availablity']=$this->input->post('availablity');
        $data['new_arrivals']=$this->input->post('new_arrivals');
        $data['Offer_of_the_day']=$this->input->post('Offer_of_the_day');
        $data['best_seller']=$this->input->post('best_seller');
        $data['weekly_offer']=$this->input->post('weekly_offer');
        $data['special_discount']=$this->input->post('special_discount');
        $data['featured']=$this->input->post('featured');
        for($i=1;$i<9;$i++){
            if($_FILES['image'.$i]['tmp_name']){
                $file=$_FILES['image'.$i]['tmp_name'];
                $ext=explode('.',$_FILES['image'.$i]['name']);
                $name=$this->input->post('code').$i.'_'.date('mdHis').'.'.$ext[1];
                if(move_uploaded_file($file, FILE_HARD_PATH.'product/'.$name)){
                    $data['image'.$i]=$name;               
                }
            }
        }
        $this->my_model->update($id,$data);
        redirect(base_url().'cms-admin/product/index');
     }

*/
    public function delete()
    {
		$this->cms_commoncontroller->logincheck();
    	$id=$this->uri->segment(4);
        $getdetial=$this->my_model->getdetials($id);
        //----------------------------//
        $image1='';
        $image2='';
        $image3='';
        $image4='';
        $image5='';
        $image6='';
        $image7='';
        $image8='';
        if(isset($getdetial)){
          foreach($getdetial as $d){
            $id=$d->id;
            $image1='./uploads/product/'.$d->image1;
            $image2='./uploads/product/'.$d->image2;
            $image3='./uploads/product/'.$d->image3;
            $image4='./uploads/product/'.$d->image4;
            $image5='./uploads/product/'.$d->image5;
            $image6='./uploads/product/'.$d->image6;
            $image7='./uploads/product/'.$d->image7;
            $image8='./uploads/product/'.$d->image8;
          }
        }
        if(file_exists($image1)){unlink($image1);}
        if(file_exists($image2)){unlink($image2);}
        if(file_exists($image3)){unlink($image3);}
        if(file_exists($image4)){unlink($image4);}
        if(file_exists($image5)){unlink($image5);}
        if(file_exists($image6)){unlink($image6);}
        if(file_exists($image7)){unlink($image7);}
        if(file_exists($image8)){unlink($image8);}
        //----------------------------//
        $this->my_model->delete($id);
        $this->my_model->delAttribute($id);

    	redirect(base_url().'cms-admin/product/index');
    }


    public function entry()
    {
        $id=$this->uri->segment(4);
        $viewPath='cms_admin/';
        $data['step1']=$viewPath.'product/new_step1';
        $data['step2']=$viewPath.'product/new_step2';
        $data['step3']=$viewPath.'product/new_step3';
        $step1_data['form_action']='cms_product/step1_post/';
        $step1_data['form_method']='post';
        $step1_data['form_cancel']='cms-admin/product/index/';
        $step1_data['form_header']='Product Initial & Image';    
        ////////////////////////////////////////////////////////// 
        $step3_data['form_action']='cms_product/step3_post/';
        $step3_data['form_method']='post';
        $step3_data['form_cancel']='cms-admin/product/index/';
        $step3_data['form_header']='Product Attributes';  
        //////////////////////////////////////////////////////////// 
        $step2_data['form_action']='cms_product/step2_post/';
        $step2_data['form_method']='post';
        $step2_data['form_cancel']='cms-admin/product/index/';
        $step2_data['form_header']='Product Details Entry';
        $data['step1_data']=$step1_data;
        $data['step2_data']=$step2_data;
        $data['step3_data']=$step3_data;
        $data['getcatagories']=$this->my_model->getcatagories();
        $data['getsubcatagories']=$this->my_model->getsubcatagories();
        $data['attributeNameMaster']=$this->my_model->getAttributeNameMaster();
        $data['attributeSelecttionMaster']=$this->my_model->getAttributeSelecttionMaster();
        if($id>0){
            $data['getdetials']=$this->my_model->getdetials($id);
            $data['productAttributeValue']=$this->my_model->getProductAttributeValue($id);
            $data['attributes']=$this->my_model->getAttribute($id);
        }
		$this->cms_commoncontroller->commonLayoutView('product/entry',$data);
    }
    public function step1_post()
    {
        $data['title']=$this->input->post('title');
        $data['brand_text']=$this->input->post('brand_text');
        $data['code']=$this->input->post('code'); 
        $data['cat_id']=$this->input->post('cat_id');
        $data['sub_cat_id']=$this->input->post('sub_cat_id');
##########################################################################
        for($i=1;$i<9;$i++){
            if($_FILES['image'.$i]['tmp_name']){
                $file=$_FILES['image'.$i]['tmp_name'];
                $ext=explode('.',$_FILES['image'.$i]['name']);
                $name=$data['code'].$i.'_'.date('mdHis').'.'.$ext[1];
                if(move_uploaded_file($file, FILE_HARD_PATH.'product/'.$name)){
                    $data['image'.$i]=$name;               
                }
            }
        }
##########################################################################
        $product_id='';
        if($this->input->post('id')==0){
            $this->my_model->save($data);
            $product_id=$this->db->insert_id();
        }
        if($this->input->post('id')>0){
            $this->my_model->update($this->input->post('id'),$data);
            $product_id=$this->input->post('id');
        }
        redirect(base_url().'cms-admin/product/edit/'.$product_id.'/content');
    }
    /*        
        
    */
    public function step2_post()
    {   //print_r($this->input->post());
        $data=array();
        $data['details']=$this->input->post('details');
        $data['quick_overview']=$this->input->post('quick_overview');
        $data['general_info']=$this->input->post('general_info');
        $data['occession']=$this->input->post('occession');
        $data['material']=$this->input->post('material');
        $data['maintainance']=$this->input->post('maintainance');
        $data['price']=$this->input->post('price');
        $data['status']=$this->input->post('status');
        $data['meta_tag']=$this->input->post('meta_tag');
        $data['meta_description']=$this->input->post('meta_description');
        $data['meta_content']=$this->input->post('meta_content');
        $data['discount']=$this->input->post('discount');
        $data['availablity']=$this->input->post('availablity');
        $data['new_arrivals']=$this->input->post('new_arrivals');
        $data['Offer_of_the_day']=$this->input->post('Offer_of_the_day');
        $data['best_seller']=$this->input->post('best_seller');
        $data['weekly_offer']=$this->input->post('weekly_offer');
        $data['special_discount']=$this->input->post('special_discount');
        $data['featured']=$this->input->post('featured');
             
        $product_id='';
        if($this->input->post('id')>0){
            $this->my_model->update($this->input->post('id'),$data);
            $product_id=$this->input->post('id');
        }

        redirect(base_url().'cms-admin/product/edit/'.$product_id.'/attr');
    }
    public function step3_post()
    {
        $data=array();
        $attributes=array();
        if($this->input->post('sub_cat_id')>0)
        $attributes=$this->my_model->getAttribute($this->input->post('sub_cat_id'));
        foreach($attributes as $a){
            $data[$a->id]=$this->input->post($a->id);
        }
        $this->session->set_userdata('step2_data',$data);        
        $product_id='';
        if($this->input->post('id')>0)
        $product_id=$this->input->post('id');
        $this->my_model->delAttribute($product_id);//echo 'deleted';
        $attributes=$this->my_model->getAttribute($product_id);
        foreach($attributes as $as){
            $save['product_id']=$product_id;
            $save['attribute_id']=$as->id;
            $save['attribute_value']=$this->input->post($as->id);
            $this->my_model->saveAttribute($save);
        }
        redirect(base_url().'cms-admin/product/index');
    }
	/*
    public function addnew_post()
    {
        //print_r($this->input->post()); 
        $data['title']=$this->input->post('title');
        $data['code']=$this->input->post('code'); 
        $data['sub_cat_id']=$this->input->post('sub_cat_id');
        $data['details']=$this->input->post('details');
        $data['quick_overview']=$this->input->post('quick_overview');
        $data['general_info']=$this->input->post('general_info');
        $data['occession']=$this->input->post('occession');
        $data['material']=$this->input->post('material');
        $data['maintainance']=$this->input->post('maintainance');
        $data['price']=$this->input->post('price');
        $data['status']=$this->input->post('status');
        $data['meta_tag']=$this->input->post('meta_tag');
        $data['meta_description']=$this->input->post('meta_description');
        $data['meta_content']=$this->input->post('meta_content');
        $data['discount']=$this->input->post('discount');
        $data['availablity']=$this->input->post('availablity');
        $data['new_arrivals']=$this->input->post('new_arrivals');
        $data['Offer_of_the_day']=$this->input->post('Offer_of_the_day');
        $data['best_seller']=$this->input->post('best_seller');
        $data['weekly_offer']=$this->input->post('weekly_offer');
        $data['special_discount']=$this->input->post('special_discount');
        $data['featured']=$this->input->post('featured');
        for($i=1;$i<9;$i++){
            if($_FILES['image'.$i]['tmp_name']){
                $file=$_FILES['image'.$i]['tmp_name'];
                $ext=explode('.',$_FILES['image'.$i]['name']);
                $name=$this->input->post('code').$i.'_'.date('mdHis').'.'.$ext[1];
                if(move_uploaded_file($file, FILE_HARD_PATH.'product/'.$name)){
                    $data['image'.$i]=$name;               
                }
            }
        }
        $this->my_model->save($data);
        redirect(base_url().'cms-admin/product/index');
    } 
	*/
    public function getAttribute(){
        $subcat_id=$_REQUEST["subcat_id"];
        $attributes=$this->my_model->getAttribute($subcat_id);
        //print_r($attributes);
        echo json_encode($attributes);
    }

}