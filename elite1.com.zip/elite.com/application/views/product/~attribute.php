<?php //print_r($attrlist);?>
<?php //print_r($attrValuelist);?>


  <div class="SectionOuter SubpageWrap">
  	<div class="SectionInner">
    	<div class="SidebarLeft">
        	<div class="SectionTitleBar">
            	<div class="TitleIcon FilterIcon"></div>
                <div class="TitleTxt">
                	Filter By
                </div>
            </div>
        	<div class="ProFilterMenu">
            	<div class="box">
                	<h1>CATEGORY</h1>
                    <ul class="FilmainMenu">
                        <?php if(isset($catlist)){foreach($catlist as $cat){?>
<li><label for="women"><input type="checkbox" name="cat_attr" id="cat_<?=$cat->id?>" 
onChange="myFunctionSubCatGen('<?=$cat->id?>')" 
<?=($this->uri->segment(3)==$cat->id)?'checked':''?>>
 <?=$cat->title?></label></li>
                        <?php }}?>
                    </ul>
                </div>
                <div class="box">
                	<h1>Occassions</h1>
                    <ul class="FilmainMenu" id="sub_cat_div">
                        <?php if(isset($subcatlist)){foreach($subcatlist as $subcat){?>
<li><label for="comfort"><input type="checkbox" name="subcat_attr" id="sub_cat_<?=$subcat->id?>" 
onChange="myFunctionAttributeGen('<?=$subcat->id?>');"
<?=($this->uri->segment(4)==$subcat->id)?'checked':''?>>
 <?=$subcat->title?></label></li>
                        <?php }}?>
                    </ul>
                </div>
<!-------------------------------- dynamic attribute listing starts ------------------------------>  
<div id="attr_div">  
<?php if(isset($attrlist)){foreach($attrlist as $attr){?>
                <div class="box">
                    <h1><?=$attr->attribute?></h1>
                    <ul class="FilmainMenu">
                    <?php $i=0;if(isset($attrValuelist)){foreach($attrValuelist as $attrVal){
                        if($attr->attribute_type_id==$attrVal->attribute_field_name_id){$i++;?>
<li <?=($i==1)?'class=""':''?>><label for="exclude-stock"><input type="checkbox" id="<?=$attrVal->id?>" >
<?=$attrVal->value?></label></li>
                    <?php }}}?>
                    </ul>
                </div>
<?php }}?>
</div>
<!-------------------------------- dynamic attribute listing starts ------------------------------>     
<?php /* ?>          
                <div class="box FilterSize">
                	<h1>Size</h1>
                    <ul>
                    	<li>5</li>
                        <li>6</li>
                        <li>7</li>
                        <li>8</li>
                        <li>9</li>
                        <li>10</li>
                    </ul>
                </div>
                <div class="box">
                	<h1>Offers</h1>
                    <ul class="FilmainMenu">
                    	<li class=""><label for="discounts"><input type="checkbox" id="discounts" > Discounts</label></li>
                        <li><label for="combo-Offer"><input type="checkbox" id="combo-Offer"> Combo-Offer</label></li>
                        <li><label for="seasonal-discount"><input type="checkbox" id="seasonal-discount"> Seasonal Discount</label></li>
                    </ul>
                </div>
                <div class="box">
                	<h1>Brand</h1>
                    <ul class="FilmainMenu">
                    	<li class=""><label for="a2-by-Aerosoles"><input type="checkbox" id="a2-by-Aerosoles" > A2 by Aerosoles</label></li>
                        <li><label for="adidas"><input type="checkbox" id="adidas"> Adidas</label></li>
                        <li><label for="aerosoles"><input type="checkbox" id="aerosoles"> Aerosoles</label></li>
                    </ul>
                </div>
                <div class="box FilterColor">
                	<h1>Color</h1>
                    <ul class="">
                    	<li style="background:#e4322c;"></li>
                        <li style="background:#202020;"></li>
                        <li style="background:#e5e5e5;"></li>
                        <li style="background:#ffd800;"></li>
                        <li style="background:#66b710;"></li>
                    </ul>
                </div>
                
                <div class="box">
                	<h1>Availability</h1>
                    <ul class="FilmainMenu">
                    	<li class=""><label for="exclude-stock"><input type="checkbox" id="exclude-stock" > Exclude Out of Stock</label></li>
                    </ul>
                </div>
                <div class="box">
                	<h1>Price</h1>
                    <ul>
                    	<li class=""><label for="exclude-stock"><input type="checkbox" id="exclude-stock" > Exclude Out of Stock</label></li>
                    </ul>
                </div>
<?php */ ?>                
<!-------------------------------------------------------------------------------->                
            </div>
        </div>
<script>
function myFunctionSubCatGen(param){//alert(param); 
   $.ajax({
       url : '<?=base_url()?>product/getSubCatagoryList/',
       type : "POST",
       data : { 'parent_id' : param},
       success(data){alert(data);
            $('#sub_cat_div').html(data);
            //$('#cat_'+param).attr('checked');
        }
    });
}  
function myFunctionAttributeGen(param){alert(param); 
   $.ajax({
       url : '<?=base_url()?>product/getAttributeList/',
       type : "POST",
       data : { 'subcat_id' : param},
       success(data){alert(data); 
         $('#attr_div').html(data);
        }
    });
}  
</script>