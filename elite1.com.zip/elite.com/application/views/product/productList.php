        <div class="PageRight PageRM">
        	<div class="SectionTitleBar">
            	<div class="TitleIcon Box4Icon"></div>
                <div class="TitleTxt">
                	Filtered Product List
                </div>
            </div>
            <div class="ProBoxWrapWrap">
        	<?php foreach($list as $l){?>
                <div class="ProBoxWrap">
                    <div class="PBWIn">
                        <div class="ProImgDivH">
                            <div class="ProImgDivV">
                                <img src="<?=base_url()?>uploads/product/<?=$l->image1?>" alt=""/> 
                            </div>
                        </div>
                        <div class="ProInfo">
                            <h1 class="ProName"><?=$l->title?></h1>
                            <div class="ProPrice">
                                <?php if($l->discount<>''){?>
                                <span class="OldPrice"><?=((((int)($l->discount)/100)*(int)($l->price))+(int)($l->price))?></span>
                                <?php }?>
                                <span class="NewPrice"><?=$l->price?></span>
                            </div>
                            <!--<div class="ReviewRate">
                                <span><a href="#"><img src="<?=base_url()?>assets/images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                                <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                            </div>-->
                            <div class="ViewDeBtn">
                                <a href="<?=base_url().$product_details.$l->id?>" class="ViewBTN">View details</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php }?>            

            </div>
           <div class="clr"></div>
            
        </div>
    </div>
  </div>
