<?php
//$this->load->view($breadcrumbView,$breadcrumbData);
$this->load->view($attributeView,$attributeData);
$this->load->view($productListView,$productListData);