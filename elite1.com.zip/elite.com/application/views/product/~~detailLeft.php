  <div class="SectionOuter SubpageWrap">
    <div class="SectionInner">
      <div class="SidebarLeft">
        
        <div class="ProFilterMenu NoBorder">
            <!--<div class="box NoBorder CatMenu SingleBox">
                <div class="SectionTitleBar">
                  <div class="TitleIcon CAtListIcon"></div>
                  <div class="TitleTxt"> Category </div>
                </div>
                <ul>
                    <li><a href="#">Men</a></li>
                    <li><a href="#">Women</a></li>
                    <li><a href="#">Kids</a></li>
                    <li><a href="#">Juniors</a></li> 
                </ul>
              </div>-->
            <div class="box NoBorder BestSellPro SingleBox">
                <div class="SectionTitleBar">
                  <div class="TitleIcon BestSellIcon"></div>
                  <div class="TitleTxt">  Bestseller </div>
                </div>
                <ul class="BeSelinfo">
                    <?php foreach($best_seller as $d){?>
                    <li>
                        <div class="BeSeProimg">
                        <?php if($d->image1<>'' && file_exists('./uploads/product/'.$d->image1)){?>
                        <a href="#"><img src="<?=base_url().'uploads/product/'.$d->image1?>" alt="" style=""/></a>
                        <?php }?>
                        </div>
                        <div class="BeSelinfo">
                            <h1 class="ProTitle"><?=$d->title?></h1>
                            <div class="PriceLab">&nbsp;<?=$d->price?></div>
                            <p><?=substr($d->meta_description,0,80)?>...</p>
                        </div> 
                        <div class="clr"></div>
                    </li>
                    <?php }?>
                    <!--<li>
                        <div class="BeSeProimg"><img src="<?=base_url()?>assets/images/sellimgpro.png" alt=""/></div>
                        <div class="BeSelinfo">
                            <h1 class="ProTitle">SHIRT "LOLO" BAG</h1>
                            <div class="PriceLab">$999.99</div>
                            <p>Lorem ipsum dolor sit amet, con sec tetur adipisicing elit, sed do...</p>
                        </div>
                        <div class="clr"></div>
                    </li>
                    <li>
                        <div class="BeSeProimg"><img src="<?=base_url()?>assets/images/sellimgpro.png" alt=""/></div>
                        <div class="BeSelinfo">
                            <h1 class="ProTitle">SHIRT "LOLO" BAG</h1>
                            <div class="PriceLab">$999.99</div>
                            <p>Lorem ipsum dolor sit amet, con sec tetur adipisicing elit, sed do...</p>
                        </div>
                        <div class="clr"></div>
                    </li>
                    <li>
                        <div class="BeSeProimg"><img src="<?=base_url()?>assets/images/sellimgpro.png" alt=""/></div>
                        <div class="BeSelinfo">
                            <h1 class="ProTitle">SHIRT "LOLO" BAG</h1>
                            <div class="PriceLab">$999.99</div>
                            <p>Lorem ipsum dolor sit amet, con sec tetur adipisicing elit, sed do...</p>
                        </div>
                        <div class="clr"></div>
                    </li>
                    <li>
                        <div class="BeSeProimg"><img src="<?=base_url()?>assets/images/sellimgpro.png" alt=""/></div>
                        <div class="BeSelinfo">
                            <h1 class="ProTitle">SHIRT "LOLO" BAG</h1>
                            <div class="PriceLab">$999.99</div>
                            <p>Lorem ipsum dolor sit amet, con sec tetur adipisicing elit, sed do...</p>
                        </div>
                        <div class="clr"></div>
                    </li>
                    <li>
                        <div class="BeSeProimg"><img src="<?=base_url()?>assets/images/sellimgpro.png" alt=""/></div>
                        <div class="BeSelinfo">
                            <h1 class="ProTitle">SHIRT "LOLO" BAG</h1>
                            <div class="PriceLab">$999.99</div>
                            <p>Lorem ipsum dolor sit amet, con sec tetur adipisicing elit, sed do...</p>
                        </div>
                        <div class="clr"></div>
                    </li>-->
                </ul>
              </div>
              
        </div>
      </div>