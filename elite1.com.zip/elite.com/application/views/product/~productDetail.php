<?php 
$id='';
$title='';
$code='';
$sub_cat_id='';
$details='';
$quick_overview='';
$general_info='';
$occession='';
$material='';
$maintainance='';
$price='';
$status='';
$meta_tag='';
$meta_description='';
$meta_content='';
$discount='';
$availablity='';
$new_arrivals='';
$Offer_of_the_day='';
$best_seller='';
$weekly_offer='';
$special_discount='';
$featured='';
$image1='';
$image2='';
$image3='';
$image4='';
$image5='';
$image6='';
$image7='';
$image8='';
foreach($detail as $d){
    $id=$d->id;
    $title=$d->title;
    $code=$d->code; 
    $sub_cat_id=$d->sub_cat_id;
    $details=$d->details;
  $quick_overview=$d->quick_overview;
  $general_info=$d->general_info;
  $occession=$d->occession;
  $material=$d->material;
  $maintainance=$d->maintainance;
    $price=$d->price;
    $status=$d->status;
    $meta_tag=$d->meta_tag; 
    $status=$d->status;
    $meta_description=$d->meta_description;
    $meta_content=$d->meta_content;
    $discount=$d->discount;
    $availablity=$d->availablity;
    $new_arrivals=$d->new_arrivals;
    $Offer_of_the_day=$d->Offer_of_the_day;
    $best_seller=$d->best_seller;
    $weekly_offer=$d->weekly_offer;
    $special_discount=$d->special_discount;
  $featured=$d->featured;
    $image1=$d->image1;
    $image2=$d->image2;
    $image3=$d->image3;
    $image4=$d->image4;
    $image5=$d->image5;
    $image6=$d->image6;
    $image7=$d->image7;
    $image8=$d->image8;

}
//print_r($attribute);
//echo '<br>';
//print_r($attributeValue);
?>
<style type="text/css">
.Active{background:#FF0000 !important;}
</style>
      <div class="PageRight">
        <div class="ProDetails">
            <h1 class="ProDTitle"><?=$title?></h1>
            <div class="">
<?php ##################################################################################### ?>
            <div class="ProDImgWrap">
            <div class="cfix">
              <div class="cfix"> <a href="<?=base_url()?>uploads/product/<?=$image1?>" class="jqzoom" rel='gal1'  title="triumph" > 
              <img src="<?=base_url()?>uploads/product/<?=$image1?>"  title="triumph"  style="border: 1px solid #ececec;"> </a> </div>
              <br/>
              <div class="clearfix" >
                <ul id="thumblist" class="clearfix" >
                  
<?php if($image1<>''){?>
<li><a class="zoomThumbActive" href='javascript:void(0);' 
  rel="{gallery: 'gal1', smallimage: '<?=base_url()?>uploads/product/<?=$image1?>',largeimage: '<?=base_url()?>uploads/product/<?=$image1?>'}">
  <img src='<?=base_url()?>uploads/product/<?=$image1?>' width="100" /></a>
</li>                
<?php }?>
<?php if($image2<>''){?>
<li><a href='javascript:void(0);' 
  rel="{gallery: 'gal1', smallimage: '<?=base_url()?>uploads/product/<?=$image2?>',largeimage: '<?=base_url()?>uploads/product/<?=$image2?>'}">
  <img src='<?=base_url()?>uploads/product/<?=$image2?>' width="100" /></a>
</li>              
<?php }?>
<?php if($image3<>''){?>
<li><a href='javascript:void(0);' 
  rel="{gallery: 'gal1', smallimage: '<?=base_url()?>uploads/product/<?=$image3?>',largeimage: '<?=base_url()?>uploads/product/<?=$image3?>'}">
  <img src='<?=base_url()?>uploads/product/<?=$image3?>' width="100" /></a>
</li>                
<?php }?>
<?php if($image4<>''){?>
<li><a href='javascript:void(0);' 
  rel="{gallery: 'gal1', smallimage: '<?=base_url()?>uploads/product/<?=$image4?>',largeimage: '<?=base_url()?>uploads/product/<?=$image4?>'}">
  <img src='<?=base_url()?>uploads/product/<?=$image4?>' width="100" /></a>
</li>              
<?php }?> 
<?php if($image5<>''){?>
<li><a href='javascript:void(0);' 
  rel="{gallery: 'gal1', smallimage: '<?=base_url()?>uploads/product/<?=$image5?>',largeimage: '<?=base_url()?>uploads/product/<?=$image5?>'}">
  <img src='<?=base_url()?>uploads/product/<?=$image5?>' width="100" /></a>
</li>                
<?php }?>
<?php if($image6<>''){?>
li><a href='javascript:void(0);' 
  rel="{gallery: 'gal1', smallimage: '<?=base_url()?>uploads/product/<?=$image6?>',largeimage: '<?=base_url()?>uploads/product/<?=$image6?>'}">
  <img src='<?=base_url()?>uploads/product/<?=$image6?>' width="100" /></a>
</li>              
<?php }?>                                
                </ul>
              </div>
            </div>
          </div>
<?php ##################################################################################### ?>          
            <!--<div class="ProDImgWrap">
            <div class="cfix">
              <div class="cfix"> <a href="<?=base_url()?>assets/imgProd/triumph_big1.jpg" class="jqzoom" rel='gal1'  title="triumph" > 
              <img src="<?=base_url()?>assets/images/triumph_small1.png"  title="triumph"  style="border: 1px solid #ececec;"> </a> </div>
              <br/>
              <div class="clearfix" >
                <ul id="thumblist" class="clearfix" >
                  <li> <a class="zoomThumbActive" href='javascript:void(0);' 
                  rel="{gallery: 'gal1', smallimage: '<?=base_url()?>assets/imgProd/triumph_small1.jpg',largeimage: '<?=base_url()?>assets/imgProd/triumph_big1.jpg'}">
                  <img src='<?=base_url()?>assets/imgProd/thumbs/triumph_thumb1.jpg' width="100" /></a> </li>
                  <?php for($i=1;$i<=7;$i++){?>
                  <li> <a  href='javascript:void(0);' 
                  rel="{gallery: 'gal1', smallimage: '<?=base_url()?>uploads/product/<?=$image1?>',largeimage: '<?=base_url()?>uploads/product/<?=$image1?>'}">
                  <img src='<?=base_url()?>uploads/product/<?=$image1?>' width="100" /></a> </li>
                  <?php }?>
                  
                </ul>
              </div>
            </div>
          </div>-->
<?php ##################################################################################### ?>
            <div class="ProInfoDetail">
            <div class="OfferTag"><?php if($discount<>''){?><img src="<?=base_url()?>assets/images/offer-tag.png"  alt=""/><?php }?></div>
            <?php foreach($attribute as $attr){?>
              <?php if($attr->input_status=='check' && ($attr->attribute=='price' || $attr->attribute=='Price')){?>
                <div class="PriceRow">
                  <label>Price:</label><span class="NowPrice"><?=$attr->attribute_value?></span>
                  <?php if($discount<>''){?>
                    <span class="OldPrice">
                      <?=((((int)($discount)/100)*(int)($price))+(int)($price))?>
                    </span>
                  <?php }?>
                </div>
              <?php }?>
              <?php if($attr->input_status=='color'){?>
                <div class="pdRow">
                  <label>Availabile Color:</label>
                  <ul class="Acolor">
                      <li style="background: #<?=$attr->attribute_value?>;"></li>
                  </ul>
                </div>
              <?php }?>
              <?php if($attr->input_status=='select' && ($attr->attribute=='Size' || $attr->attribute=='Size')){?>
                <div class="pdRow SizeWrap">
                <label>Size:</label>
                <ul>
                <?php foreach($attributeValue as $attrVal){
                  if($attrVal->attribute_field_name_id==$attr->attribute_field_id){?>                  
                    <li <?php /*?><?=($attrVal->id==$attr->attribute_value)?'class="Active"':''?><?php */?>><?=$attrVal->value?></li>
                <?php }}?>
                </ul>
            </div>
              <?php }?>
            <?php }?>            
            <div class="pdRow">
              <label>Availability:</label>
              <span class="PStock"><?=($availablity=='y')?'In stock':'Out of stock'?></span>
            </div>

            <div class="pdRow">
              <label>QUICK OVERVIEW:</label>
                <?=$quick_overview?>
            </div>
            <!--<div class="pdRow review">
                <p>Be the first to review this product</p>
                <a href="#">2 Review(s)</a>&nbsp;  |  &nbsp;<a href="#">Write Your Review</a>
            </div>-->
            <!--<div class="pdRow SizeWrap">
                <label>Size:</label>
                <ul>
                    <li>5</li>
                    <li>6</li>
                    <li>7</li>
                    <li>8</li>
                    <li>9</li>
                    <li>10</li>
                </ul>
            </div>-->
            <!--<div class="pdRow">
              <label>Availability:</label>
              <span class="PStock"><?=($availablity=='y')?'In stock':'Out of stock'?></span>
            </div>-->
            <!--<div class="pdRow">
              <label>Availabile Color:</label>
              <ul class="Acolor">
                    <li style="background:#e4322c;"></li>
                    <li style="background:#202020;"></li>
                    <li style="background:#e5e5e5;"></li>
                    <li style="background:#ffd800;"></li>
                    <li style="background:#66b710;"></li>
                </ul>
            </div>-->
            <!--<div class="pdRow">
              <label>Product Code:</label>
              <ul class="Acolor">
                <li style="background:#66b710;"></li>
              </ul>
            </div>-->
            <!--<div class="pdRow">
              <label>QUICK OVERVIEW:</label>
                <?=$quick_overview?>
            </div>-->
          </div>
          
          </div>
          <div class="ProDesc1">
            <div class="container1">            
                <?php if($details){?>
                  <h2>Product Description</h2>
                  <?=$details?>    
                <?php }if($general_info){?>
                  <h2>General Info</h2>
                  <?=$general_info?>   
                <?php }if($occession){?>
                <h2>Occession</h2>
                <?=$occession?> 
                <?php }if($material){?>               
                  <h2>Material</h2>
                  <?=$material?>
                <?php }if($maintainance){?>
                  <h2>Maintainance</h2>
                  <?=$maintainance?>
                <?php }?>
                </div>
          </div>
          <div class="RelatedPro">
            <ul id="flexiselDemo1"> 
                <?php foreach($similar_list as $l){?>
                <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="<?=base_url().$product_details.$l->id?>"><img src="<?=base_url()?>uploads/product/<?=$l->image1?>" width="150" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName"><?=$l->title?></span>
                        <span class="ProCat">Catrgory: <?=$l->subcatagory?></span>
                        <span class="ProBtn"><a href="<?=base_url().$product_details.$l->id?>">View Details</a></span>    
                    </div>
                </div>
                </li>
                <?php }?>
            <!--<li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="<?=base_url()?>assets/images/pro-item2.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>-->                                                         
        </ul>
          </div>
          <div class="clr"></div>
        </div>
        <div class="clr"></div>
      </div>
    </div>
  </div>
