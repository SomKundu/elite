<?php
//$this->load->view($breadcrumbView,$breadcrumbData);
$this->load->view($detailLeftView,$detailLeftData);
$this->load->view($productDetailView,$productDetailData);