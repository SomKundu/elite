<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script>
$(function() {
	$( "#datepicker" ).datepicker();
});
</script>
<style>
.JoinEmpoye { padding:10px; border: #F3F3F3 thin solid; margin: 0 0 20px 0;}
.JoinEmpoye .FRow { width:100%; padding:10px 0; }
.JoinEmpoye .FRow .FRowSec { width:30%; float:left; margin:0 1.5% 0 0}
.JoinEmpoye .FRow .FRowSec label { padding-bottom:5px; display:block;}
.JoinEmpoye .FRow .FRowSec label span{ font-size: small;}
.exp_select{ max-width:48% !important;float:left; margin:0 1.5% 0 0;}

</style>

<div class="SectionOuter SubpageWrap">
    <div class="SectionInner">
        <!--####################################################-->
        <form action="<?=base_url().$form_action?>" method="<?=$form_method?>" enctype="multipart/form-data">
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>First Name :</label>
                    <input  name="fname" type="text"  id="fname"  />
                </div>
                <div class="FRowSec">
                    <label>Middle Name ( Optional ) :</label>
                    <input name="mname" type="text"  id="mname"  />
                </div>
                <div class="FRowSec">
                    <label>Last Name :</label>
                    <input  name="lname" type="text"  id="lname"  />
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>Gender  :</label>
                    <select  name="sex"   >
                        <option value="m">Male</option>
                        <option value="f">Female</option>
                    </select>
                </div>
                <div class="FRowSec">
                    <label>Date of Birth :</label>
                    <input  name="dob" type="text"  id="datepicker" />
                </div>
                <div class="FRowSec">
                	<label>Address Line :</label>
                    <textarea  name="address" id="address"></textarea>
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>Phone :</label>
                    <input  name="phone" type="text"  id="phone"  />
                </div>
                <div class="FRowSec">
                    <label>Mobile ( Optional ) :</label>
                    <input name="mobile" type="text"  id="mobile"  />
                </div>
                <div class="FRowSec">
                    <label>Fax ( Optional ) :</label>
                    <input name="fax" type="text"  id="fax"  />
                    
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>Email :</label>
                    <input name="email" type="email"  id="email"  />
                </div>
                <div class="FRowSec">
                                      
                </div>
                <div class="FRowSec">                
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>Qualification :</label>
                    <select  name="qualification" id="qualification" multiple>
<option value="0">- Select Qualification -</option>
<option value="Undergraduate">Undergraduate</option>
<option value="Graduate">Graduate</option>
<option value="Post Graduate">Post Graduate </option>
                    </select>
                </div>
                <div class="FRowSec">
                    <label style="display:block;">Work Experience  :</label>
                    <select name="exp_years" id="exp_years" class="exp_select">
<option value="0">Select Year/s</option>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
                    </select>
                    <select name="exp_months" id="exp_months" class="exp_select">
<option value="0" selected="selected">0 Months</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
                    </select>
                </div>
                <div class="FRowSec">
                    <label style="display:block;">Work Experience Details : <span>[ If in business, please indicate nature of business, no of years in business]</span></label>
                    <textarea  name="work_exp_detail" id="work_exp_detail"></textarea>  
                    
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>City / Town :</label>
                    <input name="city" type="text"  id="city"  />
                </div>
                <div class="FRowSec">
                    <label>Locality :</label>
                    <input name="locality" type="text"  id="locality"  />
                </div>
                <div class="FRowSec">
                    <label>Shop Located in :</label>
                    <select  name="located_in" id="located_in" >
<option value="0">- Select Shop Location -</option>
<option value="Established Market">Established Market</option>
<option value="New market">New market</option>
<option value="Residential Market">Residential Market</option>
<option value="Commercial Basement">Commercial Basement</option>
<option value="Commercial Ground Floor">Commercial Ground Floor</option>
<option value="Commercial First Floor">Commercial First Floor</option>
                    </select>                      
                </div>
                <div class="clr"></div>
            </div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>Any other brands nearby :</label>
                    <input name="any_other_brand_nearly" type="text"  id="any_other_brand_nearly"  />
                </div>
                <div class="FRowSec">
                    <label>Parking facility :</label>
                    <input name="parking_facility" type="text"  id="parking_facility"  />
                </div>
                <div class="FRowSec">
                     <label>What is the consumer profile of the proposed locality :</label>
                     <select  name="proposed_locality" id="proposed_locality">
<option value="0">- Select Proposed Locality -</option>
<option value="High income">High income</option>
<option value="Middle income residential area">Middle income residential area</option>
<option value="College">College</option>
<option value="School students">school students</option>
                    </select>   
                </div>
                <div class="clr"></div>
            </div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>Any other :</label>
                    <input name="other_proposed_locality" type="text"  id="other_proposed_locality"  />
                </div>
                <div class="FRowSec">
                </div>
                <div class="FRowSec">
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>Size in Sq. Ft (area) :</label>
                    <input name="size_sq_ft" type="text"  id="size_sq_ft"  />
                </div>
                <div class="FRowSec">
                    <label>Frontage (in ft) :</label>
                    <input name="frontage_ft" type="text"  id="frontage_ft"  />
                </div>
                <div class="FRowSec">
                    <label>Ceiling Height (in ft.) :</label>
                    <input  name="height_ft" type="text"  id="height_ft"  />
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>Proposed capital investment:  Rs  :</label>
                    <input  name="investment" type="text"  id="investment"  />
                </div>
                <div class="FRowSec">
                    <label>Is the property owned or rented :</label>
                    <select  name="owned_rented" id="owned_rented"  >
<option value="0">- Owned or Rented -</option>
<option value="Owned">Owned</option>
<option value="Rented">Rented</option>                    	
                    </select>
                </div>
                <div class="FRowSec">
                	<label>If rented for how many years is the lease :</label>
                    <input  name="lease_years" type="text"  id="lease_years"  />
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        	<div class="FRow">
                <div class="FRowSec">
                    <label>Reasons for your interest in this business  :</label>
                    <textarea  name="reason_investment" id="reason_investment"></textarea>
                </div>
                <div class="FRowSec">
                    <label>Please indicate the amount of funds <span>that you are willing to invest, should you be awarded this franchise (please tick)</span></label>
                    <select  name="owned_rented" id="owned_rented"  >
<option value="0">- Owned or Rented -</option>
<option value="Below  30 Lacs">Below  30 Lacs</option>
<option value="30-45 Lacs">30-45 Lacs</option>
<option value="45 – 50 Lacs">45 – 50 Lacs</option>
<option value="50 lacs & Above">50 lacs & Above</option>                    	
                    </select>
                </div>
                <div class="FRowSec">
                	<label>What is the source of funds indicated above?<span> (Please tick)</span></label>
                    <select  name="funds_source" id="funds_source"  >
<option value="0">- Owned or Rented -</option>
<option value="Personal funds">Personal funds</option>
<option value="Bank Loan">Bank Loan</option>
<option value="Both">Both</option>                    	
                    </select>
                </div>
                <div class="clr"></div>
            </div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>Will you be otherwise employed while owning this business :</label>
                    <select  name="owning_business" id="owning_business"  >
<option value="0">- Owning Business -</option>
<option value="Yes">Yes</option>
<option value="No">No</option>
					</select>
                </div>
                <div class="FRowSec">
                    <label>Do you own any other franchise business</label>
                    <select  name="franchise_business" id="franchise_business"  >
<option value="0">- Franchise Business -</option>
<option value="Yes">Yes</option>
<option value="No">No</option>
					</select>
                </div>
                <div class="FRowSec">
                	<label>If yes, which franchise</label>
                    <textarea  name="franchise_info" id="franchise_info"></textarea>
                </div>
                <div class="clr"></div>
            </div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>How soon do you intend to invest in ELITE :<span>(in Months)</span></label>
                    <input  name="investment_in_month" type="text"  id="investment_in_month"  />
                </div>
                <div class="FRowSec">
                </div>
                <div class="FRowSec">
                </div>
                <div class="clr"></div>
            </div>
            
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
        <p>Kindly enclose 2 – 3 photographs of the proposed shop from various angles, the entrance, and the road leading to the shop and nearby market / surrounding area. If not than kindly sketch out the same for better understanding of the proposed location</p>
            <div class="FRow">
                <div class="FRowSec">
                    <label>File Upload :</label>
                    <input type="file" id="ulocfile[]" name="ulocfile[]" multiple />
                </div>
                <div class="FRowSec">
                </div>
                <div class="FRowSec">
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
        	<div class="FRow">
                <div class="FRowSec" style="margin:0 auto;float:none;">
                    <input type="submit" />
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        </form>
        <!--####################################################-->
    </div>
</div>
