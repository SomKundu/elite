<script src="http://maps.googleapis.com/maps/api/js"></script>

  <div class="SectionOuter SubpageWrap">
    <div class="SectionInner">
      <div class="StoreLocator">
      	<!--<div class="SLBanner">asdjkas</div>-->
      	<div class="STl">
        	<div class="LocFormWrap">
            	<h1>You can find your nearest <span>store</span> location</h1>
            	<form>
                <div class="FormRow">
                	<label>State</label>
                    <span>
                    	  <select id="select_state" onchange="MyfunctionGetDist()">
                          <option value="">---Select State---</option>
                          <?php foreach ($getState as $r1){ ?>
                          <option value="<?=$r1->state?>"><?=$r1->state?></optiopn>
                          <?php }?>
                        </select>
                    </span>
                </div>
                <div class="FormRow">
                	<label>District / City</label>
                    <span>
                    	  <select id="select_dist" onchange="MyfunctionGetTown()">
                        	<option value="">---District / City---</option>
                        </select>
                    </span>
                </div>
                <div class="FormRow">
                	<label>Town / Market</label>
                    <span>
                    	  <select id="select_town">
                        	<option value="">---Town / Market---</option>
                        </select>
                    </span>
                </div>
                <div class="FormRow">
                	<input type="button" value="Search" class="SearchBTN" id="Search" onclick="getCustomInitialize();">
                </div>
                </form>
            </div>
            <!--############################## Store List Starts #################################-->
<div style="padding-top: 18px"><div style="width: 98%;height: 274px;"><div id="searchAreaList" style="width: 98%;border-color: #EAEAEA; border-width: 2px; border-style: solid;overflow:auto; height: 268px;">
            
<div  style="padding: 10px 10px 10px 10px"><b style="color: #ec1827"><label>Lindsay St New Market</label></b><br><label style="font-size: 11px">Shop No. 7, Grant Lane Lindsay St New Market Area, Dharmatala, Taltala Kolkata, West Bengal 700087</label></div>                    
                
</div></div></div>
            <!--############################## Store List Ends #################################-->                
        </div>
        <div class="STr">
            <input type="hidden" id="txtZoom" value="10">
            <input type="hidden" id="txtLat" value="22.5667">
            <input type="hidden" id="txtLng" value="88.3537869">
        	<div class="LocatorMap" id="googleMap" style="width: 632; height: 511px;">
            
          </div>
        </div>
        <div class="clr"></div>
      </div>      
    </div>
  </div>
 
<script type="text/javascript">
function initialize()
{
  var markers = JSON.parse('<?=$storeLocation?>');
  var mapProp = {
    center:{lat: parseFloat($('#txtLat').val()), lng: parseFloat($('#txtLng').val())},
    zoom:parseInt(7),
    mapTypeId:google.maps.MapTypeId.ROADMAP
    };
  var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
  var infoWindow = new google.maps.InfoWindow();
/////////////////////////////////////////////////////////////////  
  for (i = 0; i < markers.length; i++) {
      var data = markers[i];
      //alert(i+' '+parseFloat(data.LATITUDE)+'||'+parseFloat(data.LONGITITUDE));
      var marker = new google.maps.Marker({
          position: {lat: parseFloat(data.LATITUDE), lng: parseFloat(data.LONGITITUDE)},
          map: map,
          title: data.STORENAME,
          icon: '<?=base_url()?>assets/images/map_marker.png'
      });
      (function (marker, data) {
          google.maps.event.addListener(marker, "click", function (e) {
              infoWindow.setContent(data.ADDRESS);
              infoWindow.open(map, marker);
          });
      })(marker, data);
  }
}
google.maps.event.addDomListener(window, 'load', initialize);

//////////////////////////////////////////////////////
function MyfunctionGetDist(){
  var select_state=$('#select_state').val();//alert(select_state);
  $.ajax({
       url : '<?=base_url()?>storelocator/get_selected_dist/',
       type : "POST",
       data : { 'select_state' : select_state},
       success(data){//alert(data); 
         $('#select_dist').html(data);
        }
    });
  
}
function MyfunctionGetTown(){
  var select_dist=$('#select_dist').val();//alert(select_dist);
  $.ajax({
       url : '<?=base_url()?>storelocator/get_selected_town/',
       type : "POST",
       data : { 'select_dist' : select_dist},
       success(data){//alert(data); 
         $('#select_town').html(data);
        }
    });
}
function getCustomInitialize(){
  var select_town=$('#select_town').val();//alert(select_town);
  
  $.ajax({
       url : '<?=base_url()?>storelocator/get_location_points/',
       type : "POST",
       dataType: "json",
       data : { 'select_town' : select_town},
       success(listdata){//alert(listdata); alert(listdata.length);
        var markers=listdata;
        //----------------------------//  
        //var markers = JSON.parse('<?=$storeLocation?>');
		var areaList='';
        var mapProp = {
          center:{lat: parseFloat(markers[0].LATITUDE), lng: parseFloat(markers[0].LONGITITUDE)},
          zoom:parseInt(12),
          mapTypeId:google.maps.MapTypeId.ROADMAP
        };
        var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
        var infoWindow = new google.maps.InfoWindow(); 
        for (i = 0; i < markers.length; i++) {if(select_town==markers[i].city){	
            var data = markers[i];		
			//----------------------------//  
				areaList=areaList+'<div  style="padding: 10px 10px 10px 10px"><b style="color: #ec1827"><label>'+data.STORENAME+'</label></b><br><label style="font-size: 11px">'+data.ADDRESS+'</label></div>'; 
			//----------------------------// 
            //alert(i+' '+parseFloat(data.LATITUDE)+'||'+parseFloat(data.LONGITITUDE));
            var marker = new google.maps.Marker({
                position: {lat: parseFloat(data.LATITUDE), lng: parseFloat(data.LONGITITUDE)},
                map: map,
                title: data.STORENAME,
                icon: '<?=base_url()?>assets/images/map_marker.png'
            });
            (function (marker, data) {
                google.maps.event.addListener(marker, "click", function (e) {
                    infoWindow.setContent(data.ADDRESS);
                    infoWindow.open(map, marker);
                });
            })(marker, data);
        }}
		//----------------------------// 		
		$('#searchAreaList').html(areaList); 
      }
    });           
}
//////////////////////////////////////////////////////

</script>
