<?php 
$id='';
$title='';
$image='';
$status='';
$parent_id='';
$discount='';
foreach($getdetials as $d){
	$id=$d->id;
	$title=$d->title;
	$image=$d->image;
	$status=$d->status;
	$parent_id=$d->parent_id;
	$discount=$d->discount;
}
?>

<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
        <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>--> 
        <a href="<?=base_url().$form_cancel?>">
        <h2><i class="halflings-icon remove"></i> Close</h2>
        </a> </div>
    </div>
    <?php //print_r($getcatagories);?>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <input type="hidden" name="id" value="<?=$id?>">
          <div class="control-group">
            <label class="control-label" for="typeahead">catagory<span>*</span></label>
            <div class="controls">
              <select name="parent_id" required>
                <option value="">-Select Catagory-</option>
                <?php foreach($getcatagories as $sub){?>
                <option value="<?=$sub->id?>" 
										<?=($parent_id==$sub->id)?'selected':''?>>
                <?=$sub->title?>
                </option>
                <?php }?>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">title<span>*</span></label>
            <div class="controls">
              <input type="text" name="title" value="<?=$title?>" required  >
            </div>
          </div>
          <div class="control-group">
            <div class="controls">
              <?php if($image<>'' && file_exists('./uploads/catagory/'.$image)){?>
              <img class="avatar" alt="Jane" src="<?=base_url().'uploads/catagory/'.$image?>" 
										style="height: 70px !important;">
              <?php }?>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">image</label>
            <div class="controls">
              <input type="file"  name="image" value="">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">discount</label>
            <div class="controls">
              <input type="text"  name="discount" value="<?=$discount?>">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">status</label>
            <div class="controls">
              <select name="status">
                <option value="y" <?=($status=='y')?'selected':''?>>Active</option>
                <option value="n" <?=($status=='n')?'selected':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit">Save changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
