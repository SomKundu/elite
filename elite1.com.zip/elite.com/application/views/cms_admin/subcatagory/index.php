<div class="row-fluid sortable ui-sortable">
  <div class="box span12">
    <div class="box-header">
      <h2><i class="halflings-icon align-justify"></i><span class="break"></span>
        <?=$table_header?>
      </h2>
      <div class="box-icon"> <a href="<?=base_url().$addNew?>" >
        <h2><i class="halflings-icon plus"> </i> Add New</h2>
        </a> 
        <!--<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a> 
        <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>--> 
      </div>
    </div>
    <div class="box-content">
      <table class="table table-bordered table-striped table-condensed">
        <!--<div class="row-fluid">
          <div class="span6">
            <div id="DataTables_Table_0_length" class="dataTables_length">
              <label>
                <select size="1" name="DataTables_Table_0_length" aria-controls="DataTables_Table_0">
                  <option value="10" selected="selected">10</option>
                  <option value="25">25</option>
                  <option value="50">50</option>
                  <option value="100">100</option>
                </select>
                records per page</label>
            </div>
          </div>
          <div class="span6">
            <div class="dataTables_filter" id="DataTables_Table_0_filter">
              <label>Search:
                <input type="text" aria-controls="DataTables_Table_0">
              </label>
            </div>
          </div>
        </div>-->
        <thead>
          <tr>
            <th>ID</th>
            <th>TITLE</th>
            <th>PARENT</th>
            <th>IMAGE</th>
            <th>DISCOUNT</th>
            <th>STATUS</th>
            <th>ACTION</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($list as $d){?>
          <tr>
            <td class="center"><?=$d->id?></td>
            <td class="center"><?=$d->title?></td>
            <td class="center"><?=$d->cat_title?></td>
            <td class="center"><?php if($d->image<>'' && file_exists('./uploads/catagory/'.$d->image)){?>
              <img class="avatar" alt="Jane" src="<?=base_url().'uploads/catagory/'.$d->image?>" 
							style="height: 70px !important;">
              <?php }?></td>
            <td class="center"><?=$d->discount?></td>
            <td class="center"><span class="<?=($d->status=='y')?'label label-success':'label label-important'?>">
              <?=($d->status=='y')?'Active':'In-Active'?>
              </span></td>
            <td class="center">
<!------------------------------------------------------------------------------------------>             
                <a class="btn btn-info" href="<?=base_url().$edit.$d->id?>"> 
                  <i class="halflings-icon white edit"></i> </a> 
                <a class="btn btn-danger" href="<?=base_url().$delete.$d->id?>"> 
                  <i class="halflings-icon white trash"></i> </a>
                <a class="btn btn-primary" href="<?=base_url().$attribute.$d->id?>">
                  <i class="white halflings-icon tags"></i> </a>
<!------------------------------------------------------------------------------------------>                   
            <!--<a class="btn btn-info" href="<?=base_url().$edit?><?=$d->id?>"> 
              <i class="halflings-icon white edit"></i> </a> 
            <a class="btn btn-danger" href="<?=base_url().$delete?><?=$d->id?>"> 
              <i class="halflings-icon white trash"></i> </a>
            <a class="btn btn-primary" href="<?=base_url().$attribute?><?=$d->id?>">
    <i class="halflings-icon white halflings-icon tags"></i></a>-->
            </td>
          </tr>
          <?php }?>
        </tbody>
      </table>
      <!--<div class="row-fluid">
        <div class="span12">
          <div class="dataTables_info" id="DataTables_Table_0_info">Showing 1 to 10 of 32 entries</div>
        </div>
        <div class="span12 center">
          <div class="dataTables_paginate paging_bootstrap pagination">
            <ul>
              <li class="prev disabled"><a href="#">← Previous</a></li>
              <li class="active"><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">4</a></li>
              <li class="next"><a href="#">Next → </a></li>
            </ul>
          </div>
        </div>
      </div>--> 
    </div>
  </div>
  <!--/span--> 
</div>
