			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10">
			
						
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="<?=base_url()?>cms-admin/">Home</a> 					
				<?php if($this->uri->segment(2)<>''){ ?>
					<i class="icon-angle-right"></i>
				</li>
				<li>
					<a href="javascript:window.history.go(-1);">
					<?=ucwords(str_replace("_"," ",$this->uri->segment(2)));?></a>
					<?php if($this->uri->segment(3)<>'index' or $this->uri->segment(3)<>''){ ?>
						<i class="icon-angle-right"></i>
					</li>
						<li><a href="<?=current_url()?>">
						<?=ucwords(str_replace("_"," ",$this->uri->segment(3)));?></a></li>
					<?php }else{?>
					</li>
					<?php }}else{?>
				</li>
				<?php }?>
			</ul>
