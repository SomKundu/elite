<!-- start: Main Menu -->
<div id="sidebar-left" class="span2">
	<a class="brand" href="<?=base_url()?>cms-admin/"><span><!--<img src="<?=base_url().'assets/images/logo-img.png'?>">-->
	<img src="<?=base_url().'assets/images/Elite.gif'?>"></span></a>
	<div class="nav-collapse sidebar-nav">
		<ul class="nav nav-tabs nav-stacked main-menu">
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> Product Management</span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$catagory_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Category List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$catagory_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Catagory</span></a></li>-->
					<li><a class="submenu" href="<?=base_url().$subcatagory_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Sub-Category List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$subcatagory_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Sub-Catagory</span></a></li>-->
					<li><a class="submenu" href="<?=base_url().$product_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Product List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$product_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Product</span></a></li>-->
				</ul>	
			</li>
		<?php if($this->session->userdata('adminPriority')=='y'){?>
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> Content Management</span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$content_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Content List</span></a></li>
					<li><a class="submenu" href="<?=base_url().$media_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Media List</span></a></li>
					<li><a class="submenu" href="<?=base_url().$corporate_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Corporate List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$content_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Content</span></a></li>-->
				</ul>	
			</li>
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> Banner Management</span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$banner_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Banner List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$banner_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Banner</span></a></li>-->
				</ul>	
			</li>
            <!--<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> Offer Management</span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$offer_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Offer List</span></a></li>
				</ul>	
			</li>-->
		<?php }?>
<!------------------------------------------------------------------------------------------>			
	
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> Store Locator</span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$store_locator_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Store Locator List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$content_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Content</span></a></li>-->
				</ul>	
			</li>

<!------------------------------------------------------------------------------>			
            <li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> News-Letter </span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$newsletter_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> News-Letter List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$content_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Content</span></a></li>-->
				</ul>	
			</li>
			<!-------------------------------------------------------------->
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> Jobseeker</span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$jobseeker_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Jobseeker List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$content_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Content</span></a></li>-->
				</ul>	
			</li>
            <li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> Franchise</span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$franchise_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Franchise List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$content_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Content</span></a></li>-->
				</ul>	
			</li>
			<!-------------------------------------------------------------->            
         <?php if($this->session->userdata('adminPriority')=='y'){?>
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet"> Attribute Master </span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$attribute_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Attribute Value Master List</span></a></li>
					<li><a class="submenu" href="<?=base_url().$attribute_master_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Attribute Type Master List</span></a></li>
					<!--<li><a class="submenu" href="<?=base_url().$content_addNew?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Add Content</span></a></li>-->
				</ul>	
			</li>
         <?php }?>
<!------------------------------------------------------------------------------------------>			
			<!--<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i>
					<span class="hidden-tablet">Attribute Type Master </span></a>
				<ul>
					<li><a class="submenu" href="<?=base_url().$attribute_master_list?>"><i class="icon-file-alt"></i>
					<span class="hidden-tablet"> Attribute Type Master List</span></a></li>
				</ul>	
			</li>-->
			
<!------------------------------------------------------------------------------>						
		</ul>
	</div>
	<div style="clear:both;"></div>
</div>
<!-- end: Main Menu -->

<style type="text/css">
.nav-tabs.nav-stacked{margin-top: 10px !important;}
.container-fluid-full {overflow: visible !important;}
.brand img {margin: -27px 0px -5px 13px !important;background-color: #fff !important;padding: 5px !important;}	
.nav-tabs.nav-stacked > li > ul > li > a span{font-size: 12px !important;}
.nav-tabs.nav-stacked > li > ul > li > a{padding: 5px 0px 5px 0px !important;}
</style>