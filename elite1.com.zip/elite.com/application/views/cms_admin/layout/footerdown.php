	
	<!-- start: JavaScript-->

		<script src="<?=base_url()?>assets/cms_admin/js/jquery-1.9.1.min.js"></script>
	<script src="<?=base_url()?>assets/cms_admin/js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.ui.touch-punch.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/modernizr.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/bootstrap.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.cookie.js"></script>
	
		<script src='<?=base_url()?>assets/cms_admin/js/fullcalendar.min.js'></script>
	
		<script src='<?=base_url()?>assets/cms_admin/js/jquery.dataTables.min.js'></script>

		<script src="<?=base_url()?>assets/cms_admin/js/excanvas.js"></script>
	<script src="<?=base_url()?>assets/cms_admin/js/jquery.flot.js"></script>
	<script src="<?=base_url()?>assets/cms_admin/js/jquery.flot.pie.js"></script>
	<script src="<?=base_url()?>assets/cms_admin/js/jquery.flot.stack.js"></script>
	<script src="<?=base_url()?>assets/cms_admin/js/jquery.flot.resize.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.chosen.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.uniform.min.js"></script>
		
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.cleditor.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.noty.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.elfinder.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.raty.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.iphone.toggle.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.gritter.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.imagesloaded.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.masonry.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.knob.modified.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/jquery.sparkline.min.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/counter.js"></script>
	
		<script src="<?=base_url()?>assets/cms_admin/js/retina.js"></script>

		<script src="<?=base_url()?>assets/cms_admin/js/custom.js"></script>
	<!-- end: JavaScript-->


<script type="text/javascript">
function divShowHide(param){//alert(param);		
	$('.myCollapse').click();
	$('#myCollapseForm_'+param).click();
}
$().ready(function() {
	if(('<?=$this->uri->segment(2)?>'=='product' && '<?=$this->uri->segment(3)?>'=='addnew' ) || ('<?=$this->uri->segment(2)?>'=='product' && '<?=$this->uri->segment(3)?>'=='edit' )){
		divShowHide('<?=$this->uri->segment(5)?>');
	}

//------------############################---------------------//
<?php if($this->session->userdata('adminPriority')<>'y'){?>

$( ".cleditorToolbar .cleditorGroup:nth-child(1)" ).html('');	
$( ".cleditorToolbar .cleditorGroup:nth-child(2)" ).html('');	
$( ".cleditorToolbar .cleditorGroup:nth-child(3)" ).html('');	
$( ".cleditorToolbar .cleditorGroup:nth-child(4)" ).html('');	
$( ".cleditorToolbar .cleditorGroup:nth-child(5)" ).html('');	
$( ".cleditorToolbar .cleditorGroup:nth-child(6)" ).html('');	
//------------############################---------------------//
<?php }?>
});	
</script>	
</body>
</html>
