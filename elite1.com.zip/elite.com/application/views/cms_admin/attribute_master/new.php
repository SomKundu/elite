<style>
.form-horizontal textarea {
	width: 490px;
}
</style>

<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
        <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>--> 
        <a href="<?=base_url().$form_cancel?>">
        <h2><i class="halflings-icon remove"></i> Close</h2>
        </a> </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="typeahead">Attribute Field Name<span>*</span></label>
            <div class="controls">
              <input type="text" name="attribute_field_name" value="" required>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="typeahead">Input Status</label>
            <div class="controls">
              <select name="input_status">
                <option value="select">select</option>
                <option value="check">check</option>
                <option value="check">color</option>
              </select>
            </div>
          </div>
          
          <div class="control-group">
            <label class="control-label" for="typeahead">status</label>
            <div class="controls">
              <select name="status">
                <option value="y">Active</option>
                <option value="n">In-Active</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" >Save changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
