<?php 
$id='';
$attribute_field_name_id='';
$value='';
$status='';
//$slag='';
foreach($getdetials as $attr){
  $id=$attr->id;
  $attribute_field_name_id=$attr->attribute_field_name_id;
  $value=$attr->value;
  $status=$attr->status;
  //$slag=$attr->slag;  
}
?>

<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
        <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>--> 
        <a href="<?=base_url().$form_cancel?>">
        <h2><i class="halflings-icon remove"></i> Close</h2>
        </a> </div>
    </div>
    <?php //print_r($getcatagories);?>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <input type="hidden" name="id" value="<?=$id?>">
          <div class="control-group">
            <label class="control-label" for="typeahead">catagory<span>*</span></label>
            <div class="controls">
              <select name="attribute_field_name_id" required>
                <option value="">-Select Attruibute-</option>
                <?php foreach($getattribute as $sub){?>
                <option value="<?=$sub->id?>" 
                    <?=($attribute_field_name_id==$sub->id)?'selected':''?>>
                <?=$sub->attribute_field_name?>
                </option>
                <?php }?>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">value<span>*</span></label>
            <div class="controls">
              <input type="text" name="value" value="<?=$value?>" required >
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">status</label>
            <div class="controls">
              <select name="status">
                <option value="y" <?=($status=='y')?'selected':''?>>Active</option>
                <option value="n" <?=($status=='n')?'selected':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit">Save changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
