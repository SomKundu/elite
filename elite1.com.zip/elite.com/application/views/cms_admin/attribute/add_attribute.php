<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
        <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>--> 
        <a href="<?=base_url().$form_cancel?>">
        <h2><i class="halflings-icon remove"></i> Close</h2>
        </a> </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
          <table class="table table-condensed">
            <thead><tr><td colspan="4">
              <table class="table table-striped">
                <tbody>
                    <?php $i=0;foreach($attributelist as $d){$i++;?>
                <tr id="ajaxAttributeDiv_<?=$d->id?>">
                <td><a title="Edit">
                    <span class="label label-warning">
                        <i id="editIcon_<?=$d->id?>" onclick="myAttributeEdit('<?=$d->id?>');" class="halflings-icon edit"></i>
                    </span></a>
                    <a title="Delete">
                    <span class="label label-important">
                        <i class="halflings-icon ban-circle" onclick="myAttributeDelete('<?=$d->id?>');"></i>
                    </span></a>
                </td>
                <td><label for="attribute">Attribute <?=$i?> : </label></td>
                <td>
                <input type="text" id="update_attribute_name_<?=$d->id?>" value="<?=$d->attribute?>" disabled="disabled"></td>
                <td><label for="attribute">Field Type: </label></td>
                <td><select id="update_attribute_type_<?=$d->id?>" disabled="disabled">
                    <option value="">---Select Field Type---</option>
                    <?php foreach($attr_type as $attr){?>
                        <option value="<?=$attr->id?>" <?=($attr->id==$d->attribute_type)?'selected="Selected"':''?>><?=$attr->attribute_field_name?></option>
                    <?php }?>
                    
                    </select>
                </td></tr> 
                    <?php }?>
                </tbody></table>    
            </td></tr></thead>
            <tbody id="ajaxAttributeDiv">
                <tr>
                    <td>Attribute 1<span>*</span></td>
                    <td><input name="attribute_1" type="text" required="required" class="span6 typeahead"></td>
                    <td>Field Type <span>*</span></td>
                    <td><select name="attribute_type_1" required >
                            <option value="">---Select Field Type---</option>
                            <?php foreach($attr_type as $attr){?>
                            <option value="<?=$attr->id?>"><?=$attr->attribute_field_name?></option>
                            <?php }?>
                        </select></td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                  <input type="hidden" name="subcat_id" value="<?=$this->uri->segment(4)?>">
                  <input type="hidden" value="1" name="attributeCounter" id="attributeCounter">
                  <td colspan="4" style="text-align:right !important;">
                    <i onclick="myAttributeAdd();" class="glyphicons-icon circle_plus"></i>
                  </td>
                </tr><tr>
                  <td></td>
                  <td><button type="submit" class="btn btn-primary">Save changes</button></td>
                  <td><button type="reset" class="btn">Cancel</button></td>
                  <td></td>
                </tr>
            </tfoot>
          </table>
      </form>
    </div>
  </div>
  <!--/span-->   
</div>
<!--/row--> 
<script type="text/javascript">
function myAttributeAdd(){
    var attributeCounter=$('#attributeCounter').val();
    attributeCounter++;
    $("#ajaxAttributeDiv").append('<tr><td>Attribute '+attributeCounter+' :</td><td><input name="attribute_'+attributeCounter+'" type="text" required="required" class="span6 typeahead" ></td><td>Field Type :</td><td><select name="attribute_type_'+attributeCounter+'"><option value="">---Select Field Type---</option><?php foreach($attr_type as $attr){?><option value="<?=$attr->id?>"><?=$attr->attribute_field_name?></option><?php }?></select></td></tr>');
    $('#attributeCounter').val(attributeCounter);
}
function myAttributeEdit(param){//alert(param);
    $('#ajaxAttributeDiv_'+param).append('<td id="editDone_'+param+'"><input type="button" value="Done" class="btn btn-small btn-success" onclick="myAttributeEditDone('+param+')"></td>');
    $('#update_attribute_name_'+param).removeAttr('disabled');
    $('#update_attribute_type_'+param).removeAttr('disabled');
    $('#editIcon_'+param).attr('onclick','myAttributeEditDone('+param+');');
}
function myAttributeEditDone(param){//alert(param);
    var attribute=$('#update_attribute_name_'+param).val();
    var attribute_type=$('#update_attribute_type_'+param).val();
    $.ajax({
        url: '<?=base_url()?>cms_attribute/updateAttribute/',
        type: 'POST',
        data: {'attribute' : attribute , 'attribute_type' : attribute_type, 'id' : param},
        success: function(data) {//alert(data);
            (data=='Yo')?location.reload():'';
        },
        error: function(e){}
    });
}
function myAttributeDelete(param){//alert(param);
    $.ajax({
        url: '<?=base_url()?>cms_attribute/deleteAttribute/',
        type: 'POST',
        data: {'id' : param},
        success: function(data) {//alert(data);
            (data=='Yo')?location.reload():'';
        },
        error: function(e){}
    });
}
</script>