<div class="row-fluid sortable ui-sortable">
  <div class="box span12">
    <div class="box-header">
      <h2><i class="halflings-icon align-justify"></i><span class="break"></span>
        <?=$table_header?>
      </h2>
      <div class="box-icon"> <a href="<?=base_url().$addNew?>" >
        <h2><i class="halflings-icon plus"> </i> Add New</h2>
        </a>  
      </div>
    </div>
    <div class="box-content">
      <table class="table table-bordered table-striped table-condensed">
        <thead>
          <tr>
            <th>ID</th>
            <th>STORE CODE</th>
            <th>STORE NAME</th>
            <th>ADDRESS</th>
            <th>CITY</th>
            <th>DISTRICT</th>            
            <th>STATE</th>
            <th>ZIP</th>
            <th>LATTITUDE</th>
            <th>LONGITUDE</th>
            <th>STATUS</th>
            <th>ACTION</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($list as $d){?>
          <tr>
            <td class="center"><?=$d->id?></td>
            <td class="center"><?=$d->storecode?></td>
            <td class="center"><?=$d->store_name?></td>
            <td class="center"><?=substr($d->address, 0, 7)?></td>
            <td class="center"><?=$d->city?></td>
            <td class="center"><?=$d->district?></td>
            <td class="center"><?=$d->state?></td>
            <td class="center"><?=$d->zip?></td>
            <td class="center"><?=$d->lat?></td>
            <td class="center"><?=$d->lng?></td>
            <td class="center"><span class="<?=($d->status=='y')?'label label-success':'label label-important'?>">
              <?=($d->status=='y')?'Active':'In-Active'?>
              </span></td>
            <td class="center"><a class="btn btn-info" href="<?=base_url().$edit?><?=$d->id?>"> <i class="halflings-icon white edit"></i> </a> <a class="btn btn-danger" href="<?=base_url().$delete?><?=$d->id?>"> <i class="halflings-icon white trash"></i> </a></td>
          </tr>
          <?php }?>
        </tbody>
      </table>
     
    </div>
  </div>
  <!--/span--> 
</div>
