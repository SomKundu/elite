<?php 
$id='';
$storecode='';
$store_name='';
$address='';
$city='';
$district='';
$state='';
$zip='';
$lat='';
$lng='';
$status='';

foreach($getdetials as $d){
	$id=$d->id;
	$storecode=$d->storecode;
	$store_name=$d->store_name;	
	$address=$d->address;
	$city=$d->city;
	$district=$d->district;
  $state=$d->state;
  $zip=$d->zip;
  $lat=$d->lat;
  $lng=$d->lng;
  $status=$d->status;
}
?>

<style>
.form-horizontal textarea {
	width: 490px;
}
</style>

<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
      <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>-->
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a>  
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <input type="hidden" name="id" value="<?=$id?>">
         <div class="control-group">
            <label class="control-label" for="typeahead">storecode<span>*</span></label>
            <div class="controls">
              <input type="text" name="storecode" value="<?=$storecode?>" required>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">store_name<span>*</span></label>
            <div class="controls">
             <input type="text" name="store_name" value="<?=$store_name?>" required>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">address<span>*</span></label>
            <div class="controls">
               <input type="text" name="address" value="<?=$address?>" required>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">city<span>*</span></label>
            <div class="controls">
               <input type="text" name="city" value="<?=$city?>" required>
            </div>
          </div>         
           <div class="control-group">
            <label class="control-label" for="date01">district<span>*</span></label>
            <div class="controls">
             <input type="text" name="district" value="<?=$district?>" required>
            </div>
          </div>

           <div class="control-group">
            <label class="control-label" for="date01">state<span>*</span></label>
           <div class="controls">
             <input type="text" name="state" value="<?=$state?>" required>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">zip<span>*</span></label>
            <div class="controls">
              <input type="text" name="zip" value="<?=$zip?>" required>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">lattitude<span>*</span></label>
            <div class="controls">
               <input type="text" name="lat" value="<?=$lat?>" required>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">longitude<span>*</span></label>
            <div class="controls">
              <input type="text" name="lng" value="<?=$lng?>" required>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">status</label>
            <div class="controls">
              <select name="status">
                <option value="y">Active</option>
                <option value="n">In-Active</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" >Save changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
