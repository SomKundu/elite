
<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
      <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>-->
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a>  
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="typeahead">title<span>*</span></label>
            <div class="controls">
              <input type="text" name="title" value=""  required>
            </div>
          </div>
      <?php if($this->session->userdata('adminPriority')=='y'){?>          
          <div class="control-group">
            <label class="control-label" for="date01">image</label>
            <div class="controls">
              <input type="file"  name="image" value="">
            </div>
          </div>
      <?php }?>
          <div class="control-group">
            <label class="control-label" for="date01">discount</label>
            <div class="controls">
              <input type="text"  name="discount" value="">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">status</label>
            <div class="controls">
              <select name="status">
                <option value="y">Active</option>
                <option value="n">In-Active</option>
              </select>
            </div>
          </div>
      <?php if($this->session->userdata('adminPriority')=='y'){?>
<!-------------------------------- Home Promotion Starts ------------------------------------>          
          <div class="control-group">
            <label class="control-label" for="typeahead">home link</label>
            <div class="controls">
              <select name="home_link" id="home_link" onchange="myHomeLinkActive()">
                <option value="">-- Select --</option>
                <option value="y">Active</option>
                <option value="n">In-Active</option>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">promotion image<span id="lbl_prom_img"></span></label>
            <div class="controls">
              <input type="file"  name="prom_img" id="prom_img" value="">
            </div>
          </div>
<!-------------------------------- Home Promotion Ends ------------------------------------>           
      <?php }?>
          
          <div class="form-actions">
            <button type="submit" >Save changes</button>
            <a href="#"><button type="reset">Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
<script type="text/javascript">
  function myHomeLinkActive(){//alert($('#home_link').val());
    if($('#home_link').val()=='y'){
        $('#prom_img').attr('required','true');
        $('#lbl_prom_img').html('*');
    }else{
      $('#prom_img').removeAttr('required');
      $('#lbl_prom_img').html('');
    }
  }
</script>