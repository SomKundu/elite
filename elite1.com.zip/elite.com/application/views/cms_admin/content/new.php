<style>
.form-horizontal textarea {
	width: 490px;
}
</style>
<script type="text/javascript">
function myPageCheck(data){
	if(data.value=='default'){
		$('#imgLinkDiv').hide();
	}else{
		$('#imgLinkDiv').show();
	}
}
</script>
<!--++++++++++++++++++++++++++ text editor starts ++++++++++++++++++++++++++++-->
<!--<script type="text/javascript" src="<?=base_url()?>assets/cms_admin/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
    tinymce.init({
      selector: "#customTinyMce",
      images_upload_base_path: "<?=FILE_HARD_PATH?>banner/"
    });
</script>-->
<!--++++++++++++++++++++++++++ text editor ends ++++++++++++++++++++++++++++-->
<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
        <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>--> 
        <a href="<?=base_url().$form_cancel?>">
        <h2><i class="halflings-icon remove"></i> Close</h2>
        </a> </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="typeahead">Title<span>*</span></label>
            <div class="controls">
              <input type="text" name="header" value=""  required>
            </div>
          </div>

           <div class="control-group">
            <label class="control-label" for="typeahead">Page Type</label>
            <div class="controls">
              <select name="page" onchange="myPageCheck(this);">
                <option value="">--Select Page--</option>
                <option value="corporate">Corporate</option>
                <option value="media">Media</option>
                <option value="default">Default</option>
              </select>
            </div>
          </div>
          <div class="control-group" id="imgLinkDiv">
            <label class="control-label" for="date01">image</label>
            <div class="controls">
              <input type="file"  name="image" value="">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Sequence Number</label>
            <div class="controls">
              <input type="text" name="sequence_no" value="<?=count($sequence_no) + 1?>" >
            </div>
          </div>  
          <div class="control-group">
            <label class="control-label" for="date01">Meta keyword</label>
            <div class="controls">
              <textarea name="keyword"></textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Meta Description</label>
            <div class="controls">
              <textarea name="description"></textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Content<span>*</span></label>
            <div class="controls">
              <!--<textarea name="content" required  style="height:200px !important;"></textarea>-->
              <textarea class="cleditor" name="content" required></textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Status</label>
            <div class="controls">
              <select name="status">
                <option value="y">Active</option>
                <option value="n">In-Active</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" >Save changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
