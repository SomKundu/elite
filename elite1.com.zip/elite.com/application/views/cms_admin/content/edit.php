<?php 
$id='';
$header='';
$keyword='';
$description='';
$content='';
$status='';
$page='';
$sequence_no='';
$image='';

foreach($getdetials as $d){
	$id=$d->id;
	$header=$d->header;
	$keyword=$d->keyword;	
	$description=$d->description;
	$content=$d->content;
	$status=$d->status;
  $page=$d->page;
  $sequence_no=$d->sequence_no;
  $image=$d->image;
}
?>
<style>
.form-horizontal textarea {
	width: 490px;
}
</style>

<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
      <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>-->
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a>  
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <input type="hidden" name="id" value="<?=$id?>">
          <div class="control-group">
            <label class="control-label" for="typeahead">Title<span>*</span></label>
            <div class="controls">
              <input type="text" name="header" value="<?=$header?>" required>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="typeahead">Page Type</label>
            <div class="controls">
              <select name="page">
                <option value="">--Select Page--</option>
                <option value="corporate" <?=($page=='corporate')?'selected':''?>>Corporate</option>
                <option value="media" <?=($page=='media')?'selected':''?>>Media</option>
                <option value="default" <?=($page=='default')?'selected':''?>>Default</option>
              </select>
            </div>
          </div>
           <div class="control-group">
            <div class="controls">
              <?php if($image<>'' && file_exists('./uploads/content/'.$image)){?>
              <img class="avatar" alt="Jane" src="<?=base_url().'uploads/content/'.$image?>" 
                    style="height: 70px !important;">
              <?php }?>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Image</label>
            <div class="controls">
              <input type="file"  name="image" value="">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Sequence Number</label>
            <div class="controls">
              <input type="text" name="sequence_no" value="<?=$sequence_no?>" >
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Meta Keyword</label>
            <div class="controls">
              <textarea name="keyword" ><?=$keyword?>
</textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Meta Description</label>
            <div class="controls">
              <textarea name="description"><?=$description?>
</textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Content<span>*</span></label>
            <div class="controls">
              <!--<textarea name="content"  required style="height:200px !important;"><?=$content?></textarea>-->
              <textarea class="cleditor" name="content"  required><?=$content?></textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Status</label>
            <div class="controls">
              <select name="status">
                <option value="y" <?=($status=='y')?'selected':''?>>Active</option>
                <option value="n" <?=($status=='n')?'selected':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" >Save Changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
