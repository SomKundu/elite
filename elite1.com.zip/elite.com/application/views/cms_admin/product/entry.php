<?php
	$this->load->view($step1,$step1_data);

	if($this->uri->segment(3)<>'addnew'){
		$this->load->view($step2,$step2_data);
		$this->load->view($step3,$step3_data);
	}
?>