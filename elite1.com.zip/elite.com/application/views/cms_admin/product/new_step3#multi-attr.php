<style>
.form-horizontal textarea {
  width: 490px;
}
</style>
<?php 
$id=0;
$sub_cat_id=0;
if(isset($getdetials)){
  foreach($getdetials as $d){
    $id=$d->id;
    $sub_cat_id=$d->sub_cat_id;
  }
}//if(isset($productAttributeValue)){print_r($productAttributeValue);}
?>
<!--------------------   color box declaration starts  -------------------------------->
<script type="text/javascript" src="<?=base_url()?>assets/cms_admin/colorpicker/jscolor.js"></script>
<!--------------------   color box declaration ends   -------------------------------->
<?php /*
  if($this->session->userdata('step1_data'))
    print_r($this->session->userdata('step1_data'));
  if($this->session->userdata('step2_data'))
    print_r($this->session->userdata('step2_data'));
  if($this->session->userdata('step3_data'))
   print_r($this->session->userdata('step3_data'));
  if(isset($attributes))print_r($attributes);
  */
 ?>

<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
        <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>--> 
        <a href="#" class="btn-minimize"><h2><i id="myCollapseForm_attr" class="myCollapse halflings-icon chevron-up"></i>Minimize</h2></a>
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a> 
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <input type="hidden" name="id" value="<?=$id?>">
        <input type="hidden" name="sub_cat_id" value="<?=$sub_cat_id?>">
        <input type="hidden" name="redirection" required value="<?=$this->uri->segment(3)?>">
        <fieldset>
<!-------------------------------------------------------------------->    
<?php 
$data=array();
if(count($productAttributeValue)>0){
    foreach($attributes as $at){
        foreach($productAttributeValue as $proAttrVal){
          if($proAttrVal->attribute_id==$at->id){
             $data[$at->id]=$proAttrVal->attribute_value;
          }
      } 
    }
    //$this->session->set_userdata('step2_data',$data);
}
//echo count($productAttributeValue);
//print_r($data);
//print_r($productAttributeValue);
?>       
<?php if(isset($attributes)){foreach($attributes as $a){?>  
  <div class="control-group">
    <label class="control-label" for="date01"><?=$a->attribute?><span>*</span></label>
    <div class="controls">
    <?php foreach($attributeNameMaster as $attr_input_status){
      if($attr_input_status->id==$a->attribute_type && $attr_input_status->input_status=='color'){?>
      <input type="text" name="<?=$a->id?>" class="color" 
        value="<?=(count($data)>0)?$data[$a->id]:''?>" required>
    <?php }if($attr_input_status->id==$a->attribute_type && $attr_input_status->input_status=='check'){?>
      <input type="text" name="<?=$a->id?>" 
      value="<?=(count($data)>0)?$data[$a->id]:''?>" required>
    <?php }if($attr_input_status->id==$a->attribute_type && $attr_input_status->input_status=='select'){?>
      <select name="<?=$a->id?>" required>
        <option value=""> --Select <?=$a->attribute?> -- </option>
        <?php foreach($attributeSelecttionMaster as $atSelect){
          if($attr_input_status->id==$atSelect->attribute_field_name_id){?>
        <option value="<?=$atSelect->id?>" <?=(count($data)>0)?(($data[$a->id]==$atSelect->id)?'selected="selected"':''):''?>><?=$atSelect->value?></option>
        <?php }}?>
      </select>
    <?php }}?>      
    </div>
  </div>
<?php }}?>
<!-------------------------------------------------------------------->   
          <div class="form-actions">
            <button type="submit" >Save changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 