<?php 
$id=0;
$title='';
$brand_text='';
$code=random_string('alnum', 6);
$cat_id=0;
$sub_cat_id=0;
$image1='';
$image2='';
$image3='';
$image4='';
$image5='';
$image6='';
$image7='';
$image8='';


if(isset($getdetials)){
  foreach($getdetials as $d){
    $id=$d->id;
    $title=$d->title;
    $brand_text=$d->brand_text;
    $code=$d->code; 
    $cat_id=$d->cat_id;
    $sub_cat_id=$d->sub_cat_id;
    $image1=$d->image1;
    $image2=$d->image2;
    $image3=$d->image3;
    $image4=$d->image4;
    $image5=$d->image5;
    $image6=$d->image6;
    $image7=$d->image7;
    $image8=$d->image8;
  }
}
?>
<style>
.form-horizontal textarea {
	width: 490px;
}
</style>
<script type="text/javascript">
function mySubCatValues(){//alert($('#cat_id').val());
  if($('#cat_id').val()!=''){
    $('#sub_cat_id').html('<option>-Select Sub-Catagory-</option>');
    <?php foreach($getsubcatagories as $sub){?>
      if('<?=$sub->parent_id?>'==$('#cat_id').val()){
        $('#sub_cat_id').append('<option value="<?=$sub->id?>"><?=$sub->title?></option>');
      }
    <?php }?>
  }
}  
</script>         
<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
        <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>--> 
        <a href="#" class="btn-minimize"><h2><i id="myCollapseForm_detail" class="myCollapse halflings-icon chevron-up"></i>Minimize</h2></a>
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a> 
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <input type="hidden" name="id" value="<?=$id?>">
        <input type="hidden" name="redirection" value="<?=$this->uri->segment(3)?>">
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="typeahead">Title<span>*</span></label>
            <div class="controls">
              <input type="text" name="title" required value="<?=$title?>">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Brand-Title</label>
            <div class="controls">
              <input type="text" name="brand_text" value="<?=$brand_text?>">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Artificial ID<span>*</span></label>
            <div class="controls">
              <input type="text" name="code" value="<?=$code?>" >
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Catagory<span>*</span></label>
            <div class="controls">
              <select name="cat_id" required id="cat_id" onchange="mySubCatValues();">
                <option value="">-Select Catagory-</option>
                <?php foreach($getcatagories as $cat){?>
                <option value="<?=$cat->id?>" <?=($cat_id==$cat->id)?'selected="selected"':''?>><?=$cat->title?></option>
                <?php }?>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Subcatagory<span>*</span></label>
            <div class="controls">
              <select name="sub_cat_id" id="sub_cat_id" required>
                <option value="">-Select Sub-Catagory-</option>
                <?php if($sub_cat_id>0){
                  foreach($getsubcatagories as $subcat){
                    if($cat_id==$subcat->parent_id){?>
                <option value="<?=$subcat->id?>" <?=($sub_cat_id==$subcat->id)?'selected="selected"':''?>><?=$subcat->title?></option>
                <?php }}}?>
              </select>
            </div>
          </div>
          <!--##########################################################################-->
              <div class="control-group">
                <div class="controls">
              <?php if($image1<>'' && file_exists('./uploads/product/'.$image1)){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/product/'.$image1?>" 
                    style="height: 70px !important;"><?php }?>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="date01">image1 <span> Image Size should be less than 1MB</span></label>
                <div class="controls">
                <input type="file"  name="image1" id="image1" value="" accept="image/jpg,image/png,image/jpeg,image/gif" 
              onchange="ValidateSingleInput(this,'errorname1','image1')" ><span id="errorname1">    </span>
                </div>
              </div>

              <div class="control-group">
                <div class="controls">
              <?php if($image2<>'' && file_exists('./uploads/product/'.$image2)){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/product/'.$image2?>" 
                    style="height: 70px !important;"><?php }?>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="date01">image2 <span> Image Size should be less than 1MB</span></label>
                <div class="controls">
                <input type="file"  name="image2" id="image2" value="" accept="image/jpg,image/png,image/jpeg,image/gif" 
              onchange="ValidateSingleInput(this,'errorname2','image2')"><span id="errorname2">    </span>
                </div>
              </div>

              <div class="control-group">
                <div class="controls">
              <?php if($image3<>'' && file_exists('./uploads/product/'.$image3)){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/product/'.$image3?>" 
                    style="height: 70px !important;"><?php }?>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="date01">image3 <span> Image Size should be less than 1MB</span></label>
                <div class="controls">
                <input type="file"  name="image3" id="image3" value="" accept="image/jpg,image/png,image/jpeg,image/gif" 
              onchange="ValidateSingleInput(this,'errorname3','image3')"><span id="errorname3">    </span>
                </div>
              </div>

              <div class="control-group">
                <div class="controls">
              <?php if($image4<>'' && file_exists('./uploads/product/'.$image4)){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/product/'.$image4?>" 
                    style="height: 70px !important;"><?php }?>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="date01">image4 <span> Image Size should be less than 1MB</span></label>
                <div class="controls">
                <input type="file"  name="image4" id="image4" value="" accept="image/jpg,image/png,image/jpeg,image/gif" 
              onchange="ValidateSingleInput(this,'errorname4','image4')"><span id="errorname4">    </span>
                </div>
              </div>

              <div class="control-group">
                <div class="controls">
              <?php if($image5<>'' && file_exists('./uploads/product/'.$image5)){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/product/'.$image5?>" 
                    style="height: 70px !important;"><?php }?>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="date01">image5 <span> Image Size should be less than 1MB</span></label>
                <div class="controls">
                <input type="file"  name="image5" id="image5" value="" accept="image/jpg,image/png,image/jpeg,image/gif" 
              onchange="ValidateSingleInput(this,'errorname5','image5')"><span id="errorname5">    </span>
                </div>
              </div>

              <div class="control-group">
                <div class="controls">
              <?php if($image6<>'' && file_exists('./uploads/product/'.$image6)){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/product/'.$image6?>" 
                    style="height: 70px !important;"><?php }?>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="date01">image6 <span> Image Size should be less than 1MB</span></label>
                <div class="controls">
                <input type="file"  name="image6" id="image6" value="" accept="image/jpg,image/png,image/jpeg,image/gif" 
              onchange="ValidateSingleInput(this,'errorname6','image6')"><span id="errorname6">    </span>
                </div>
              </div>

              <div class="control-group">
                <div class="controls">
              <?php if($image7<>'' && file_exists('./uploads/product/'.$image7)){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/product/'.$image7?>" 
                    style="height: 70px !important;"><?php }?>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="date01">image7 <span> Image Size should be less than 1MB</span></label>
                <div class="controls">
                <input type="file"  name="image7" id="image7" value="" accept="image/jpg,image/png,image/jpeg,image/gif" 
              onchange="ValidateSingleInput(this,'errorname7','image7')"><span id="errorname7">    </span>
                </div>
              </div>

              <div class="control-group">
                <div class="controls">
              <?php if($image8<>'' && file_exists('./uploads/product/'.$image8)){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/product/'.$image8?>" 
                    style="height: 70px !important;"><?php }?>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="date01">image8 <span> Image Size should be less than 1MB</span></label>
                <div class="controls">
                <input type="file"  name="image8" id="image8" value="" accept="image/jpg,image/png,image/jpeg,image/gif" 
              onchange="ValidateSingleInput(this,'errorname8','image8')"><span id="errorname8">    </span>
                </div>
              </div>
          <!--##########################################################################-->
          <div class="form-actions">
            <button type="submit" >Save Changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
<script type="text/javascript">
var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png"];    
function ValidateSingleInput(oInput,errorSpan,inputFile) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                oInput.value = "";
                $('#'+errorSpan).html("this is an invalid file type"); 
                return false;
            }
        }
    }
///////////////////////////////////////////////    
    var file_size =  $('#'+inputFile)[0].files[0].size;
  if(file_size>=1048576) {
$("#"+errorSpan).html("File size is greater than 2MB");
    $(".demoInputBox").css("border-color","#FF0000");
     $('#'+inputFile).attr({ value: '' });
    return false;

  }
///////////////////////////////////////////////   
    return true;
}
</script>