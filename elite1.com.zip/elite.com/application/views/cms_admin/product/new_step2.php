<?php 
$id=0;
$title='';
$brand_text='';
$code=random_string('alnum', 6);
$cat_id=0;
$sub_cat_id=0;
$details='';
$quick_overview='';
$general_info='';
$occession='';
$material='';
$maintainance='';
$price='';
$status='';
$meta_tag='';
$meta_description='';
$meta_content='';
$discount='';
$availablity='';
$new_arrivals='';
$Offer_of_the_day='';
$best_seller='';
$weekly_offer='';
$special_discount='';
$featured='';

//print_r($getdetials);
if(isset($getdetials)){
  foreach($getdetials as $d){
    $id=$d->id;
    $title=$d->title;
    $brand_text=$d->brand_text;
    $code=$d->code; 
    $cat_id=$d->cat_id;
    $sub_cat_id=$d->sub_cat_id;
    $details=$d->details;
    $quick_overview=$d->quick_overview;
    $general_info=$d->general_info;
    $occession=$d->occession;
    $material=$d->material;
    $maintainance=$d->maintainance;
    $price=$d->price;
    $status=$d->status;
    $meta_tag=$d->meta_tag; 
    $status=$d->status;
    $meta_description=$d->meta_description;
    $meta_content=$d->meta_content;
    $discount=$d->discount;
    $availablity=$d->availablity;
    $new_arrivals=$d->new_arrivals;
    $Offer_of_the_day=$d->Offer_of_the_day;
    $best_seller=$d->best_seller;
    $weekly_offer=$d->weekly_offer;
    $special_discount=$d->special_discount;
    $featured=$d->featured;
  }
}
?>
<style>
.form-horizontal textarea {
  width: 490px;
}
</style>
<script type="text/javascript">
function mySubCatValues(){//alert($('#cat_id').val());
  if($('#cat_id').val()!=''){
    $('#sub_cat_id').html('<option>-Select Sub-Catagory-</option>');
    <?php foreach($getsubcatagories as $sub){?>
      if('<?=$sub->parent_id?>'==$('#cat_id').val()){
        $('#sub_cat_id').append('<option value="<?=$sub->id?>"><?=$sub->title?></option>');
      }
    <?php }?>
  }
}  
</script>         
<?php /*
  if($this->session->userdata('step1_data'))
    print_r($this->session->userdata('step1_data'));
  if($this->session->userdata('step2_data'))
    print_r($this->session->userdata('step2_data'));
  if($this->session->userdata('step3_data'))
   print_r($this->session->userdata('step3_data'));
  */
 ?>

<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
        <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>--> 
        <a href="#" class="btn-minimize"><h2><i id="myCollapseForm_content" class="myCollapse halflings-icon chevron-up"></i>Minimize</h2></a>
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a> 
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <input type="hidden" name="id" value="<?=$id?>">
        <input type="hidden" name="redirection" value="<?=$this->uri->segment(3)?>">
        <fieldset>
          <div class="control-group">
            <label class="control-label" for="typeahead">Title<span>*</span></label>
            <div class="controls">
              <input type="text" readonly value="<?=$title?>">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Brand-Title<span></span></label>
            <div class="controls">
              <input type="text" readonly value="<?=$brand_text?>">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Artificial ID<span>*</span></label>
            <div class="controls">
              <input type="text" readonly value="<?=$code?>" >
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Catagory<span>*</span></label>
            <div class="controls">
              <select readonly >
                <option value="">-Select Catagory-</option>
                <?php foreach($getcatagories as $cat){?>
                <option value="<?=$cat->id?>" <?=($cat_id==$cat->id)?'selected="selected"':''?>><?=$cat->title?></option>
                <?php }?>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Subcatagory<span>*</span></label>
            <div class="controls">
              <select readonly >
                <option value="">-Select Sub-Catagory-</option>
                <?php if($sub_cat_id<>0){
                  foreach($getsubcatagories as $subcat){
                    if($cat_id==$subcat->parent_id){?>
                <option value="<?=$subcat->id?>" <?=($sub_cat_id==$subcat->id)?'selected="selected"':''?>><?=$subcat->title?></option>
                <?php }}}?>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Meta Tag</label>
            <div class="controls">
              <textarea  name="meta_tag"><?=$meta_tag?></textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Meta Description</label>
            <div class="controls">
              <textarea name="meta_description"><?=$meta_description?></textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Meta Content</label>
            <div class="controls">
              <textarea name="meta_content"><?=$meta_content?></textarea>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Details</label>
            <div class="controls">
              <textarea name="details"  style="height:200px !important;"><?=$details?></textarea>
              <!--<textarea  class="cleditor" name="details" ><?=$details?></textarea>-->
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Quick Overview</label>
            <div class="controls">
              <textarea name="quick_overview"  style="height:200px !important;"><?=$quick_overview?></textarea>
              <!--<textarea  class="cleditor" name="quick_overview" ><?=$quick_overview?></textarea>-->
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">General Info</label>
            <div class="controls">
              <textarea name="general_info"  style="height:200px !important;"><?=$general_info?></textarea>
              <!--<textarea  class="cleditor" name="general_info"><?=$general_info?></textarea>-->
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Occession</label>
            <div class="controls">
              <textarea name="occession"  style="height:200px !important;"><?=$occession?></textarea>
              <!--<textarea  class="cleditor" name="occession"><?=$occession?></textarea>-->
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Material</label>
            <div class="controls">
              <textarea name="material"  style="height:200px !important;"><?=$material?></textarea>
              <!--<textarea  class="cleditor" name="material"><?=$material?></textarea>-->
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Maintainance</label>
            <div class="controls">
            	
              <textarea name="maintainance"  style="height:200px !important;"><?=$maintainance?></textarea>
              <!--<textarea  class="cleditor" name="maintainance"><?=$maintainance?></textarea>-->
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Price<span>*</span></label>
            <div class="controls">
              <input type="text" required name="price" value="<?=$price?>">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Status<span>*</span></label>
            <div class="controls">
              <select name="status" required>
              <option value="">---Select Status---</option>
                <option value="y" <?=($status=='y')?'selected="selected"':''?>>Active</option>
                <option value="n" <?=($status=='n')?'selected="selected"':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Discount</label>
            <div class="controls">
              <input type="text"  name="discount" value="<?=$discount?>">
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Availablity<span>*</span></label>
            <div class="controls">
              <select name="availablity" required>
              <option value="">---Select Availablity---</option>
                <option value="y" <?=($availablity=='y')?'selected="selected"':''?>>Active</option>
                <option value="n" <?=($availablity=='n')?'selected="selected"':''?>>In-Active</option>
              </select>
            </div>
          </div><!--
          <div class="control-group">
            <label class="control-label" for="typeahead">New Arrivals</label>
            <div class="controls">
              <select name="new_arrivals">
                <option value="">---Select New Arrivals---</option>
                <option value="y" <?=($new_arrivals=='y')?'selected="selected"':''?>>Active</option>
                <option value="n" <?=($new_arrivals=='n')?'selected="selected"':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Offer of The Day</label>
            <div class="controls">
              <select name="Offer_of_the_day">
                <option value="">---Offer of The Day---</option>
                <option value="y" <?=($Offer_of_the_day=='y')?'selected="selected"':''?>>Active</option>
                <option value="n" <?=($Offer_of_the_day=='n')?'selected="selected"':''?>>In-Active</option>
              </select>
            </div>
          </div>-->
          <div class="control-group">
            <label class="control-label" for="typeahead">Best Seller</label>
            <div class="controls">
              <select name="best_seller">
                <option value="">---Best Seller---</option>
                <option value="y" <?=($best_seller=='y')?'selected="selected"':''?>>Active</option>
                <option value="n" <?=($best_seller=='n')?'selected="selected"':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <!--<div class="control-group">
            <label class="control-label" for="typeahead">Weekly Offer</label>
            <div class="controls">
              <select name="weekly_offer">
                <option value="">---Weekly Offer---</option>
                <option value="y" <?=($weekly_offer=='y')?'selected="selected"':''?>>Active</option>
                <option value="n" <?=($weekly_offer=='n')?'selected="selected"':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="typeahead">Special Discount</label>
            <div class="controls">
              <select name="special_discount">
                <option value="">---Special Discount---</option>
                <option value="y" <?=($special_discount=='y')?'selected="selected"':''?>>Active</option>
                <option value="n" <?=($special_discount=='n')?'selected="selected"':''?>>In-Active</option>
              </select>
            </div>
          </div>-->
          <div class="control-group">
            <label class="control-label" for="typeahead">Featured</label>
            <div class="controls">
              <select name="featured">
                <option value="">---Featured---</option>
                <option value="y" <?=($featured=='y')?'selected="selected"':''?>>Active</option>
                <option value="n" <?=($featured=='n')?'selected="selected"':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" >Save Changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
