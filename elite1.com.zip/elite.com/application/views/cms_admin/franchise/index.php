<div class="row-fluid sortable ui-sortable">
  <div class="box span12">
    <div class="box-header">
      <h2><i class="halflings-icon align-justify"></i><span class="break"></span>
        <?=$table_header?>
      </h2>
      
    </div>
   
    <div class="box-content">
      <table class="table table-bordered table-striped table-condensed">
        <thead>
          <tr>
           
            <th>NAME</th>
            <th>ADDRESS</th>        
            <th>PHONE</th>
            <th>MOBILE</th>            
            <th>EMAIL</th>          
            <th>CITY</th>
            <th>LOCATION</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($list as $d){?>
          <tr>
            
            <td class="center"><?=$d->fname.' '.$d->mname.' '.$d->lname?></td>
            <td class="center"><?=$d->address?></td>
            <td class="center"><?=$d->phone?></td>
            <td class="center"><?=$d->mobile?></td>
            <td class="center"><?=$d->email?></td>
            <td class="center"><?=$d->city?></td>
            <td class="center"><?=$d->locality.' '.$d->located_in?></td>                     
            <td class="center"><a class="btn btn-info" href="<?=base_url().$edit?><?=$d->id?>"> <i class="halflings-icon white edit"></i> </a> </td>
          </tr>
          <?php }?>
        </tbody>
      </table>
     
    </div>
  </div>
  <!--/span--> 
</div>
