<?php 
$email='';
$fname='';
$mname='';
$lname='';
$sex='';
$dob='';
$phone='';
$mobile='';
$state='';
$country='';
$address='';
$qualification='';
$other_qualification='';
$exp_years='';
$exp_months='';
$relevant_exp_years='';
$relevant_exp_months='';
$cvfile='';
$cvText='';
foreach($getdetials as $d){
	$id=$d->id;
	$email=$d->email;
	$fname=$d->fname;
	$mname=$d->mname;
	$lname=$d->lname;
	$sex=$d->sex;
	$dob=$d->dob;
	$phone=$d->phone;
	$mobile=$d->mobile;
	$state=$d->state;
	$country=$d->country;
	$address=$d->address;
	$qualification=$d->qualification;
	$other_qualification=$d->other_qualification;
	$exp_years=$d->exp_years;
	$exp_months=$d->exp_months;
	$relevant_exp_years=$d->relevant_exp_years;
	$relevant_exp_months=$d->relevant_exp_months;
	$cvfile=$d->cvfile;
	$cvText=$d->cvText;
}
?>

<style>
.form-horizontal textarea {
	width: 490px;
}
</style>
<link  href="<?=base_url()?>assets/cms_admin/sumoselect/css/sumoselect.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script type='text/javascript' src="<?=base_url()?>assets/cms_admin/sumoselect/js/jquery.sumoselect.js"></script>
<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
      <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>-->
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a>  
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <input type="hidden" name="id" value="<?=$id?>">
        <div class="control-group">
            <label class="control-label" for="typeahead">email</label>
            <div class="controls">
              <input type="text" name="email" value="<?=$email?>" required disabled>
            </div>
          </div>
        <div class="control-group">
            <label class="control-label" for="typeahead">First Name</label>
            <div class="controls">
              <input type="text" name="fname" value="<?=$fname?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Middle Name</label>
            <div class="controls">
             <input type="text" name="mname" value="<?=$mname?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">Last Name</label>
            <div class="controls">
             <input type="text" name="lname" value="<?=$lname?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Sex</label>
            <div class="controls">
             <input type="text" name="sex" value="<?=($sex=='m')?'Male':'Female'?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Date of Birth</label>
            <div class="controls">
             <input type="text" name="dob" value="<?=$dob?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Phone</label>
            <div class="controls">
             <input type="text" name="phone" value="<?=$phone?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Mobile</label>
            <div class="controls">
             <input type="text" name="mobile" value="<?=$mobile?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">State</label>
            <div class="controls">
             <input type="text" name="state" value="<?=$state?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Country</label>
            <div class="controls">
             <input type="text" name="country" value="<?=$country?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Address</label>
            <div class="controls">
             <textarea name="address" value="<?=$address?>" required disabled></textarea>
            </div>
          </div>
<!--`email`, `fname`, `mname`, `lname`, `sex`, `dob`, `phone`, `mobile`, `state`, `country`, `address`, `qualification`, `other_qualification`, `exp_years`, `exp_months`, `relevant_exp_years`, `relevant_exp_months`, `cvfile`, `cvText`,-->
          <div class="control-group">
            <label class="control-label" for="date01">Qualification</label>
            <div class="controls">
             <input type="text" name="qualification" value="<?=$qualification?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Other Qualification</label>
            <div class="controls">
             <input type="text" name="other_qualification" value="<?=$other_qualification?>" required disabled>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">Experience</label>
            <div class="controls">
             <input type="text" name="experience" value="<?=$exp_years.' Year(s) and '.$exp_months.' Month(s)'?>" required disabled>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">Relevant Experience</label>
            <div class="controls">
             <input type="text" name="city" value="<?=$relevant_exp_years.' Year(s) and '.$relevant_exp_months.' Month(s)'?>" required disabled>
            </div>
          </div>
          <?php if($cvfile<>''){?>
           <div class="control-group">
            <label class="control-label" for="date01">CV</label>
            <div class="controls">
             <a href="<?=base_url().'uploads/career/'.$cvfile?>"><?=$cvfile?></a>
            </div>
          </div>
          <?php }?>
           <div class="control-group">
            <label class="control-label" for="date01">Text</label>
            <div class="controls">
             <textarea name="located_in" value="<?=$cvText?>" required disabled></textarea>
            </div>
          </div>
            </fieldset>
      </form>
    </div>
  </div>
  </div>
          
<!--/row--> 

