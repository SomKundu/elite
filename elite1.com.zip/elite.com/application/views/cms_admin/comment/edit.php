<?php 
$id='';
$fname='';
$mname='';
$lname='';
$sex='';
$dob='';
$address='';
$phone='';
$mobile='';
$fax='';
$qualification='';
$exp_years='';
$email='';
$city='';
$locality='';
$located_in='';
$exp_months='';
$exp_months='';
$any_other_brand_nearly='';
$parking_facility='';
$proposed_locality='';
$other_proposed_locality='';
$size_sq_ft='';
$frontage_ft='';
$height_ft='';
$investment='';
$owned_rented='';
$lease_years='';
$reason_investment='';
$funds_source='';
$owning_business='';
$other_proposed_locality='';
$franchise_business='';
$franchise_info='';
$franchise_info='';
$owning_business='';
$investment_in_month='';
$ulocfile='';
$work_exp_detail='';


  
 

foreach($getdetials as $d){
	$id=$d->id;
	$fname=$d->fname;
	$mname=$d->mname;	
	$lname=$d->lname;
	$address=$d->address;
	$phone=$d->phone; 
  $mobile=$d->mobile;
  $email=$d->email;
  $city=$d->city;
  $locality=$d->locality; 
  $located_in=$d->located_in;
  $sex=$d->sex;
  $dob=$d->dob; 
  $fax=$d->fax;
  $qualification=$d->qualification;
  $exp_years=$d->exp_years; 
  $exp_months=$d->exp_months;
  $any_other_brand_nearly=$d->any_other_brand_nearly;
  $parking_facility=$d->parking_facility;
  $proposed_locality=$d->proposed_locality; 
  $other_proposed_locality=$d->other_proposed_locality;
  $size_sq_ft=$d->size_sq_ft;
  $frontage_ft=$d->frontage_ft;
  $parking_facility=$d->parking_facility;
  $height_ft=$d->height_ft; 
  $investment=$d->investment;
  $owned_rented=$d->owned_rented;
  $lease_years=$d->lease_years;
  $reason_investment=$d->reason_investment;
  $funds_source=$d->funds_source;
  $owning_business=$d->owning_business;
  $other_proposed_locality=$d->other_proposed_locality;
  $franchise_business=$d->franchise_business;
  $franchise_info=$d->franchise_info;
  $franchise_info=$d->franchise_info;
  $owning_business=$d->owning_business;
  $investment_in_month=$d->owning_business;
  $ulocfile=$d->ulocfile;
  $work_exp_detail=$d->work_exp_detail;
}
?>

<style>
.form-horizontal textarea {
	width: 490px;
}
</style>
<link  href="<?=base_url()?>assets/cms_admin/sumoselect/css/sumoselect.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script type='text/javascript' src="<?=base_url()?>assets/cms_admin/sumoselect/js/jquery.sumoselect.js"></script>
<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
      <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>-->
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a>  
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <input type="hidden" name="id" value="<?=$id?>">
        <div class="control-group">
            <label class="control-label" for="typeahead">Fname<span>*</span></label>
            <div class="controls">
              <input type="title" name="fname" value="<?=$fname?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Mname<span>*</span></label>
            <div class="controls">
             <input type="text" name="mname" value="<?=$mname?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">Lname<span>*</span></label>
            <div class="controls">
             <input type="text" name="lname" value="<?=$lname?>" required disabled>
            </div>
          </div>
          
           
          <div class="control-group">
            <label class="control-label" for="date01">sex<span>*</span></label>
            <div class="controls">
             <input type="text" name="sex" value="<?=$sex?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">dob<span>*</span></label>
            <div class="controls">
             <input type="text" name="dob" value="<?=$dob?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">Address<span>*</span></label>
            <div class="controls">
             <input type="text" name="address" value="<?=$address?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">fax<span>*</span></label>
            <div class="controls">
             <input type="text" name="lname" value="<?=$lname?>" required disabled>
            </div>
          </div> 
           


          <div class="control-group">
            <label class="control-label" for="date01">qualification<span>*</span></label>
            <div class="controls">
             <input type="text" name="qualification" value="<?=$qualification?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">exp_years<span>*</span></label>
            <div class="controls">
             <input type="text" name="exp_years" value="<?=$exp_years?>" required disabled>
            </div>
          </div>
          
          <div class="control-group">
            <label class="control-label" for="date01">Phone<span>*</span></label>
            <div class="controls">
             <input type="text" name="phone" value="<?=$phone?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">Mobile<span>*</span></label>
            <div class="controls">
             <input type="text" name="mobile" value="<?=$mobile?>" required disabled>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">Email<span>*</span></label>
            <div class="controls">
             <input type="text" name="email" value="<?=$email?>" required disabled>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">City<span>*</span></label>
            <div class="controls">
             <input type="text" name="city" value="<?=$city?>" required disabled>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">locality<span>*</span></label>
            <div class="controls">
             <input type="text" name="locality" value="<?=$locality?>" required disabled>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="date01">Located_in<span>*</span></label>
            <div class="controls">
             <input type="text" name="located_in" value="<?=$located_in?>" required disabled>
            </div>
          </div>
           
          <div class="control-group">
            <label class="control-label" for="date01">exp_months<span>*</span></label>
            <div class="controls">
             <input type="text" name="exp_months" value="<?=$exp_months?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">work_exp_detail<span>*</span></label>
            <div class="controls">
             <input type="text" name="work_exp_detail" value="<?=$work_exp_detail?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">any_other_brand_nearly<span>*</span></label>
            <div class="controls">
             <input type="text" name="any_other_brand_nearly" value="<?=$any_other_brand_nearly?>" required disabled>
            </div>
          </div>
          
          


          <div class="control-group">
            <label class="control-label" for="date01">parking_facility<span>*</span></label>
            <div class="controls">
             <input type="text" name="parking_facility" value="<?=$parking_facility?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">proposed_locality<span>*</span></label>
            <div class="controls">
             <input type="text" name="proposed_locality" value="<?=$proposed_locality?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">other_proposed_locality<span>*</span></label>
            <div class="controls">
             <input type="text" name="other_proposed_locality" value="<?=$other_proposed_locality?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">size_sq_ft<span>*</span></label>
            <div class="controls">
             <input type="text" name="size_sq_ft" value="<?=$size_sq_ft?>" required disabled>
            </div>
          </div>
           
          <div class="control-group">
            <label class="control-label" for="date01">frontage_ft<span>*</span></label>
            <div class="controls">
             <input type="text" name="frontage_ft" value="<?=$frontage_ft?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">height_ft<span>*</span></label>
            <div class="controls">
             <input type="text" name="height_ft" value="<?=$height_ft?>" required disabled>
            </div>
          </div>
          

          <div class="control-group">
            <label class="control-label" for="date01">investment<span>*</span></label>
            <div class="controls">
             <input type="text" name="investment" value="<?=$investment?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">owned_rented<span>*</span></label>
            <div class="controls">
             <input type="text" name="owned_rented" value="<?=$owned_rented?>" required disabled>
            </div>
          </div>

        

          <div class="control-group">
            <label class="control-label" for="date01">lease_years<span>*</span></label>
            <div class="controls">
             <input type="text" name="lease_years" value="<?=$lease_years?>" required disabled>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">reason_investment<span>*</span></label>
            <div class="controls">
             <input type="text" name="reason_investment" value="<?=$reason_investment?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">funds_source<span>*</span></label>
            <div class="controls">
             <input type="text" name="funds_source" value="<?=$funds_source?>" required disabled>
            </div>
          </div>           

          <div class="control-group">
            <label class="control-label" for="date01">owning_business<span>*</span></label>
            <div class="controls">
             <input type="text" name="owning_business" value="<?=$owning_business?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">franchise_business<span>*</span></label>
            <div class="controls">
             <input type="text" name="franchise_business" value="<?=$franchise_business?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">franchise_info<span>*</span></label>
            <div class="controls">
             <input type="text" name="franchise_info" value="<?=$franchise_info?>" required disabled>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="date01">investment_in_month<span>*</span></label>
            <div class="controls">
             <input type="text" name="investment_in_month" value="<?=$investment_in_month?>" required disabled>
            </div>
          </div>


          <div class="control-group">
            <label class="control-label" for="date01">ulocfile<span>*</span></label>
            <div class="controls">
             <input type="text" name="ulocfile" value="<?=$ulocfile?>" required disabled>
            </div>
          </div>



          
            </fieldset>
      </form>
    </div>
  </div>
  </div>
          
<!--/row--> 

