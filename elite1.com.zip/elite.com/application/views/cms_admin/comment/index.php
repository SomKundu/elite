<div class="row-fluid sortable ui-sortable">
  <div class="box span12">
    <div class="box-header">
      <h2><i class="halflings-icon align-justify"></i><span class="break"></span>
        <?=$table_header?>
      </h2>
      
    </div>
   
    <div class="box-content">
      <table class="table table-bordered table-striped table-condensed">
        <thead>
          <tr>          
            <th>NAME</th>       
            <th>PHONE</th>             
            <th>EMAIL</th>          
            <th>COMMENT</th>
            <th>ACTION</th>           
          </tr>
        </thead>
        <tbody>
        
          <?php foreach($list as $d){?>
          <tr>            
            <td class="center"><?=$d->name?></td>            
            <td class="center"><?=$d->phone_no?></td>           
            <td class="center"><?=$d->email_id?></td>
            <td class="center"><?=$d->comments?></td> 
            <?php $flag=0;
              foreach($existing_customer_list as $el){
                if($el->email==$d->email_id || $el->phone_no==$d->phone_no ){
                  $flag++;
                }
              }?>
            <td class="center"><?php if($flag==0){?><a  href="<?=base_url().$addtoclient?><?=$d->id?>"> <i class="glyphicons-icon circle_plus"></i> </a><?php }?></td>                   
            
          </tr>
          <?php }?>
        </tbody>
      </table>
     
    </div>
  </div>
  <!--/span--> 
</div>
