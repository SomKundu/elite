<div class="row-fluid sortable ui-sortable">
  <div class="box span12">
    <div class="box-header">
      <h2><i class="halflings-icon align-justify"></i><span class="break"></span>
        <?=$table_header?>
      </h2>
      <div class="box-icon"> <a href="<?=base_url().$addNew?>" >
        <h2><i class="halflings-icon plus"> </i> Add New</h2>
        </a>  
      </div>
    </div>
   
    <div class="box-content">
      <table class="table table-bordered table-striped table-condensed">
        <thead>
          <tr>
            <th>ID</th>
            <th>TITLE</th>
            <th>DATE OF PUBLISH</th>        
            <th>REPEAT</th>
            <th>DESCRIPTION</th>            
            <th>SEND LIST</th>          
            <th>STATUS</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($list as $d){?>
          <tr>
            <td class="center"><?=$d->id?></td>
            <td class="center"><?=$d->title?></td>
            <td class="center"><?=$d->date_of_publish?></td>
            <td class="center"><span class="<?=($d->repeat=='y')?'label label-success':'label label-important'?>">
              <?=($d->repeat=='y')?'Active':'In-Active'?>
              </span></td>
            <td class="center"><?=$d->desc?></td>
            <td class="center">
            <?php $send_list=explode('|',$d->send_list);
            for($i=0;$i<count($send_list);$i++){foreach($emailList as $e){
              if($send_list[$i]==$e->id){?>
              <?='<p>'.$e->email.'</p>'?>
            <?php  }}}?></td>          
            <td class="center"><span class="<?=($d->status=='y')?'label label-success':'label label-important'?>">
              <?=($d->status=='y')?'Active':'In-Active'?>
              </span></td>
            <td class="center"><a class="btn btn-info" href="<?=base_url().$edit?><?=$d->id?>"> <i class="halflings-icon white edit"></i> </a> <a class="btn btn-danger" href="<?=base_url().$delete?><?=$d->id?>"> <i class="halflings-icon white trash"></i> </a></td>
          </tr>
          <?php }?>
        </tbody>
      </table>
     
    </div>
  </div>
  <!--/span--> 
</div>
