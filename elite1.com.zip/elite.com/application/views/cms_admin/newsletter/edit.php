<?php 
$id='';
$title='';
$date_of_publish='';
$repeat='';
$desc='';
$send_list='';
$status='';

foreach($getdetials as $d){
	$id=$d->id;
	$title=$d->title;
	$date_of_publish=$d->date_of_publish;	
	$repeat=$d->repeat;
	$desc=$d->desc;
	$send_list=$d->send_list; 
  $status=$d->status;
}
?>

<style>
.form-horizontal textarea {
	width: 490px;
}
</style>
<link  href="<?=base_url()?>assets/cms_admin/sumoselect/css/sumoselect.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script type='text/javascript' src="<?=base_url()?>assets/cms_admin/sumoselect/js/jquery.sumoselect.js"></script>
<div class="row-fluid sortable">
  <div class="box span12">
    <div class="box-header" data-original-title>
      <h2><i class="halflings-icon edit"></i><span class="break"></span><?=$form_header?></h2>
      <div class="box-icon"> 
      <!--<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
        <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>-->
        <a href="<?=base_url().$form_cancel?>"><h2><i class="halflings-icon remove"></i> Close</h2></a>  
      </div>
    </div>
    <div class="box-content">
      <form class="form-horizontal"  method="<?=$form_method?>" action="<?=base_url().$form_action?>" enctype="multipart/form-data" >
        <fieldset>
          <input type="hidden" name="id" value="<?=$id?>">
        <div class="control-group">
            <label class="control-label" for="typeahead">title<span>*</span></label>
            <div class="controls">
              <input type="title" name="title" value="<?=$title?>" required>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="date01">date_of_publish<span>*</span></label>
            <div class="controls">
             <input type="text" name="date_of_publish" value="<?=$date_of_publish?>" required>
            </div>
          </div>
           <div class="control-group">
            <label class="control-label" for="typeahead">send once</label>
            <div class="controls">
              <select name="repeat">
                 <option value="y" <?=($repeat=='y')?'selected':''?>>Yes</option>
                <option value="n" <?=($repeat=='n')?'selected':''?>>No</option>
              </select>
            </div>
            </div>
          <div class="control-group">
            <label class="control-label" for="date01">description</label>
            <div class="controls">
              <!--<textarea name="desc"  style="height:200px !important;"><?=$desc?></textarea>-->
              <textarea class="cleditor" name="desc" ><?=$desc?></textarea>
            </div>
          </div>         
           <div class="control-group">
            <label class="control-label" for="typeahead">send list<span>*</span></label>
            <div class="controls">
              <select name="send_list" required multiple="multiple">
                <option value="">-Select send list-</option>
                <?php foreach($email_edit as $e){?>
                <option value="<?=$e->id?>"><?=$e->email?></option>
                <?php }?>
              </select>
              <!--<select  name="send_list" class="testSelAll" multiple="multiple">
                <option value="">-Select send list-</option>
                <?php foreach($email_edit as $e){?>
                <option value="<?=$e->id?>"<?=($send_list==$e->id)?'selected':''?>><?=$e->email?></option>
                <?php }?>
              </select>-->
            </div>
          </div>   
          <div class="control-group">
            <label class="control-label" for="typeahead">status</label>
            <div class="controls">
              <select name="status">
                <option value="y" <?=($status=='y')?'selected':''?>>Active</option>
                <option value="n" <?=($status=='n')?'selected':''?>>In-Active</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" >Save changes</button>
            <a href="<?=base_url().$form_cancel?>">
            <button type="reset" >Cancel</button>
            </a> </div>
        </fieldset>
      </form>
    </div>
  </div>
  <!--/span--> 
  
</div>
<!--/row--> 
<script type="text/javascript">
      ;(function($){
        $(document).ready(function () {
          window.asd = $('.SlectBox').SumoSelect({ csvDispCount: 3 });
          window.testSelAll = $('.testSelAll').first().SumoSelect({okCancelInMulti:true, selectAll:true });
          });
        })(jQuery);
</script>
