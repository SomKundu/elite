<?php 
  $header='';
  $content='';
  foreach($data as $row){
    $header=$row->header;
    $content=$row->content;
  }
?> 		


<div class="SectionOuter SubpageWrap">
  <div class="SectionInner">
    <div>
        	<div class="SectionTitleBar" >
        		
                <!--<div class="TitleTxt" style="text-align:center">-->
                	<h1><?=$header?></h1>
                <!--</div>-->
            </div>
           <!--<div style="padding-top:30pt;margin-left:10%;margin-right:10%;">-->
           		<?=$content?> 
           	<!--</div>-->
           		
         </div>  	
  </div>
</div>         
       