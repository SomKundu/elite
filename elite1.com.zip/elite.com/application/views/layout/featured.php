      <div class="FeaturedPro">
      <div class="TitleWrap">
      	 <h1>Featured</h1>
      </div>
      
      	<ul id="flexiselDemo1"> 
            <li>
            	<div class="ProWrap">
                	<div class="ProImg">
                		<a href="#"><img src="<?=base_url()?>assets/images/pro-item.png" /></a>
                	</div>
                    <div class="ProDesc">
                    	<span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>	
                    </div>
                </div>
            </li>
            <li>
            	<div class="ProWrap">
                	<div class="ProImg">
                		<a href="#"><img src="<?=base_url()?>assets/images/pro-item1.png" /></a>
                	</div>
                    <div class="ProDesc">
                    	<span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>	
                    </div>
                </div>
            </li>
            <li>
            	<div class="ProWrap">
                	<div class="ProImg">
                		<a href="#"><img src="<?=base_url()?>assets/images/pro-item2.png" /></a>
                	</div>
                    <div class="ProDesc">
                    	<span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>	
                    </div>
                </div>
            </li>
            <li>
            	<div class="ProWrap">
                	<div class="ProImg">
                		<a href="#"><img src="<?=base_url()?>assets/images/pro-item3.png" /></a>
                	</div>
                    <div class="ProDesc">
                    	<span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>	
                    </div>
                </div>
            </li>
            <li>
            	<div class="ProWrap">
                	<div class="ProImg">
                		<a href="#"><img src="<?=base_url()?>assets/images/pro-item4.png" /></a>
                	</div>
                    <div class="ProDesc">
                    	<span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>	
                    </div>
                </div>
            </li>
            <li>
            	<div class="ProWrap">
                	<div class="ProImg">
                		<a href="#"><img src="<?=base_url()?>assets/images/pro-item.png" /></a>
                	</div>
                    <div class="ProDesc">
                    	<span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>	
                    </div>
                </div>
            </li>
            <li>
            	<div class="ProWrap">
                	<div class="ProImg">
                		<a href="#"><img src="<?=base_url()?>assets/images/pro-item1.png" /></a>
                	</div>
                    <div class="ProDesc">
                    	<span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>	
                    </div>
                </div>
            </li>
            <li>
            	<div class="ProWrap">
                	<div class="ProImg">
                		<a href="#"><img src="<?=base_url()?>assets/images/pro-item2.png" /></a>
                	</div>
                    <div class="ProDesc">
                    	<span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>	
                    </div>
                </div>
            </li>                                                         
        </ul>
        <div class="clr"></div>
      </div>
