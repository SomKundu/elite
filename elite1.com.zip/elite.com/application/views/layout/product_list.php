        <div class="PageRight">
        	<div class="SectionTitleBar">
            	<div class="TitleIcon Box4Icon"></div>
                <div class="TitleTxt">
                	Filtered Product List
                </div>
            </div>
        	<div class="ProBoxWrapWrap">
            	<div class="ProBoxWrap">
                  <div class="PBWIn">
                        <div class="NewTag">New</div>
                        <div class="ProImgDivH">
                            <div class="ProImgDivV">
                                <img src="images/product-img.png" alt=""/> 
                            </div>
                        </div>
                        <div class="ProInfo">
                            <h1 class="ProName">Wingtip Cognac Oxford</h1>
                            <div class="ProPrice">
                                <span class="OldPrice">1599.99</span>
                                <span class="NewPrice">499.99</span>
                            </div>
                            <div class="ReviewRate">
                                <span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                                <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                        </div>
                            <div class="ViewDeBtn">
                                <a href="product-details.html" class="ViewBTN">View details</a>
                            </div>
                        </div>
                  </div>
            	</div>            
            <div class="ProBoxWrap">
            	<div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img01.png" alt=""/> 
                        </div>
                  	</div>
                    <div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
           	  <div class="PBWIn">
              		<div class="NewTag">New</div>
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img.png" alt=""/> 
                        </div>
                  	</div>
               		<div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
            	<div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img01.png" alt=""/> 
                        </div>
                  	</div>
                    <div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
           	  <div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img.png" alt=""/> 
                        </div>
                  	</div>
               		<div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
            	<div class="PBWIn">
                	<div class="NewTag">New</div>
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img01.png" alt=""/> 
                        </div>
                  	</div>
                    <div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
           	  <div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img.png" alt=""/> 
                        </div>
                  	</div>
               		<div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
            	<div class="PBWIn">
                	<div class="NewTag">New</div>
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img01.png" alt=""/> 
                        </div>
                  	</div>
                    <div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
           	  <div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img.png" alt=""/> 
                        </div>
                  	</div>
               		<div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
            	<div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img01.png" alt=""/> 
                        </div>
                  	</div>
                    <div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
           	  <div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img.png" alt=""/> 
                        </div>
                  	</div>
               		<div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
            	<div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img01.png" alt=""/> 
                        </div>
                  	</div>
                    <div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
           	  <div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img.png" alt=""/> 
                        </div>
                  	</div>
               		<div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
            	<div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img01.png" alt=""/> 
                        </div>
                  	</div>
                    <div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
           	  <div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img.png" alt=""/> 
                        </div>
                  	</div>
               		<div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            <div class="ProBoxWrap">
            	<div class="PBWIn">
                	<div class="ProImgDivH">
                    	<div class="ProImgDivV">
               	  			<img src="images/product-img01.png" alt=""/> 
                        </div>
                  	</div>
                    <div class="ProInfo">
                    	<h1 class="ProName">Wingtip Cognac Oxford</h1>
                        <div class="ProPrice">
                        	<span class="OldPrice">1599.99</span>
                            <span class="NewPrice">499.99</span>
                        </div>
                        <div class="ReviewRate">
                        	<span><a href="#"><img src="images/prorating-icon.png" width="68" height="12"  alt=""/></a></span>
                            <span class="ReviewTxt"><a href="#">Review (10)</a></span>
                    </div>
                        <div class="ViewDeBtn">
                        	<a href="product-details.html" class="ViewBTN">View details</a>
                        </div>
                    </div>
              </div>
            </div>
            </div>
           <div class="clr"></div>
            
        </div>
    </div>
  </div>
