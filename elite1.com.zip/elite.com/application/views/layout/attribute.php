


  <div class="SectionOuter SubpageWrap">
  	<div class="SectionInner">
    	<div class="SidebarLeft">
        	<div class="SectionTitleBar">
            	<div class="TitleIcon FilterIcon"></div>
                <div class="TitleTxt">
                	Filter By
                </div>
            </div>
        	<div class="ProFilterMenu">
            	<div class="box">
                	<h1>CATEGORY</h1>
                    <ul class="FilmainMenu">
                    	<li class=""><label for="men"><input type="checkbox" id="men" > Men</label></li>
                        <li><label for="women"><input type="checkbox" id="women"> Women</label></li>
                        <li><label for="kids"><input type="checkbox" id="kids"> Kids</label></li>
                        <li><label for="juniors"><input type="checkbox" id="juniors"> Juniors</label></li>
                    </ul>
                </div>
                <div class="box">
                	<h1>Occassions</h1>
                    <ul class="FilmainMenu">
                    	<li class=""><label for="casual"><input type="checkbox" id="casual" > Casual</label></li>
                        <li><label for="comfort"><input type="checkbox" id="comfort"> Comfort</label></li>
                        <li><label for="party-wear"><input type="checkbox" id="party-wear"> Party wear</label></li>
                        <li><label for="ethnic"><input type="checkbox" id="ethnic"> Ethnic</label></li>
                        <li><label for="sports"><input type="checkbox" id="sports"> Sports</label></li>
                        <li><label for="formals"><input type="checkbox" id="formals"> Formals</label></li>
                    </ul>
                </div>
                <div class="box FilterSize">
                	<h1>Size</h1>
                    <ul>
                    	<li>5</li>
                        <li>6</li>
                        <li>7</li>
                        <li>8</li>
                        <li>9</li>
                        <li>10</li>
                    </ul>
                </div>
                <div class="box">
                	<h1>Offers</h1>
                    <ul class="FilmainMenu">
                    	<li class=""><label for="discounts"><input type="checkbox" id="discounts" > Discounts</label></li>
                        <li><label for="combo-Offer"><input type="checkbox" id="combo-Offer"> Combo-Offer</label></li>
                        <li><label for="seasonal-discount"><input type="checkbox" id="seasonal-discount"> Seasonal Discount</label></li>
                    </ul>
                </div>
                <div class="box">
                	<h1>Brand</h1>
                    <ul class="FilmainMenu">
                    	<li class=""><label for="a2-by-Aerosoles"><input type="checkbox" id="a2-by-Aerosoles" > A2 by Aerosoles</label></li>
                        <li><label for="adidas"><input type="checkbox" id="adidas"> Adidas</label></li>
                        <li><label for="aerosoles"><input type="checkbox" id="aerosoles"> Aerosoles</label></li>
                    </ul>
                </div>
                <div class="box FilterColor">
                	<h1>Color</h1>
                    <ul class="">
                    	<li style="background:#e4322c;"></li>
                        <li style="background:#202020;"></li>
                        <li style="background:#e5e5e5;"></li>
                        <li style="background:#ffd800;"></li>
                        <li style="background:#66b710;"></li>
                    </ul>
                </div>
                
                <div class="box">
                	<h1>Availability</h1>
                    <ul class="FilmainMenu">
                    	<li class=""><label for="exclude-stock"><input type="checkbox" id="exclude-stock" > Exclude Out of Stock</label></li>
                    </ul>
                </div>
                <!--<div class="box">
                	<h1>Price</h1>
                    <ul>
                    	<li class=""><label for="exclude-stock"><input type="checkbox" id="exclude-stock" > Exclude Out of Stock</label></li>
                    </ul>
                </div>-->
            </div>
        </div>