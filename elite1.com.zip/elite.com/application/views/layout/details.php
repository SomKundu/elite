<?php 
$id='';
$title='';
$code='';
$sub_cat_id='';
$details='';
$price='';
$status='';
$meta_tag='';
$meta_description='';
$meta_content='';
$discount='';
$availablity='';
$new_arrivals='';
$Offer_of_the_day='';
$best_seller='';
$weekly_offer='';
$special_discount='';
$featured='';
$image1='';
$image2='';
$image3='';
$image4='';
$image5='';
$image6='';
$image7='';
$image8='';
foreach($detail as $d){
    $id=$d->id;
    $title=$d->title;
    $code=$d->code; 
    $sub_cat_id=$d->sub_cat_id;
    $details=$d->details;
    $price=$d->price;
    $status=$d->status;
    $meta_tag=$d->meta_tag; 
    $status=$d->status;
    $meta_description=$d->meta_description;
    $meta_content=$d->meta_content;
    $discount=$d->discount;
    $availablity=$d->availablity;
    $new_arrivals=$d->new_arrivals;
    $Offer_of_the_day=$d->Offer_of_the_day;
    $best_seller=$d->best_seller;
    $weekly_offer=$d->weekly_offer;
    $special_discount=$d->special_discount;
    $featured=$d->featured;
    $image1=$d->image1;
    $image2=$d->image2;
    $image3=$d->image3;
    $image4=$d->image4;
    $image5=$d->image5;
    $image6=$d->image6;
    $image7=$d->image7;
    $image8=$d->image8;
}
?>
?>
      <div class="PageRight">
        <div class="ProDetails">
            <h1 class="ProDTitle">ROCK & CANDY GIRL</h1>
            <div class="">
            <div class="ProDImgWrap">
            <div class="cfix">
              <div class="cfix"> <a href="<?=base_url()?>assets/imgProd/triumph_big1.jpg" class="jqzoom" 
              rel='gal1'  title="triumph" > 
              <img src="<?=base_url()?>assets/images/triumph_small1.png"  title="triumph"  
              style="border: 1px solid #ececec;"> </a> </div>
              <br/>
              <div class="clearfix" >
                <ul id="thumblist" class="clearfix" >
                  <li> <a class="zoomThumbActive" href='javascript:void(0);' 
                  rel="{gallery: 'gal1', smallimage: '.<?=base_url()?>assets/imgProd/triumph_small1.jpg',largeimage: '.<?=base_url()?>assets/imgProd/triumph_big1.jpg'}">
                  <img src='<?=base_url()?>assets/imgProd/thumbs/triumph_thumb1.jpg' width="100" /></a> </li>
                </ul>
              </div>
            </div>
          </div>
            <div class="ProInfoDetail">
            <div class="OfferTag"><img src="<?=base_url()?>assets/images/offer-tag.png"  alt=""/></div>
            <div class="PriceRow">
                <label>Price:</label><span class="NowPrice">499.99</span><span class="OldPrice">999.99</span>
            </div>
            <div class="pdRow review">
                <p>Be the first to review this product</p>
                <a href="#">2 Review(s)</a>&nbsp;  |  &nbsp;<a href="#">Write Your Review</a>
            </div>
            <div class="pdRow SizeWrap">
                <label>Size:</label>
                <ul>
                    <li>5</li>
                    <li>6</li>
                    <li>7</li>
                    <li>8</li>
                    <li>9</li>
                    <li>10</li>
                </ul>
            </div>
            <div class="pdRow">
              <label>Availability:</label>
              <span class="PStock">In stock</span>
            </div>
            <div class="pdRow">
              <label>Availabile Color:</label>
              <ul class="Acolor">
                    <li style="background:#e4322c;"></li>
                    <li style="background:#202020;"></li>
                    <li style="background:#e5e5e5;"></li>
                    <li style="background:#ffd800;"></li>
                    <li style="background:#66b710;"></li>
                </ul>
            </div>
            <div class="pdRow">
              <label>Product Code:</label>
                <span>sp4</span>
            </div>
            <div class="pdRow">
              <label>QUICK OVERVIEW:</label>
                <p>Lorem ipsum dolor sit amet, con sec tetur adipisicing elit, sed do eiusmod orem ipsum dolor. Dolor sit amet, con sec tetur adipisicing elit...</p>
            </div>
          </div>
          
          </div>
          <div class="ProDesc1">
            <div class="container1">            
                <h2>Product Description</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eu ultricies nibh, eget hendrerit nibh. Nullam auctor, sem a fringilla vulputate, ante magna euismod purus, ac malesuada mi sem sit amet nisl. Integer id mauris dictum nulla semper varius. Vivamus ullamcorper faucibus nulla eu sagittis. Fusce congue luctus sapien dictum commodo. In vestibulum, mauris et cursus sodales, dui mi mattis dui, sed blandit nulla massa vel dolor. Mauris at ante id metus scelerisque ultrices. Nullam id orci semper, tempus magna nec, condimentum eros. Etiam aliquam viverra molestie. Nam et ipsum sem. Proin ac porta leo. Nam condimentum dapibus tortor, eu posuere velit pharetra nec. Etiam mollis erat feugiat semper commodo. Vivamus in risus a nulla tincidunt aliquet. Nunc sem erat, hendrerit quis purus eu, consectetur mattis massa. Nunc non tincidunt turpis, vel suscipit dui.</p>
                    
                <h2>General Info</h2>
                <p>Duis rhoncus dui purus, non vehicula libero pulvinar in. Nullam blandit sodales dictum. Nulla facilisi. Pellentesque vulputate massa ac dignissim pulvinar. Aliquam erat volutpat. Sed porttitor, dui at facilisis semper, tortor elit tincidunt nisi, eu mollis urna quam sit amet nisi. Maecenas et justo tortor. Phasellus id velit varius sapien tempus consectetur. Suspendisse sit amet ipsum felis. Etiam urna metus, ornare a pellentesque non, accumsan vel nunc. Nam vehicula, dui vel tristique auctor, nibh nisl venenatis justo, eget tincidunt dui lorem ac nibh.</p>
                
                <h2>Shoe Details</h2>
                <p>Ut nec tellus eget urna placerat venenatis vitae et felis. Vivamus vitae suscipit nunc, ac sollicitudin justo. Nulla facilisi. Ut tempus lectus quis mi auctor pretium. Nulla facilisi. Duis et aliquet diam. Suspendisse in mollis ipsum. Donec pharetra, metus at sodales lacinia, urna libero euismod lectus, ut egestas dui sapien fermentum purus. Maecenas non nulla varius, porta dolor rhoncus, lacinia nibh. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed ut nunc arcu. Maecenas laoreet augue nisi, et bibendum nisi viverra id. Etiam risus nisl, vehicula eget ultricies vel, viverra vel lorem. Praesent eu nisl lectus. Curabitur porta aliquet urna, eu fringilla augue rutrum feugiat. Morbi nibh orci, lobortis eget mattis nec, eleifend ac lectus.</p>
                 
                <h2>Occession</h2>
                <p>In quis interdum nunc. Vivamus sit amet nisi risus. Quisque sed pretium lorem. Praesent aliquam massa id euismod adipiscing. Integer dignissim felis id volutpat mollis. Mauris hendrerit, dolor sed aliquet dapibus, eros diam lobortis lacus, ut vestibulum ante sapien et metus. Pellentesque ullamcorper elementum lacus, et venenatis eros molestie gravida. Quisque cursus risus quis semper sollicitudin. Suspendisse faucibus tellus sit amet purus rhoncus congue. Quisque euismod eget diam quis dignissim.</p> 
                                
                <h2>Material</h2>
                <p>In quis interdum nunc. Vivamus sit amet nisi risus. Quisque sed pretium lorem. Praesent aliquam massa id euismod adipiscing. Integer dignissim felis id volutpat mollis. Mauris hendrerit, dolor sed aliquet dapibus, eros diam lobortis lacus, ut vestibulum ante sapien et metus. Pellentesque ullamcorper elementum lacus, et venenatis eros molestie gravida. Quisque cursus risus quis semper sollicitudin. Suspendisse faucibus tellus sit amet purus rhoncus congue. Quisque euismod eget diam quis dignissim.</p> 
                
                <h2>Maintainance</h2>
                <p>In quis interdum nunc. Vivamus sit amet nisi risus. Quisque sed pretium lorem. Praesent aliquam massa id euismod adipiscing. Integer dignissim felis id volutpat mollis. Mauris hendrerit, dolor sed aliquet dapibus, eros diam lobortis lacus, ut vestibulum ante sapien et metus. Pellentesque ullamcorper elementum lacus, et venenatis eros molestie gravida. Quisque cursus risus quis semper sollicitudin. Suspendisse faucibus tellus sit amet purus rhoncus congue. Quisque euismod eget diam quis dignissim.</p>
                    
                </div>
          </div>
          <div class="RelatedPro">
            <ul id="flexiselDemo1"> 
            <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="images/pro-item.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>
            <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="images/pro-item1.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>
            <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="images/pro-item2.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>
            <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="images/pro-item3.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>
            <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="images/pro-item4.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>
            <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="images/pro-item.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>
            <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="images/pro-item1.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>
            <li>
                <div class="ProWrap">
                    <div class="ProImg">
                        <a href="#"><img src="images/pro-item2.png" /></a>
                    </div>
                    <div class="ProDesc">
                        <span class="ProName">Wingtip Cognac Oxford</span>
                        <span class="ProCat">Catrgory: Women</span>
                        <span class="ProBtn"><a href="#">View Details</a></span>    
                    </div>
                </div>
            </li>                                                         
        </ul>
          </div>
          <div class="clr"></div>
        </div>
        <div class="clr"></div>
      </div>
    </div>
  </div>
