  <div class="SectionOuter FooterWrap">
  	<div class="SectionInner">
    	<div class="FootTop">
            <div class="FootBox">
                <ul>
<?php $countContent=count($get_content);
$count=0;$tab=0;
foreach($get_content as $row){$count++?>
<li><a href="<?=base_url().$content_management_link.$row->id?>"><?=$row->header?></a></li> 
<?php if($count%6==0){$tab++;echo '</ul></div><div class="FootBox"><ul>';}
if($tab>=2){break;}?>
<?php }

            ?>
                </ul>
            </div>
<?=($tab==0)?'<div class="FootBox"><ul><li><a> </a></li></ul></div>':''?>

            <div class="FootBox"><a href="<?=base_url().$storelocator_link?>">
            	<div class="MapWrap"><img src="<?=base_url()?>assets/images/map-img.jpg" alt=""/></div>
<p>7, Grant Lane, Kolkata 700012</p></a>
            </div>
            <div class="FootBox">
            	<form action="<?=base_url().$newsletter_link?>" name="form" method="post">
                    <input class="EmailTxt" required type="text" value="" placeholder="Enter your mail address" name="email">
                    <input  type="hidden" value="<?=current_url()?>"name="curUrl">
                    <input type="submit" value="Subscribe" class="SubsBtn">
                </form>
            </div>
            <div class="clr"></div>
        </div>
    </div>
    <div class="FootBot">
    	&copy; All Rights Reserved
    </div>
  </div>
  
</div>
<div class="slide-out-div" style="z-index:99999;"> <a class="handle" href="http://link-for-non-js-users" style="z-index:99999;">Content</a>
  <h3>Contact Us</h3>
  <div>
    <form  method="post" action="<?=base_url().$comment_link?>">
      <input  type="hidden" value="<?=current_url()?>" name="current_url">
      <div class="FormRow">
        <label>Name:</label>
        <input type="text" name="name" value="write your name" onfocus="if(this.value == 'write your name') { this.value = '';}" onblur="if(this.value == '') { this.value = 'write your name';}">
      </div>
      <!--<div class="FormRow">
        <label>First name:</label>
        <input type="text" name="first_name" value="write your first name" onfocus="if(this.value == 'write your first name') { this.value = '';}" onblur="if(this.value == '') { this.value = 'write your first name';}">
      </div>
      <div class="FormRow">
        <label>Last name:</label>
        <input type="text" name="last_name" value="write your last Name" onfocus="if(this.value == 'write your last Name') { this.value = '';}" onblur="if(this.value == '') { this.value = 'write your last Name';}">
      </div>-->
      <div class="FormRow">
        <label>Phone No:</label>
        <input type="text" name="phone_no" value="write your phone number" onfocus="if(this.value == 'write your phone number') { this.value = '';}" onblur="if(this.value == '') { this.value = 'write your phone number';}">
      </div>
      <div class="FormRow">
        <label>Email ID:</label>
        <input type="text" name="email_id" value="write your email id" onfocus="if(this.value == 'write your email id') { this.value = '';}" onblur="if(this.value == '') { this.value = 'write your email id';}">
      </div>
      <div class="FormRow">
        <label>Comments:</label>
        <textarea  name="Comments" cols="25" rows="6" onfocus="if(this.value == 'write your comments') { this.value = '';}" onblur="if(this.value == '') { this.value = 'write your comments';}">write your comments</textarea>
      </div>
      <div class="FormRow">
        <input type="submit" value="Submit" class="ContactSub">
      </div>
    </form>
  </div>
</div>






<script src="<?=base_url()?>assets/js/script.js"></script>
<?php if($this->uri->segment(2)=='detail'&&$this->uri->segment(1)=='product'&&$this->uri->segment(3)>0){?>
<script src="<?=base_url()?>assets/js/expandy.min.js"></script>
    <script>
        jQuery('.container1').makeExpander({
            toggleElement: 'h2',
            jqAnim: true,
            showFirst: true,
            accordion: true,
            speed: 400,
            indicator: 'triangle'
        });
    </script>
<?php } ?>
<meta name="google-site-verification" content="aLpyXTTkvY_8pUR5SWl3BUI68WlMmUgDz_0ELpVIi4A" />
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-66236953-1', 'auto');
  ga('send', 'pageview');

</script>
</body>
</html>