<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>Elite</title>

<!-- Main CSS -->
<link href="<?=base_url()?>assets/css/style.css" rel='stylesheet' type='text/css' />
<!-- Slidebars CSS -->
<link rel="stylesheet" href="<?=base_url()?>assets/css/jquery.bxslider.css">
<link href="<?=base_url()?>assets/css/jquery.jqzoom.css" rel="stylesheet" type="text/css" media="all" />
<link rel="icon" type="images/ico" href="<?=base_url()?>assets/images/favicon.ico"  />



<script type='text/javascript' src="<?=base_url()?>assets/js/jquery-1.11.2.min.js"></script>

<script src="<?=base_url()?>assets/js/jquery.bxslider.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.tabSlideOut.v1.3.js"></script>
<script src="<?=base_url()?>assets/js/jquery.jqzoom-core.js" type="text/javascript"></script>





<script>
$(function(){
 $('.slide-out-div').tabSlideOut({
	 tabHandle: '.handle',                              //class of the element that will be your tab
	 pathToTabImage: '<?=base_url()?>assets/images/contact-slide-btn.png',          //path to the image for the tab (optionaly can be set using css)
	 imageHeight: '43px',                               //height of tab image
	 imageWidth: '53px',                               //width of tab image    
	 tabLocation: 'right',                               //side of screen where tab lives, top, right, bottom, or left
	 speed: 400,                                        //speed of animation
	 action: 'click',                                   //options: 'click' or 'hover', action to trigger animation
	 topPos: '117px',                                   //position from the top
	 fixedPosition: true                               //options: true makes it stick(fixed position) on scroll
 });
});

</script><!-- For Mobile Menu -->

<script>
$(function(){
 $('.slide-out-div2').tabSlideOut({
	 tabHandle: '.handle2',                              //class of the element that will be your tab
	 pathToTabImage: '<?=base_url()?>assets/images/filter-option-icon.png',          //path to the image for the tab (optionaly can be set using css)
	 imageHeight: '30px',                               //height of tab image
	 imageWidth: '184px',                               //width of tab image    
	 tabLocation: 'left',                               //side of screen where tab lives, top, right, bottom, or left
	 speed: 400,                                        //speed of animation
	 action: 'click',                                   //options: 'click' or 'hover', action to trigger animation
	 topPos: '112px',                                   //position from the top
	 fixedPosition: true                               //options: true makes it stick(fixed position) on scroll
 });
});

</script><!-- For Mobile Menu -->




<script>
$(document).ready(function() {
	$('.bxslider').bxSlider({
	  mode: 'fade',
	  captions: true,
	  auto: true,
	  autoHover: true
	});
});
</script>

<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.flexisel.js"></script>
<script type="text/javascript">

$(window).load(function() {
    $("#flexiselDemo1").flexisel({
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 3
            },
            tablet: { 
                changePoint:768,
                visibleItems: 4
            }
        }
    });    
});
</script>
<script type="text/javascript">
$(document).ready(function() {
  $('.jqzoom').jqzoom({
    zoomType: 'standard',
    xOffset: 'right',
    hideEffect:'fadeout',
    lens:true,
    preloadImages: false,
    zoomWidth: 400,
    alwaysOn: false
    
  });
});
</script>
<script>
$(document).ready(function() {
	$(window).on('resize', function() {		
		var proboxWidth = ($(".ProImgDivH").width());	
		$(".ProImgDivV").width(proboxWidth);
	}).trigger('resize'); // Trigger resize handlers. 
})
</script>
    
<script>
function onclickNewTab(pageUrl){
	var win = window.open(pageUrl, '_blank');
  	win.focus();
}
</script>    


<!-- For Mobile Menu -->
<script src="<?=base_url()?>assets/js/modernizr.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.slicknav.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('#menu').slicknav();
});
</script>


<link rel="stylesheet" href="<?=base_url()?>assets/css/style-menu.css">
<link rel="stylesheet" href="<?=base_url()?>assets/css/slicknav.css">

<link href='http://fonts.googleapis.com/css?family=Dosis' rel='stylesheet' type='text/css'>
</head>

<body>
<div class="SiteContentWrap top">
  <div class="HeadTWrap navHighlighter">
    <div class="SectionOuter SiteTopBar">
      <div class="SectionInner">
        <div class="SignWrap pull-right">
          <ul>
            <!--<li><a href="#">Sign In</a></li>
            <li><a href="#">Sign Up</a></li>-->
            
          </ul>
        </div>
        <div class="SocialIcon pull-right">
          <ul>
            <li>
            	<a href="#" onClick="onclickNewTab('https://www.facebook.com/eliteshoe/');">
            		<img src="<?=base_url()?>assets/images/fb-icon.png" title="Facebook" alt="Facebook" style="display:block;"/>
            	</a>
            </li>
            <li>
                <a href="#" onClick="onclickNewTab('https://twitter.com/elitefootwear/');">
                    <img src="<?=base_url()?>assets/images/t-icon.png" title="Twitter" alt="Twitter" style="display:block;"/>
                </a>
            </li>
            <li>
                <a href="#" onClick="onclickNewTab('https://www.youtube.com/channel/UC2oFzkB5TtgNs6P4nP4tpQg/');">
                	<img src="<?=base_url()?>assets/images/yout-icon.png" title="Youtube" alt="Youtube" style="display:block;"/>
                </a>
            </li>
          </ul>
        </div>
        <div class="clr"></div>
      </div>
    </div>
    <div class="SectionOuter HeaderWrap">
      <div class="SectionInner">
        <div class="Logo">
        	<a href="<?=base_url()?>"><img src="<?=base_url()?>assets/images/elite_logo_126.png" title="Logo" alt="Logo" style="display:block;"/></a>
        	<a href="<?=base_url()?>"><img src="<?=base_url()?>assets/images/elite -126-txt.gif" title="Logo" alt="Logo"/></a>
        </div>
        <div class="MainNavigation">
          <ul id="menu">
            <li <?=($this->uri->segment(1)==''||$this->uri->segment(1)=='home')?'class="Mactive"':''?>><a href="<?=base_url()?>">Home</a></li>
            <li <?=($this->uri->segment(1)=='corporate')?'class="Mactive"':''?>><a href="<?=base_url().$corporate_link?>">Corporate</a></li>
            <li <?=($this->uri->segment(1)=='product')?'class="Mactive"':''?>><a href="javascript:void(0)">Product</a>
              <ul class="SubMenuWrap">
                    
                    <?php foreach($cat_list as $cat){?>
                      <div class="SubMenuBclok">
                        <a href="<?=base_url().$product_list.$cat->id.'/0'?>"><div class="MenuTitle"><?=$cat->title?></div></a>
                        <ul class="SubMenu">
                          <?php foreach($sub_cat_list as $sub){if($sub->parent_id==$cat->id){?>
                            <li><a href="<?=base_url().$product_list.$cat->id.'/'.$sub->id?>"><?=$sub->title?></a></li>
                          <?php }}?>
                            
                        </ul>
                      </div>
                    <?php }?>
                    
                </ul>
            </li>
            <li <?=($this->uri->segment(1)=='media')?'class="Mactive"':''?>><a href="<?=base_url().$media_link?>">Media</a></li>
            <li <?=($this->uri->segment(1)=='storelocator')?'class="Mactive"':''?>><a href="<?=base_url().$storelocator_link?>">Store Locator</a></li>
            <li <?=($this->uri->segment(1)=='joinus')?'class="Mactive"':''?>><a href="javascript:void(0)">Join Us</a>
            <ul class="SubMenuWrap2">
              <div class="SubMenuBclok">
                <a href="<?=base_url().$joinus_link?>"><div class="MenuTitle">Career</div></a>
                <a href="<?=base_url().$franchise_link?>"><div class="MenuTitle">Franchise</div></a>
              </div>
                </ul></li>
          </ul>
        </div>
        <div class="clr"></div>
      </div>
    </div>
    
  </div>
  