<!--
<div class="FeaturedPro">
    <div class="TitleWrap">
    	 <h1>Featured</h1>
    </div>

	<ul id="flexiselDemo1"> 
    <?php foreach($featured as $l){?>
        <li>
            <div class="ProWrap">
                <div class="ProImg">
                    <a href="#"><img src="<?=base_url()?>uploads/product/<?=$l->image1?>" width="150" /></a>
                </div>
                <div class="ProDesc">
                    <span class="ProName"><?=$l->title?></span>
                    <span class="ProCat">Catrgory: <?=$l->subcatagory?></span>
                    <span class="ProBtn"><a href="<?=base_url().$product_details.$l->id?>">View Details</a></span>    
                </div>
            </div>
        </li>
    <?php }?>                                                        
    </ul>
    <div class="clr"></div>
</div>
-->
<script>
$(document).ready(function() {
    $('.bxslider2').bxSlider({
      minSlides: 2,
      maxSlides: 5,
      slideWidth: 230,
      moveSlides: 1,
      pager:false,
      slideMargin: 0
    });
});
</script>
<style>
    .bxslider2 .ProWrap .ProImg a img { width:100%; }
</style>
<style type="text/css">
.FeaturedPro .bx-wrapper .bx-controls-direction a {top: 55px;}
.FeaturedPro .bx-wrapper .bx-controls-direction a.bx-prev { left: -10px;}
.FeaturedPro .bx-wrapper .bx-controls-direction a.bx-next { right: -10px;}
</style>

<div class="FeaturedPro">
    <div class="TitleWrap">
         <h1>Featured</h1>
    </div>
<? //php echo count($featured) ?>
    <ul class="bxslider2"> 
    <?php foreach($featured as $l){?>
        <li>
            <div class="ProWrap">
                <div class="ProImg">
                    <a href="#"><img src="<?=base_url()?>uploads/product/<?=$l->image1?>" width="150" /></a>
                </div>
                <div class="ProDesc">
                    <span class="ProName"><?=$l->title?></span>
                    <span class="ProCat">Catrgory: <?=$l->subcatagory?></span>
                    <span class="ProBtn"><a href="<?=base_url().$product_details.$l->id?>">View Details</a></span>    
                </div>
            </div>
        </li>
    <?php }?>                                                        
    </ul>
    <div class="clr"></div>
</div>
