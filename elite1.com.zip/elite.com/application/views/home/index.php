<?php
$this->load->view($bannerView,$bannerData);
$this->load->view($featuredView,$featuredData);
$this->load->view($promotionView,$promotionData);