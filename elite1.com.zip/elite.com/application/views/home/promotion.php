      <div class="LocationBoxWrap">
      	<div class="box">
        	<div class="BoxTitle">Find a Location <span class="TitleArrow"></span></div>
            <div class="BoxImg">
       	    	<a href="#"><img src="<?=base_url()?>assets/images/Findalocation-img.jpg" alt=""/></a>
            </div>
        </div>
      	<div class="box">
        	<div class="BoxTitle">General Store <span class="TitleArrow"></span></div>
            <div class="BoxImg">
   	        	<a href="#"><img src="<?=base_url()?>assets/images/genaral-store-img.jpg" alt=""/></a>
            </div>
        </div>
        <div class="box">
        	<div class="BoxTitle">Handcrafted with Pride <span class="TitleArrow"></span></div>
            <div class="BoxImg">
   	        	<a href="#"><img src="<?=base_url()?>assets/images/handcraft-img.jpg"  alt=""/></a>
            </div>
        </div>
        <div class="box">
        	<div class="BoxTitle">Heritage <span class="TitleArrow"></span></div>
            <div class="BoxImg">
       	    	<a href="#"><img src="<?=base_url()?>assets/images/haritage-img.jpg" alt=""/></a>
            </div>
        </div>
      </div>
    </div>
    <div class="clr"></div>
  </div>      
