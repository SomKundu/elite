  <div class="SSliderWrap">
  	<ul class="bxslider">
    <?php foreach($banner as $l){?>
      <li><img src="<?=base_url()?>uploads/banner/<?=$l->image?>" alt=""/></li>
    <?php }?>
    </ul>
  	<div class="StoreLocWrap SectionInner">
    	<div class="StoreLoc">
        	<a href="<?=base_url().$storelocator_link?>"><img src="<?=base_url()?>assets/images/store-location-img.png"  alt=""/></a>
        </div>
    </div>
  </div>
  <div class="SectionOuter">
    <div class="SectionInner">
      <div class="MeWoBtnWrap">
<?php if(isset($promotionalCatagoryList)){foreach ($promotionalCatagoryList as $pcat){?>      
        <a href="<?=base_url().$productListOnCat.$pcat->id.'/0/'?>" class="MenBtn">
        <img src="<?=base_url()?>uploads/prom_img/<?=$pcat->prom_img?>" alt=""/></a>
<?php }}?>       
      </div>
      <div class="AddSec">
        <!--<a href="#"><img src="<?=base_url()?>assets/images/add-img.png" alt=""/></a>-->
<?php if(count($discountList)>0 && isset($discountList)){?>
        <div class="AddSecInn">
        	<div class="OfferDIV">
            	<a href="<?=base_url().$storelocator_link?>">
                	<div class="BgTiOff">
                	<div class="BTOl"><img src="<?=base_url()?>assets/images/butn-imgoffer2.png" alt=""/></div>
                    <img src="<?=base_url()?>assets/images/offer-logo.png" alt=""/>
            		<span class="FlatTxt">FLAT <?=$MaxDiscount[0]->MaxDiscountVal?>% OFF</span>
                	<div class="BTOr"><img src="<?=base_url()?>assets/images/butn-imgoffer.png" alt=""/></div>
                </div>
            	</a>
            </div>
            <div class="OfferPro">
			<?php $i=0;foreach($discountList as $dl){
            	if($dl->image1<>'' && file_exists('./uploads/product/'.$dl->image1)){$i++;?>
            	<div class="ProBox">
            		<a href="<?=base_url().$product_link.$dl->id?>">
            			<img src="<?=base_url()?>uploads/product/<?=$dl->image1?>" alt=""/>
            		</a>
            	</div>  
            <?php if($i==6){break;}}}?> 
                                
            </div>
            
            <div class="clr"></div>
        </div>
<?php }?>
      </div>
  