<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script>
$(function() {
	$( "#datepicker" ).datepicker();
});
</script>
<style>
.JoinEmpoye { padding:10px; border: #F3F3F3 thin solid; margin: 0 0 20px 0;}
.JoinEmpoye .FRow { width:100%; padding:10px 0; }
.JoinEmpoye .FRow .FRowSec { width:30%; float:left; margin:0 1.5% 0 0}
.JoinEmpoye .FRow .FRowSec label { padding-bottom:5px; display:block;}
.exp_select{ max-width:48% !important;float:left; margin:0 1.5% 0 0;}

</style>

<div class="SectionOuter SubpageWrap">
    <div class="SectionInner">
        <!--####################################################-->
        <form action="<?=base_url().$form_action?>" method="<?=$form_method?>" enctype="multipart/form-data">
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>E-mail :</label>
                    <input required type="email" id="email" name="email" />
                </div>
                <!--<div class="FRowSec">
                    <label>Password :</label>
                    <input type="password" id="password" name="password" />
                </div>
                <div class="FRowSec">
                    <label>Confirm Password :</label>
                    <input type="password" id="cpassword" name="cpassword" />
                </div>-->
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>First Name :</label>
                    <input required name="fname" type="text" id="fname" />
                </div>
                <div class="FRowSec">
                    <label>Middle Name ( Optional ) :</label>
                    <input name="mname" type="text" id="mname" />
                </div>
                <div class="FRowSec">
                    <label>Last Name :</label>
                    <input required name="lname" type="text" id="lname" />
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>Gender  :</label>
                    <select required name="sex" >
                        <option value="m">Male</option>
                        <option value="f">Female</option>
                    </select>
                </div>
                <div class="FRowSec">
                    <label>Date of Birth :</label>
                    <input required name="dob" type="text" id="datepicker"/>
                </div>
                <div class="FRowSec">
                
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>Phone :</label>
                    <input required name="phone" type="text" id="phone" />
                </div>
                <div class="FRowSec">
                    <label>Mobile ( Optional ) :</label>
                    <input name="mobile" type="text" id="mobile" />
                </div>
                <div class="FRowSec">
                    <label>State / City :</label>
                    <select required name="state" id="state"maxlength="50" >
<option value="0">- Select Current Location -</option>
<option value="Ahmedabad">Ahmedabad</option>
<option value="Alabama">Alabama</option>
<option value="Alaska">Alaska</option>
<option value="Alberta">Alberta</option>
<option value="Andhra Pradesh- Anantapur">Andhra Pradesh- Anantapur</option>
<option value="Andhra Pradesh- Guntakal">Andhra Pradesh- Guntakal</option>
<option value="Andhra Pradesh- Guntur">Andhra Pradesh- Guntur</option>
<option value="Andhra Pradesh- Hyderabad/ Secunderabad">Andhra Pradesh- Hyderabad/ Secunderabad</option>
<option value="Andhra Pradesh- Kakinanda">Andhra Pradesh- Kakinanda</option>
<option value="Andhra Pradesh- Nellore">Andhra Pradesh- Nellore</option>
<option value="Andhra Pradesh- Nizamabad">Andhra Pradesh- Nizamabad</option>
<option value="Andhra Pradesh- Other">Andhra Pradesh- Other</option>
<option value="Andhra Pradesh- Tirupati">Andhra Pradesh- Tirupati</option>
<option value="Andhra Pradesh- Vijayawada">Andhra Pradesh- Vijayawada</option>
<option value="Andhra Pradesh- Visakapatnam">Andhra Pradesh- Visakapatnam</option>
<option value="Andhra Pradesh- Warangal">Andhra Pradesh- Warangal</option>
<option value="Arizona">Arizona</option>
<option value="Arkansas">Arkansas</option>
<option value="Arunachal Pradesh -Itanagar">Arunachal Pradesh -Itanagar</option>
<option value="Arunachal Pradesh – Other">Arunachal Pradesh – Other</option>
<option value="Assam- Guwahati">Assam- Guwahati</option>
<option value="Assam- Other">Assam- Other</option>
<option value="Assam- Silchar">Assam- Silchar</option>
<option value="Australia">Australia</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangalore">Bangalore</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Bihar- Bhagalpur">Bihar- Bhagalpur</option>
<option value="Bihar- Other">Bihar- Other</option>
<option value="Bihar- Patna">Bihar- Patna</option>
<option value="British Columbia">British Columbia</option>
<option value="California">California</option>
<option value="Canada">Canada</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chandigarh- Bhillai">Chandigarh- Bhillai</option>
<option value="Chattisgarh – Bilaspur">Chattisgarh – Bilaspur</option>
<option value="Chattisgarh – Other">Chattisgarh – Other</option>
<option value="Chattisgarh – Raipur">Chattisgarh – Raipur</option>
<option value="Chennai">Chennai</option>
<option value="Colorado">Colorado</option>
<option value="Connecticut">Connecticut</option>
<option value="Dadra & Nagar Haveli- Silvassa">Dadra & Nagar Haveli- Silvassa</option>
<option value="Daman& Diu">Daman& Diu</option>
<option value="Delaware">Delaware</option>
<option value="Delhi">Delhi</option>
<option value="Delhi/NCR ">Delhi/NCR </option>
<option value="Delhi/NCR">Delhi/NCR</option>
<option value="District of Columbia">District of Columbia</option>
<option value="Dubai/UAE">Dubai/UAE</option>
<option value="Florida">Florida</option>
<option value="France">France</option>
<option value="Georgia">Georgia</option>
<option value="Germany">Germany</option>
<option value="Goa">Goa</option>
<option value="Guam">Guam</option>
<option value="Gujarat- Ahmedabad">Gujarat- Ahmedabad</option>
<option value="Gujarat- Anand">Gujarat- Anand</option>
<option value="Gujarat- Ankleshwar">Gujarat- Ankleshwar</option>
<option value="Gujarat- Baroda">Gujarat- Baroda</option>
<option value="Gujarat- Bharuch">Gujarat- Bharuch</option>
<option value="Gujarat- Bhavnagar">Gujarat- Bhavnagar</option>
<option value="Gujarat- Bhuj">Gujarat- Bhuj</option>
<option value="Gujarat- Gir">Gujarat- Gir</option>
<option value="Gujarat- Jamnagar">Gujarat- Jamnagar</option>
<option value="Gujarat- Other">Gujarat- Other</option>
<option value="Gujarat- Surat">Gujarat- Surat</option>
<option value="Gujarat- Valsad">Gujarat- Valsad</option>
<option value="Gujarat- Vapi">Gujarat- Vapi</option>
<option value="Harayana- Ambala">Harayana- Ambala</option>
<option value="Harayana- Faridabad">Harayana- Faridabad</option>
<option value="Harayana- Gurgaon">Harayana- Gurgaon</option>
<option value="Harayana- Hisar">Harayana- Hisar</option>
<option value="Harayana- Karnal">Harayana- Karnal</option>
<option value="Harayana- Kurukshetra">Harayana- Kurukshetra</option>
<option value="Harayana- Other">Harayana- Other</option>
<option value="Harayana- Panipat">Harayana- Panipat</option>
<option value="Harayana- Rohtak">Harayana- Rohtak</option>
<option value="Hawaii">Hawaii</option>
<option value="Himachal Pradesh- Dalhousie">Himachal Pradesh- Dalhousie</option>
<option value="Himachal Pradesh- Dharmasala">Himachal Pradesh- Dharmasala</option>
<option value="Himachal Pradesh- Kulu/ Manali">Himachal Pradesh- Kulu/ Manali</option>
<option value="Himachal Pradesh- Other">Himachal Pradesh- Other</option>
<option value="Himachal Pradesh- Shimla">Himachal Pradesh- Shimla</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hyderabad">Hyderabad</option>
<option value="Idaho">Idaho</option>
<option value="Illinois">Illinois</option>
<option value="Indiana">Indiana</option>
<option value="Indonesia">Indonesia</option>
<option value="Iowa">Iowa</option>
<option value="Ireland">Ireland</option>
<option value="Jammu and Kashmir- Jammu">Jammu and Kashmir- Jammu</option>
<option value="Jammu and Kashmir- Other">Jammu and Kashmir- Other</option>
<option value="Jammu and Kashmir- Srinagar">Jammu and Kashmir- Srinagar</option>
<option value="Japan">Japan</option>
<option value="Jharkhand- Bokaro">Jharkhand- Bokaro</option>
<option value="Jharkhand- Dhanbad">Jharkhand- Dhanbad</option>
<option value="Jharkhand- Jamshedpur">Jharkhand- Jamshedpur</option>
<option value="Jharkhand- Other">Jharkhand- Other</option>
<option value="Jharkhand- Ranchi">Jharkhand- Ranchi</option>
<option value="Kansas">Kansas</option>
<option value="Karnataka- Bangalore">Karnataka- Bangalore</option>
<option value="Karnataka- Belgaum">Karnataka- Belgaum</option>
<option value="Karnataka- Bellary">Karnataka- Bellary</option>
<option value="Karnataka- Bidar">Karnataka- Bidar</option>
<option value="Karnataka- Dharwad">Karnataka- Dharwad</option>
<option value="Karnataka- Gulbarga">Karnataka- Gulbarga</option>
<option value="Karnataka- Hubli">Karnataka- Hubli</option>
<option value="Karnataka- Kolar">Karnataka- Kolar</option>
<option value="Karnataka- Mangalore">Karnataka- Mangalore</option>
<option value="Karnataka- Mysore">Karnataka- Mysore</option>
<option value="Karnataka- Other">Karnataka- Other</option>
<option value="Kentucky">Kentucky</option>
<option value="Kenya">Kenya</option>
<option value="Kerala- Calicut">Kerala- Calicut</option>
<option value="Kerala- Cochin">Kerala- Cochin</option>
<option value="Kerala- Kannur">Kerala- Kannur</option>
<option value="Kerala- Kollam">Kerala- Kollam</option>
<option value="Kerala- Kottayam">Kerala- Kottayam</option>
<option value="Kerala- Other">Kerala- Other</option>
<option value="Kerala- Palakkad">Kerala- Palakkad</option>
<option value="Kerala- Palghat">Kerala- Palghat</option>
<option value="Kerala- Thrissur">Kerala- Thrissur</option>
<option value="Kerala- Trivandrum">Kerala- Trivandrum</option>
<option value="Kolkatta">Kolkatta</option>
<option value="Kuwait">Kuwait</option>
<option value="Labrador">Labrador</option>
<option value="Louisiana">Louisiana</option>
<option value="M.P- Bhopal">M.P- Bhopal</option>
<option value="M.P- Gwalior">M.P- Gwalior</option>
<option value="M.P- Indore">M.P- Indore</option>
<option value="M.P- Jabalpur">M.P- Jabalpur</option>
<option value="M.P- Other">M.P- Other</option>
<option value="M.P- Ujjain">M.P- Ujjain</option>
<option value="Maharashtra- Ahmednagar">Maharashtra- Ahmednagar</option>
<option value="Maharashtra- Aurangabad">Maharashtra- Aurangabad</option>
<option value="Maharashtra- Jalgaon">Maharashtra- Jalgaon</option>
<option value="Maharashtra- Kolhapur">Maharashtra- Kolhapur</option>
<option value="Maharashtra- Mumbai">Maharashtra- Mumbai</option>
<option value="Maharashtra- Nagpur">Maharashtra- Nagpur</option>
<option value="Maharashtra- Nasik">Maharashtra- Nasik</option>
<option value="Maharashtra- Other">Maharashtra- Other</option>
<option value="Maharashtra- Pune">Maharashtra- Pune</option>
<option value="Maine">Maine</option>
<option value="Malaysia">Malaysia</option>
<option value="Manipur- Imphal">Manipur- Imphal</option>
<option value="Manipur- Other">Manipur- Other</option>
<option value="Manitoba">Manitoba</option>
<option value="Maryland">Maryland</option>
<option value="Massachusetts">Massachusetts</option>
<option value="Meghalaya- Other">Meghalaya- Other</option>
<option value="Meghalaya- Shillong">Meghalaya- Shillong</option>
<option value="Michigan">Michigan</option>
<option value="Minnesota">Minnesota</option>
<option value="Mississippi">Mississippi</option>
<option value="Missouri">Missouri</option>
<option value="Mizoram- Aizawal">Mizoram- Aizawal</option>
<option value="Mizoram- Other">Mizoram- Other</option>
<option value="Montana">Montana</option>
<option value="Montreal">Montreal</option>
<option value="Mumbai">Mumbai</option>
<option value="Nagaland- Dimapur">Nagaland- Dimapur</option>
<option value="Nagaland- Other">Nagaland- Other</option>
<option value="Nebraska">Nebraska</option>
<option value="Nevada">Nevada</option>
<option value="New Brunswick">New Brunswick</option>
<option value="New Hampshire">New Hampshire</option>
<option value="New Jersey">New Jersey</option>
<option value="New Mexico">New Mexico</option>
<option value="New York">New York</option>
<option value="New Zealand">New Zealand</option>
<option value="Newfoundland">Newfoundland</option>
<option value="Nigeria">Nigeria</option>
<option value="North Carolina">North Carolina</option>
<option value="North Dakota">North Dakota</option>
<option value="North West Terr.">North West Terr.</option>
<option value="Nova Scotia">Nova Scotia</option>
<option value="Nunavut">Nunavut</option>
<option value="Ohio">Ohio</option>
<option value="Oklahoma">Oklahoma</option>
<option value="Oman">Oman</option>
<option value="Ontario">Ontario</option>
<option value="Oregon">Oregon</option>
<option value="Orissa- Bhubaneshwar">Orissa- Bhubaneshwar</option>
<option value="Orissa- Cuttack">Orissa- Cuttack</option>
<option value="Orissa- Other">Orissa- Other</option>
<option value="Orissa- Paradeep">Orissa- Paradeep</option>
<option value="Orissa- Puri">Orissa- Puri</option>
<option value="Orissa- Rourkela">Orissa- Rourkela</option>
<option value="Other- India">Other- India</option>
<option value="Other- International Locations">Other- International Locations</option>
<option value="Pennsylvania">Pennsylvania</option>
<option value="Pondicherry">Pondicherry</option>
<option value="Prince Edward Is.">Prince Edward Is.</option>
<option value="Provinces in ARMM">Provinces in ARMM</option>
<option value="Provinces in CAR">Provinces in CAR</option>
<option value="Provinces in Region-01">Provinces in Region-01</option>
<option value="Provinces in Region-02">Provinces in Region-02</option>
<option value="Provinces in Region-03">Provinces in Region-03</option>
<option value="Provinces in Region-04A">Provinces in Region-04A</option>
<option value="Provinces in Region-04B">Provinces in Region-04B</option>
<option value="Provinces in Region-05">Provinces in Region-05</option>
<option value="Provinces in Region-06">Provinces in Region-06</option>
<option value="Provinces in Region-07">Provinces in Region-07</option>
<option value="Provinces in Region-08">Provinces in Region-08</option>
<option value="Provinces in Region-09">Provinces in Region-09</option>
<option value="Provinces in Region-10">Provinces in Region-10</option>
<option value="Provinces in Region-11">Provinces in Region-11</option>
<option value="Provinces in Region-12">Provinces in Region-12</option>
<option value="Provinces in Region-13">Provinces in Region-13</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Pune">Pune</option>
<option value="Punjab- Amritsar">Punjab- Amritsar</option>
<option value="Punjab- Bathinda">Punjab- Bathinda</option>
<option value="Punjab- Jalandhar">Punjab- Jalandhar</option>
<option value="Punjab- Ludhiana">Punjab- Ludhiana</option>
<option value="Punjab- Other">Punjab- Other</option>
<option value="Punjab-Mohali">Punjab-Mohali</option>
<option value="Punjab-Patiala">Punjab-Patiala</option>
<option value="Quebec">Quebec</option>
<option value="Rajasthan- Ajmer">Rajasthan- Ajmer</option>
<option value="Rajasthan- Jaipur">Rajasthan- Jaipur</option>
<option value="Rajasthan- Jaisalmer">Rajasthan- Jaisalmer</option>
<option value="Rajasthan- Jodhpur">Rajasthan- Jodhpur</option>
<option value="Rajasthan- Kota">Rajasthan- Kota</option>
<option value="Rajasthan- Other">Rajasthan- Other</option>
<option value="Rajasthan- Udaipur">Rajasthan- Udaipur</option>
<option value="Rhode Island">Rhode Island</option>
<option value="Saskatchewen">Saskatchewen</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Sikkim- Gangtok">Sikkim- Gangtok</option>
<option value="Sikkim- Other">Sikkim- Other</option>
<option value="Singapore">Singapore</option>
<option value="South Carolina">South Carolina</option>
<option value="South Dakota">South Dakota</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="Switzerland">Switzerland</option>
<option value="T.N- Chennai">T.N- Chennai</option>
<option value="T.N- Coimbatore">T.N- Coimbatore</option>
<option value="T.N- Cuddarole">T.N- Cuddarole</option>
<option value="T.N- Erode">T.N- Erode</option>
<option value="T.N- Hosur">T.N- Hosur</option>
<option value="T.N- Madurai">T.N- Madurai</option>
<option value="T.N- Nagercoil">T.N- Nagercoil</option>
<option value="T.N- Ooty">T.N- Ooty</option>
<option value="T.N- Other">T.N- Other</option>
<option value="T.N- Salem">T.N- Salem</option>
<option value="T.N- Thanjavur">T.N- Thanjavur</option>
<option value="T.N- Trichy">T.N- Trichy</option>
<option value="T.N- Trinelveli">T.N- Trinelveli</option>
<option value="T.N- Tuticorin">T.N- Tuticorin</option>
<option value="T.N- Vellore">T.N- Vellore</option>
<option value="Tennessee">Tennessee</option>
<option value="Texas">Texas</option>
<option value="Thailand">Thailand</option>
<option value="U.P- Agra">U.P- Agra</option>
<option value="U.P- Aligarh">U.P- Aligarh</option>
<option value="U.P- Bareilly">U.P- Bareilly</option>
<option value="U.P- Faizabad">U.P- Faizabad</option>
<option value="U.P- Ghaziabad">U.P- Ghaziabad</option>
<option value="U.P- Gorakhpur">U.P- Gorakhpur</option>
<option value="U.P- Kanpur">U.P- Kanpur</option>
<option value="U.P- Lucknow">U.P- Lucknow</option>
<option value="U.P- Mathura">U.P- Mathura</option>
<option value="U.P- Meerut">U.P- Meerut</option>
<option value="U.P- Noida">U.P- Noida</option>
<option value="U.P- Other">U.P- Other</option>
<option value="U.P- Varanasi">U.P- Varanasi</option>
<option value="United Kingdom (UK)">United Kingdom (UK)</option>
<option value="United States (USA)">United States (USA)</option>
<option value="Utah">Utah</option>
<option value="Uttaranchal Pradesh- Dehradun">Uttaranchal Pradesh- Dehradun</option>
<option value="Uttaranchal Pradesh- Other">Uttaranchal Pradesh- Other</option>
<option value="Uttaranchal Pradesh- Roorkee">Uttaranchal Pradesh- Roorkee</option>
<option value="Vermont">Vermont</option>
<option value="Virgin Islands">Virgin Islands</option>
<option value="Virginia">Virginia</option>
<option value="Washington">Washington</option>
<option value="West Bengal- Asansol">West Bengal- Asansol</option>
<option value="West Bengal- Durgapur">West Bengal- Durgapur</option>
<option value="West Bengal- Haldia">West Bengal- Haldia</option>
<option value="West Bengal- Kharagpur">West Bengal- Kharagpur</option>
<option value="West Bengal- Other">West Bengal- Other</option>
<option value="West Bengal- Siliguri">West Bengal- Siliguri</option>
<option value="West Virginia">West Virginia</option>
<option value="Wisconsin">Wisconsin</option>
<option value="Wyoming">Wyoming</option>
<option value="Yukon">Yukon</option>
<option value="Anywhere in India">Anywhere in India</option>
<option value="Anywhere in Northern India">Anywhere in Northern India</option>
<option value="Anywhere in South India">Anywhere in South India</option>
<option value="Anywhere in West India">Anywhere in West India</option>
<option value="Anywhere in East India">Anywhere in East India</option>
<option value="Any International Location">Any International Location</option>
                    </select>
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
            <div class="FRow">
                <div class="FRowSec">
                    <label>Country  :</label>
                    <select required name="country" tabindex="1"  id="country"class="body1" >
<option value="0">- Select Country -</option>
<option value="26">Australia</option>
<option value="7">Austria</option>
<option value="18">Belgium</option>
<option value="1">Canada</option>
<option value="27">China</option>
<option value="20">Finland</option>
<option value="32">France</option>
<option value="6">Germany</option>
<option value="43">Hong Kong</option>
<option value="28" selected="selected">India</option>
<option value="21">Ireland</option>
<option value="10">Italy</option>
<option value="40">Japan</option>
<option value="47">Kuwait</option>
<option value="41">Malaysia</option>
<option value="3">Mexico</option>
<option value="36">Nepal</option>
<option value="23">Netherlands</option>
<option value="38">Philippines</option>
<option value="46">Qatar</option>
<option value="30">Singapore</option>
<option value="45">South Africa</option>
<option value="8">Spain</option>
<option value="25">Sweden</option>
<option value="17">Switzerland</option>
<option value="42">Taiwan</option>
<option value="44">United Arab Emirates</option>
<option value="24">United Kingdom</option>
<option value="2">United States</option>
<option value="39">Viet nam</option>
                    </select>
                </div>
                <div class="FRowSec">
                    <label>Address Line :</label>
                    <textarea required name="address" id="address"></textarea>                    
                </div>
                <div class="FRowSec">                
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>Qualification :</label>
                    <select required name="qualification" id="qualification">
<option value="0">- Select Qualification -</option>
<option value="10">Any</option>
<option value="30">Any Computers (Degree/Diploma)</option>
<option value="15">Any Diploma Holders</option>
<option value="29">Any Engineering</option>
<option value="31">Any Hotel Management</option>
<option value="20">Any Management</option>
<option value="32">Any Medical</option>
<option value="24">Any Post Graduate</option>
<option value="56">Associate of Applied Science</option>
<option value="54">Associate of Arts</option>
<option value="57">Associate of Occupational Studies</option>
<option value="55">Associate of Science</option>
<option value="3">B. Com</option>
<option value="8">B. Pharma.</option>
<option value="9">B. Sc.</option>
<option value="5">B. Tech/B.E.</option>
<option value="1">B.A.</option>
<option value="35">B.B.A.</option>
<option value="34">B.C.A.</option>
<option value="38">B.H.M</option>
<option value="58">Bachelor of Arts</option>
<option value="2">Bachelor of Bus. Admin/ Mgmt.</option>
<option value="4">Bachelor of Comp. Apps./ Mgmt.</option>
<option value="37">Bachelor of Dental Science</option>
<option value="61">Bachelor of Engineering</option>
<option value="59">Bachelor of Science</option>
<option value="33">Bachelors Of Architecture</option>
<option value="36">Bachelors of Education</option>
<option value="51">BSc (IT)</option>
<option value="50">BSc Maths</option>
<option value="11">Chartered Accountant (C.A.)</option>
<option value="12">Company Secretary (C.S.)</option>
<option value="14">Diploma</option>
<option value="39">ICWA</option>
<option value="40">Integrated PG. Course</option>
<option value="41">Journalism/ Mass Communication</option>
<option value="6">LLB</option>
<option value="48">M Stat</option>
<option value="52">M Tech</option>
<option value="19">M.C.A</option>
<option value="45">M.S/M.D</option>
<option value="43">Master of Architecture</option>
<option value="17">Master of Arts</option>
<option value="60">Master of Business Administration</option>
<option value="18">Master of Commerce (M. Com.)</option>
<option value="44">Master of Education</option>
<option value="42">Master of Law</option>
<option value="22">Master of Pharmacy</option>
<option value="23">Master of Science</option>
<option value="21">Master of Technology</option>
<option value="26">Masters in Mgmt. - Part/ Correspondence</option>
<option value="25">MBA/PGDBM</option>
<option value="7">MBBS</option>
<option value="53">ME</option>
<option value="47">MPHIL</option>
<option value="49">MSc (IT)</option>
<option value="46">PG. Diploma</option>
<option value="16">PhD/Doctorate</option>
<option value="28">Others</option>
                    </select>
                </div>
                <div class="FRowSec">
                    <label>If ‘Others’ , please type your qualification  ( Optional ) :</label>
                    <input name="other_qualification" type="text" id="other_qualification" />
                </div>
                <div class="FRowSec">
                    
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
            <div class="FRow">
                <div class="FRowSec">
                    <label style="display:block;">Total Experience  :</label>
                    <select name="exp_years" id="exp_years" class="exp_select">
<option value="0">Select Year/s</option>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
                    </select>
                    <select name="exp_months" id="exp_months" class="exp_select">
<option value="0" selected="selected">0 Months</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
                    </select>
                </div>
                <div class="FRowSec">
                    <label style="display:block;">Relevant Experience  :</label>
                    <select name="relevant_exp_years" id="exp_years" class="exp_select">
<option value="0">Select Year/s</option>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
                    </select>
                    <select name="relevant_exp_months" id="exp_months" class="exp_select">
<option value="0" selected="selected">0 Months</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
                    </select>
                    
                </div>
                <div class="FRowSec">
                
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
            <div class="FRow">
                <div class="FRowSec">
                    <label>Resume :</label>
                    <input type="file" id="cvfile" name="cvfile"  />
                </div>
                <div class="FRowSec">
                    <label>or Resume Synopsis  :</label>
                    <textarea id="cvText" name="cvText"></textarea>
                </div>
                <div class="FRowSec">
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        <div class="JoinEmpoye">
        	<div class="FRow">
                <div class="FRowSec" style="margin:0 auto;float:none;">
                    <input type="submit" />
                </div>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
        </div>
        </form>
        <!--####################################################-->
    </div>
</div>
