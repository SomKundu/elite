<script>
$(document).ready(function () {
    $('nav a').on('click', function() {
    var scrollAnchor = $(this).attr('data-scroll'),
        scrollPoint  = $('section[data-anchor="'+scrollAnchor+'"]').offset().top - 175;                      
   $('body,html').animate({
       scrollTop: scrollPoint
   }, 500);    
   return false;
})
$(window).scroll(function() {
});
$(window).scroll(function() {
    if ($(".Corpwrapper").scrollTop() >= 0) {
        $('nav').addClass('fixed');        
    } else {
        $('nav').removeClass('PaddTop170');
    }
});
});
</script>
<style type="text/css">    
.Corpwrapper {
    margin: 0 auto;
    position: relative;
    padding: 0 0 0 150px;
}
nav.CroporateNav {
    position: absolute;
    /*left: 0;
    width: 100%;*/
    right; 0;
    top: 175px;
    background: rgb(61, 61, 61);
    display: block;
    z-index: 100;
    padding: 10px;
}
nav.CroporateNav li { display:block; width:100%; font-size:13px;}
nav.CroporateNav a {
    font-family: helvetica;
    color: #ffffff;
    padding: 5px 2px;
    display: block;
    text-decoration: none;
    margin-right: 4px;
}
nav.CroporateNav a:hover,
nav.CroporateNav a.active {
    /*background: white;
    color: green;*/
}
.CroporateNav.fixed {
    position: fixed;
    top: 175px;
} 
.PaddTop170 { padding-top: 0;}
.gg { padding:0 0 25px 0;}
</style>
<div class="SectionOuter SubpageWrap">
    <div class="SectionInner">       
       <nav class="CroporateNav">
            <ul>
                <?php foreach($contentList as $head){?>
                <li><a href="#" data-scroll="anchor_<?=$head->id?>"><?=$head->header?></a></li>
                <?php }?>
            </ul>
        </nav>

<div class="Corpwrapper">
    <?php foreach($contentList as $row){?>
    <section id="content_<?=$row->id?>" data-anchor="anchor_<?=$row->id?>" class="gg">        
        <h4><?=$row->header?></h4>
                <?php if($row->image<>''){?>
                    <img class="avatar" alt="Jane" src="<?=base_url().'uploads/content/'.$row->image?>" 
                        style="width: 98% !important">
              <?php }?>
        <?=$row->content?>
    </section>
    <?php }?>
    
</div>

    </div>
  </div>