<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "home";

$route['404_override'] = '';
################################################################################
$route['cms-admin/banner/delete/(:any)']	= 'cms_banner/delete';
$route['cms-admin/banner/edit/(:any)']		= 'cms_banner/edit';
$route['cms-admin/banner/addnew']			= 'cms_banner/addnew/';
$route['cms-admin/banner/index']			= 'cms_banner/index/';
$route['cms-admin/catagory/delete/(:any)']	= 'cms_catagory/delete';
$route['cms-admin/catagory/edit/(:any)']	= 'cms_catagory/edit';
$route['cms-admin/catagory/addnew']			= 'cms_catagory/addnew/';
$route['cms-admin/catagory/index']			= 'cms_catagory/index/';
##########################################################################
$route['cms-admin/offer/delete/(:any)']	= 'cms_offer/delete';
$route['cms-admin/offer/edit/(:any)']		= 'cms_offer/edit';
$route['cms-admin/offer/addnew']			= 'cms_offer/addnew/';
$route['cms-admin/offer/index']			= 'cms_offer/index/';
##########################################################################
$route['cms-admin/content/delete/(:any)']	= 'cms_content/delete';
$route['cms-admin/content/edit/(:any)']		= 'cms_content/edit';
$route['cms-admin/content/addnew']			= 'cms_content/addnew/';
$route['cms-admin/content/index']			= 'cms_content/index/default';
$route['cms-admin/corporate/index']			= 'cms_content/index/corporate';
$route['cms-admin/media/index']				= 'cms_content/index/media';
##########################################################################
$route['cms-admin/product/index']				= 'cms_product/index/';
$route['cms-admin/product/delete/(:any)']		= 'cms_product/delete';
$route['cms-admin/product/addnew/(:any)/(:any)']= 'cms_product/entry/';
$route['cms-admin/product/edit/(:any)/(:any)']	= 'cms_product/entry/';
##########################################################################
$route['cms-admin/subcatagory/delete/(:any)']	= 'cms_subcatagory/delete';
$route['cms-admin/subcatagory/edit/(:any)']		= 'cms_subcatagory/edit';
$route['cms-admin/subcatagory/addnew']			= 'cms_subcatagory/addnew/';
$route['cms-admin/subcatagory/index']			= 'cms_subcatagory/index/';
$route['cms-admin/login/index']					= 'cms_login/index/';
$route['cms-admin/login/logout']				= 'cms_login/logout/';
$route['cms-admin']								= 'cms_admin/index/';
$route['cms-admin/attribute/addnew']			= 'cms_attribute/addnew/';
$route['cms-admin/attribute/index']				= 'cms_attribute/index/';
$route['cms-admin/attribute/delete/(:any)']		= 'cms_attribute/delete';
$route['cms-admin/attribute/edit/(:any)']		= 'cms_attribute/edit';
$route['cms-admin/attribute/attribute_delete/(:any)/(:any)']	= 'cms_attribute/attribute_delete';
$route['cms-admin/attribute/add_attribute/(:any)']				= 'cms_attribute/add_attribute';
##################################################################################
$route['cms-admin/store_locator/addnew']		= 'cms_store_locator/addnew/';
$route['cms-admin/store_locator/index']			= 'cms_store_locator/index/';
$route['cms-admin/store_locator/delete/(:any)']	= 'cms_store_locator/delete';
$route['cms-admin/store_locator/edit/(:any)']	= 'cms_store_locator/edit';
$route['cms-admin/newsletter/addnew']			= 'cms_newsletter/addnew/';
$route['cms-admin/newsletter/index']			= 'cms_newsletter/index/';
$route['cms-admin/newsletter/delete/(:any)']	= 'cms_newsletter/delete';
$route['cms-admin/newsletter/edit/(:any)']		= 'cms_newsletter/edit';

$route['cms-admin/attribute_master/addnew']			= 'cms_attribute_master/addnew/';
$route['cms-admin/attribute_master/index']			= 'cms_attribute_master/index/';
$route['cms-admin/attribute_master/delete/(:any)']	= 'cms_attribute_master/delete';
$route['cms-admin/attribute_master/edit/(:any)']	= 'cms_attribute_master/edit';
###################################################################################
$route['cms-admin/franchise/edit/(:any)']	= 'cms_franchise/edit';
$route['cms-admin/franchise/index']			= 'cms_franchise/index/';

$route['cms-admin/jobseeker/edit/(:any)']	= 'cms_jobseeker/edit';
$route['cms-admin/jobseeker/index']			= 'cms_jobseeker/index/';

$route['cms-admin/comments/edit/(:any)']	= 'cms_comment/edit';
$route['cms-admin/comments/index']			= 'cms_comment/index/';
###################################################################################
$route['product/list/(:any)/(:any)']		= 'product/index';
$route['content/(:any)']					= 'content/index';
$route['storelocator/']						= 'storelocator/index/';
$route['corporate/']						= 'corporate/index/';
$route['media/']							= 'media/index/';
$route['comment/']							= 'comment/index/';
$route['joinus/']							= 'joinus/index/';
$route['franchise/']						= 'franchise/index/';


/* End of file routes.php */
/* Location: ./application/config/routes.php */